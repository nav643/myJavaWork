INSERT INTO users (name, email, framework) VALUES ('Mafiz', 'mafiz@state.mn.us', 'GWT, Hibernate, Struts');
INSERT INTO users (name, email, framework) VALUES ('Sue', 'sue@state.mn.us', 'SpringMVC, JSF');
INSERT INTO users (name, email, framework) VALUES ('Mashood', 'mashood@state.mn.us', 'Hibernate, JSF');
INSERT INTO users (name, email, framework) VALUES ('Phil', 'phil@state.mn.us', 'SpringMVC, JSF');