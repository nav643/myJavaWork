$(document).ready(function()
{		
	var serviceCodes = [];
	var names = ['Alex','Billi','Dale'];
	display_array();
	
	
	$('#nav').click(function()
	{
		alert($(this).val());
	});
	
	
	$('#btnAdd').click(function()
	{
		//fill the simple one dimension array first
		var name = $('#name').val();
		names.push(name);// appending value to arry
		
		//fill the object array now with details from other text boxes
		var serviceCodeLength = serviceCodes.length;
		var serviceCode = {
				id: serviceCodeLength + 1,
				displayValue: "SV" + (serviceCodeLength + 1),
				personName: name,
				description: {
					W: $("#Weight").val(),
					H: $("#Height").val(),
					C: $("#Color").val()
				},
				age: $("#age").val(),
				DOB: $("#DOB").val()
		};
		serviceCodes.push(serviceCode);	
		
		display_array();
		
	});
	
	
		//************ bootstrap datepickers *************
	$("#DOB-DP").datepicker({		
	   autoclose: true,
	   todayHighlight: true,
	   format: 'mm/dd/yyyy',
	   //formatSubmit: 'yyyy-mm-dd',
	   //endDate: '@DateTime.Now.ToString("yyyy-mm-dd")',
	   startDate: new Date()  		
	});
	
	
	
	//show contents of array in a div
	function display_array()
	{
		//alert("in array");

		$("#names").text('');
		$('#Codes').append("Printing Names" + "<br/>");
		$.each(names,function(index,value)
		{
		  $('#names').append(index+1 + '. ' + value + '<br/>');
		});
		
		
		//now print object array
		$("#Codes").text('');
		$('#Codes').append("<br/>"+"<br/>"+"Printing Object array ..."+"<br/>");
		$('#Codes').append('<table class="table table-striped">');
		$('#Codes').append('<thead><tr><th scope="col">id</th>' +
									'<th scope="col">Name</th><th scope="col">Age</th>' + 
									'<th scope="col">W</th><th scope="col">H</th><th scope="col">C</th><th scope="col">DOB</th>' + 
									'</tr></thead>');
		
		$('#Codes').append("<tbody>")
		$.each(serviceCodes,function(index,value)
		{
		  //index++;
/* 		  $('#Codes').append(value.displayValue + 
							'. ' + value.id + 
							' - ' + value.personName + 
							' is ' + value.age + ' years old' + 
							' and weighs ' + value.description.W + ' kg ' + 
							' with ' + value.description.H + ' ft ' + 
							' and ' + value.description.C + ' hair color<br/>'
							); */
							
		  $('#Codes').append("<tr>" +
							"<th scope='row'><input  href='" + value.id + "' id='nav'>" + value.displayValue + "</a></th>" +
							//"<td>" + value.id + "</td>" + 
							"<td>" + value.personName + "</td>" + 
							"<td>" + value.age + " years</td>" + 
							"<td>" + value.description.W + " lbs.</td>" + 
							"<td>" + value.description.H + " ft</td>" +
							"<td>" + value.description.C + "</td>" +
							"<td>" + value.description.DOB + "</td>" +
							"</tr>"
							);					
		});
		$('#Codes').append("</tbody>");
		
		//Closing the table
		$('#Codes').append("</table>");
		
		//set up the success message
		$('#messaging').text('A simple success: new record is added!');
	}
	
	$('#reset').click(function()
	{
		$("#names").text('');
		$('#Codes').text('');
		$('#messaging').text('');
		
		$("#age").val('');
		$("#Weight").val('');
		$("#Height").val('');
		$("#Color").val('');
	});
	
	$('#auto').click(function()
	{
		
		$("#age").val('24');
		$("#Weight").val('133');
		$("#Height").val('6');
		$("#Color").val('Black');		
	});
	
	
	
	//Diagnosis Code
	$("#addDiagnosisCode").click(function(){	
		//if empty then alert otherwise add (type:number) text
		var diagnosisCode = $("#diagnosisCode").val();
		if (!diagnosisCode || 0 === diagnosisCode.length) {
			alert("The required field(s) for this entry have not been completed.");
		} else if (diagnosisCode.length < 3 || diagnosisCode.length > 8) {
			alert("MHCP recognizes only values of 3 to 8 characters in DIagnosis Code.");
		} else {
			$("#ListDiagnosisCodes").append($('<option/>', {value : diagnosisCode, 	text : diagnosisCode }) );
			$("#diagnosisCode").val("");
		}
	});
	
	$("#delDiagnosisCode").click(function(){	
		//if empty then alert otherwise add (type:number) text
		$("#ListDiagnosisCodes option:selected").remove();
		$("#diagnosisCode").val("");
	});
	
	$("#ListDiagnosisCodes").change(function(){	
		//if empty then alert otherwise add (type:number) text
		var selectedValue = $(this).val();
		$("#diagnosisCode").val(selectedValue);
	});
	
	$("#ListDiagnosisCodes").blur(function(){	
		if( !$(this).val() ) {
	        //$(this).css("background-color", "#f2dede");
			alert("You must enter at least one value in Diagnosis code.");
	        //$(this).addClass('warning');
	    } else {
	        $(this).css("background-color", "#ffffff");
	    }
	});
	
	$("#checkDiagnosisCode").click(function(){
		$("#ListDiagnosisCodes > option").each(function() {
			alert($(this).val() + " , " + $("#ListDiagnosisCodes").text());
			//console.log($(this).val());
		})
		$("#communicationText").each(function() {
			alert($("#communicationText").val() + " , " + $("#communicationText").text());
			//console.log($(this).val());
		})
	});
	
		//input, textarea, select
		$( "form" ).submit(function( event ) {
		  console.log( $( this ).serializeArray() );
		  event.preventDefault();
		});
});