package com.us.mn.state.dhs.mnits.mvcpoc.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.us.mn.state.dhs.mnits.mvcpoc.model.User;
import com.us.mn.state.dhs.mnits.mvcpoc.service.UserService;
import com.us.mn.state.dhs.mnits.mvcpoc.validator.UserFormValidator;

@Controller
public class TestFormController {

	private final Logger logger = LoggerFactory.getLogger(TestFormController.class);


	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		logger.debug("index()");
		return "redirect:/users/find";
	}

	// list page
	@RequestMapping(value = "/testForm", method = RequestMethod.GET)
	public String showTestFormInHTMLFolder(Model model) {

		logger.debug("testForm -> html/test.html");
		//model.addAttribute("users", userService.findAll());
		
		return "html/test.html";
	}

	
	// list page
	@RequestMapping(value = "/testForm2", method = RequestMethod.GET)
	public String showTestFormInJSPFolder(Model model) {

		logger.debug("testForm2 -> jsp/test.html");
		//model.addAttribute("users", userService.findAll());
		
		return "test.html";
	}

	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ModelAndView handleEmptyData(HttpServletRequest req, Exception ex) {

		logger.debug("handleEmptyData()");
		logger.error("Request: {}, error ", req.getRequestURL(), ex);

		ModelAndView model = new ModelAndView();
		model.setViewName("user/show");
		model.addObject("msg", "user not found");

		return model;

	}

}