package com.us.mn.state.mnits.pasa.service;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import us.mn.state.dhs.caps.schema.AuthServLineActionFormSchema;
import us.mn.state.dhs.caps.schema.AuthServReqActionFormSchema;
import us.mn.state.dhs.caps.schema.HcsaAdditionalInfoFormSchema;
import us.mn.state.dhs.caps.schema.ObjectFactory;










import com.us.mn.state.mnits.pasa.helper.Day;
//import com.google.common.base.Splitter;
import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.ServiceInformation;
import com.us.mn.state.mnits.pasa.model.GeneralInfoServiceByNpi;
import com.us.mn.state.mnits.pasa.web.PASAController;

@RunWith(MockitoJUnitRunner.class)
public class PriorAuthorizationServiceImplTest {

	PriorAuthorizationServiceImpl PriorAuthorizationService;
	private final Logger logger = LoggerFactory.getLogger(PASAController.class);
	
	 @Before
     public void setupMocks()
     {
         GeneralInfoServiceByNpi testInfo = new GeneralInfoServiceByNpi();
         List<GeneralInfoServiceByNpi> testList = new ArrayList<GeneralInfoServiceByNpi>();
         testInfo.setProviderNumber("ABC");
         testList.add(testInfo);
         //when(generalInfoServiceByNpiDao.findByNpi("123")).thenReturn(testList);
          
     }
	
	//@Test
    public void dateToStringTest()
    {
		Date date = null; 
		String result = dateToString(date);
		//assertNull(result);
		assertTrue(StringUtils.isEmpty(result));
    }
	
	
	//@Test
    public void printMapAuthFormTest()
    {
		//build the form
		AuthForm form = new AuthForm();
		
		//PriorAuthorizationService.mapPAAuthForm(form);
		
    }
	
	@Test
	public void appTest(){
		ObjectFactory objFac = new ObjectFactory();
		AuthServLineActionFormSchema outLine = objFac.createAuthServLineActionFormSchema();
		ServiceInformation inLine = new ServiceInformation();
		
		outLine.setComments("");
		if (outLine.getComments() !=null && (!outLine.getComments().isEmpty()) ) {	
			outLine.setComments(inLine.getComments());
		} else {
			outLine.setComments("");
		}
	}
	
	@Test
	public void splitTheAdditionalInfoField() {
		String HcsaAdditionalInfoMessageText = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxssssssssssssssssssssssssss" +
				"ssttttttttttttttttttttttttttttttdddddddddddddddddddddddddddggggggggggggggggggggggggggg" +
				"gggggffffffffffffffffffffffffffjjjjjjjjjjjjjjjjjjjjjjjjj...........................ooo" +
				"oooooooooooouuuuuuuuuuuuuuuuuuuuu";
		if (!HcsaAdditionalInfoMessageText .isEmpty()) {
			//int hcsa_service_add_info_message_text_length = HcsaAdditionalInfoMessageText.length();
			//HcsaAdditionalInfoFormSchema hcsaAdditionalInfo = new HcsaAdditionalInfoFormSchema();
			
			String[] MessageStrings = HcsaAdditionalInfoMessageText.split("(?<=\\G.{70})");
			for (String msg : MessageStrings) {
			//for (String msg : Splitter.fixedLength(70).split(HcsaAdditionalInfoMessageText)) {
				//hcsaAdditionalInfo.setAdditionalInfo(substring);
				System.out.println(msg + " --> of length:" + msg.length());
			}
			//authFormSchema.getHcsaAdditionalInfo().add(hcsaAdditionalInfo);
		} else {
			System.out.println("String is empty, nothing to process");
		}
	}
	
	
	
	
	
	@Test
	public void twoVIPHiddenFieldsForSA() throws ParseException{
		logger.debug("Running test to figure out 2 very important SA hidden data fields ...");
		
		Date firstServBeginDate = null;
		Date lastServEndDate = null;
		Date servBeginDate = null;
		Date servEndDate = null;
		SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		
		List<ServiceInformation> mockItemList = new ArrayList<ServiceInformation>();
		
		ServiceInformation item1 = new ServiceInformation();
		item1.setBeginDate(myFormat.parse("12/12/2021"));
		item1.setEndDate(myFormat.parse("12/15/2021"));
		mockItemList.add(item1);
		
		ServiceInformation item2 = new ServiceInformation();
		item2.setBeginDate(myFormat.parse("12/13/2021"));
		item2.setEndDate(myFormat.parse("12/17/2021"));
		mockItemList.add(item2);
		
		ServiceInformation item3 = new ServiceInformation();
		item3.setBeginDate(myFormat.parse("12/11/2021"));
		item3.setEndDate(myFormat.parse("12/14/2021"));
		mockItemList.add(item3);
		
		ServiceInformation item4 = new ServiceInformation();
		item4.setBeginDate(myFormat.parse("12/14/2021"));
		item4.setEndDate(myFormat.parse("12/16/2021"));
		mockItemList.add(item4);

		// go thru all service line items and figure out the 1stest Begin date and lastest End date
		int serviceLineItemCounter = 0;
		for (ServiceInformation serviceLineItem : mockItemList) {
			// AuthServLineActionForm servLineItemForm =
			// inAuthForm.getServLineForm(lineItem); //lineItem is counter
			if (serviceLineItemCounter == 0) {
				firstServBeginDate = serviceLineItem.getBeginDate();
				lastServEndDate = serviceLineItem.getEndDate();
			}
			servBeginDate = serviceLineItem.getBeginDate();
			servEndDate = serviceLineItem.getEndDate();

			// 1st try/catch block for the earliest Begin Date for any service
			try {
				if (firstServBeginDate.after(servBeginDate)) {
					firstServBeginDate = servBeginDate;
				}
			} catch (Exception e) {
				logger.debug("mapSA AuthForm >> : Error while comparing the service Begin Date to figure out the earliest Begin Date for any service.");
				System.out.print(e.getMessage());
				System.out.print(e.getStackTrace());
			}

			// 2nd try/catch block for the latest End date for any service
			try {
				if (lastServEndDate.before(servEndDate)) {
					lastServEndDate = servEndDate;
				}
			} catch (Exception e) {
				logger.debug("mapSA AuthForm >> : Error while comparing the service End Date to figure out the latest End date for any service.");
				System.out.print(e.getMessage());
				System.out.print(e.getStackTrace());
			}
			
			logger.debug ("Item " + (serviceLineItemCounter + 1));
			logger.debug("Earliest BeginDate for now -> "+ myFormat.format(firstServBeginDate));			// + " -> "	+ firstServBeginDate.toString()
			logger.debug("Latest EndDate for now -> "+ myFormat.format(lastServEndDate));				// + " -> "	+ lastServEndDate.toString()

			serviceLineItemCounter++;
		}//end of for loop
		
		
		// TODO
		// at this point I am going to use the subcriber Gender field
		// Srv-agreement-begin-date
		// and the zip-code field to store the srv-agreement-end-date
		// When the PASchema_new.xsd change then we should create real fields
		// to store Srv-agreement-begin-date and Srv-agreement-end-date
		
		logger.debug("Finished pricessing all line items ...");
		if (firstServBeginDate != null & lastServEndDate != null) {
			logger.debug("Earliest Service Begin Date" + " -> "	+ myFormat.format(firstServBeginDate) + " -> "	+ firstServBeginDate.toString());
			logger.debug("lastest Service End Date" + " -> "	+ myFormat.format(lastServEndDate) + " -> " + lastServEndDate.toString());
			System.out.println("Day from Earliest Begin date using new Method: " + getNumberOfDaysFrom(firstServBeginDate).toPlainString());
			System.out.println("Day from Latest End date using new Method: " + getNumberOfDaysFrom(lastServEndDate).toPlainString());
			
			System.out.println("Day from Earliest Begin date using old Method: " + Day.getNoOfDays(dateToString(firstServBeginDate)).toPlainString());
			System.out.println("Day from Earliest Begin date using old Method: " + Day.getNoOfDays(dateToString(lastServEndDate)).toPlainString());
		}
	}
			

	
	
	
	// Century Date Calculations
	BigDecimal getNumberOfDaysFrom(Date thisDate) {
		SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date startDate = null;
		long finalcount = 0;

		try {
			startDate = myFormat.parse("12/31/1963");
			logger.debug("thisDate" + " -> "+ thisDate.toString() + "[" + myFormat.format(thisDate) + "] against "+ startDate.toString());
			//long diff = thisDate.getTime() - startDate.getTime();
			//finalcount = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			
		    long diffInMillies = Math.abs(thisDate.getTime() - startDate.getTime());
		    finalcount = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		    
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("Days from '" + myFormat.format(startDate) + "' are " + String.valueOf(finalcount));
		
		//int nbDays = firstDay.daysBetween(lastDay); 
		BigDecimal days = new BigDecimal(finalcount);	
		return days;
		
		//return String.valueOf(finalcount);	//if returning string

	}
	
	
	@Test
	public void givenTwoDatesBeforeJava8() {
		// creating the date 1 with sample input date.
			Date date1 = new Date(1963, 12, 30);
			
			// creating the date 2 with sample input date.
			Date date2 = new Date(2021, 12, 11);
			
			// getting milliseconds for both dates
			long date1InMs = date1.getTime();
			long date2InMs = date2.getTime();
			
			// getting the diff between two dates.
			long timeDiff = 0;
			if(date1InMs > date2InMs) {
				timeDiff = Math.abs(date1InMs - date2InMs);
			} else {
				timeDiff = Math.abs(date2InMs - date1InMs);
			}
			
			// converting diff into days
			int daysDiff = (int) (timeDiff / (1000 * 60 * 60* 24));
			
			// print diff in days
			System.out.println("No of days diff is : "+daysDiff);
			
		    long diffInMillies = timeDiff;
		    long finalcount = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		 
		    //int nbDays = firstDay.daysBetween(lastDay); 
			//BigDecimal days = new BigDecimal(finalcount);	
			//return days;
		    System.out.println("No of days diff using OLD methid is : "+daysDiff);
		}
	
	@Test
	public void meatOfTheDateCalculation() throws ParseException {
		
		SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date startDate = myFormat.parse("12/31/1963");
		Date todayDate = myFormat.parse("12/11/2021");
		
		Day firstDay = new Day(startDate.getYear() + 1900, startDate.getMonth(), startDate.getDate());
		Day lastDay = new Day(todayDate.getYear() + 1900, todayDate.getMonth(),	todayDate.getDate());
		int nbDays = firstDay.daysBetween(lastDay); 
		BigDecimal days = new BigDecimal(nbDays);
		
		System.out.println("Days using the bigDecimal method: " + days.toPlainString());
		//return days;
	}

	
	@Test
	public void givenTwoDatesBeforeJava8_whenDifferentiating_thenWeGetSix()
	  throws ParseException {
	 
	    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
	    Date firstDate = sdf.parse("06/24/2017");
	    Date secondDate = sdf.parse("06/30/2017");

	    long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
	    long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

	    assertEquals(6, diff);
	}
	
	@Test
	public void givenTwoDateTimesInJava8_whenDifferentiatingInSecondsUsingUntil_thenWeGetTen() {
	    LocalDateTime now = LocalDateTime.now();
	    LocalDateTime tenSecondsLater = now.plusSeconds(10);

	    long diff = now.until(tenSecondsLater, ChronoUnit.SECONDS);

	    assertEquals(10, diff);
	}
	
	@Test
	public void givenTwoDateTimesInJava8_whenDifferentiating_thenWeGetSix() {
	    LocalDateTime now = LocalDateTime.now();
	    LocalDateTime sixMinutesBehind = now.minusMinutes(6);

	    Duration duration = Duration.between(now, sixMinutesBehind);
	    long diff = Math.abs(duration.toMinutes());

	    assertEquals(6, diff);
	}
	
	
	@Test
	public void validateLineAmounts() {
		String[] assertingTrueNumberStrings = new String[]{"222.00","1.2","45678.90","9999999.99","453.2","9999999.9","1234567"};
		String[] assertingFalseNumberStrings = new String[]{"0","99999999.9","12345678","0.00"};
		
		System.out.println("Asserting True ->");	
		for (String numberString: assertingTrueNumberStrings) {
			System.out.println(numberString + " is " +  validateLineAmount(numberString));
		}
		
		System.out.println("Asserting False ->");	
		for (String numberString: assertingFalseNumberStrings) {
			System.out.println(numberString + " is " +  validateLineAmount(numberString));
		}
	}
	
	
	
	private boolean validateLineAmount(String numberString) {
					
		boolean decimalFound= numberString.indexOf('.') != -1;
		boolean oneAfterDecimalAllowed = true;
		
		if (decimalFound) {
			int decimalFoundAt= numberString.indexOf('.');
			
			String beforeDecimal =  numberString.substring(0, numberString.indexOf('.'));
			String afterDecimal =  numberString.substring(numberString.indexOf('.')+1, numberString.length());
			
			//beforeString length is only allowed to be 7 
//			if (NumberUtils.toDouble(numberString) == NumberUtils.DOUBLE_ZERO  ) {
//				return false;
//			}
			
			if (beforeDecimal.length() == 8 && afterDecimal.length() == 1){
				//88888888.9 is NOT allowed
				oneAfterDecimalAllowed = false;
				
				return false;
			} else if (beforeDecimal.length() == 8){
				oneAfterDecimalAllowed = false;
				
			} else if (beforeDecimal.length() < 8 && afterDecimal.length() < 3){
				//happy path 7777777.99
				oneAfterDecimalAllowed = true;
				
				return true;
			}
			
			if (numberString.length() == 10 && decimalFoundAt+1 == 9) {
				oneAfterDecimalAllowed = false;
			}
		} else {
			
			//Use cases for decimal not found
			
			//beforeString length is only allowed to be 7 so .00 can be attached
			if (numberString.length() > 7 ) {
				return false;
			}
			
//			if (NumberUtils.toDouble(numberString) == NumberUtils.INTEGER_ZERO  ) {
//				return false;
//			}
			
		}
		
		return true;
	}
	
	
	private String dateToString(Date date) {
	if (date == null) {
		return new String("");
	}
	DateFormat dateFormat = new SimpleDateFormat("MMddyyyy"); 
	// this is correct date format. old format was breaking the XML and JMS response would timeout
	return dateFormat.format(date);
}

	private void formatNumbers(String input) {
		//valueToValidate = "\b\d{0,2}(\.\d{1,2})?\b";
		//patternToMatch = "^[a-zA-Z0-9.]+$";
		
		System.out.format("double : %.2f", input); // 3.14
		System.out.println("double : " + String.format("%.2f", input)); // 3.14
	}
	
	
	@Test
	public void appTestSAdateChecks() {
		ObjectFactory objCreator = new ObjectFactory();
		AuthServReqActionFormSchema authFormSchema = objCreator.createAuthServReqActionFormSchema(); 
		Date firstServBeginDate = null ;
        Date lastServEndDate = null ;
        Date servBeginDate = null ;
        Date servEndDate = null ;
        
        ArrayList<ServiceInformation> serv = new ArrayList<ServiceInformation>();
        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        //String dateString = "01/01/2005";
        //Date dateObject = sdf.parse(dateString);
        
        try {
			//@DateTimeFormat(pattern="mm/dd/yyyy") or "yyyy-MM-dd"
			Date beginDate = sdf.parse("01/01/2005");
			//@DateTimeFormat(pattern="mm/dd/yyyy")
			Date endDate = sdf.parse("01/01/2010");
			
			ServiceInformation element = new ServiceInformation();
			element.setBeginDate(beginDate);
			element.setEndDate(endDate);
			element.setLineAmount("29.23");
			element.setProcedureCode("T1031");
			element.setQuantity("1");
			serv.add(element);
			
			ServiceInformation element2 = new ServiceInformation();
			element2.setBeginDate(sdf.parse("01/01/2008"));
			element2.setEndDate(sdf.parse("01/01/2009"));
			element2.setLineAmount("100.00");
			element2.setProcedureCode("T1055");
			element2.setQuantity("2");
			serv.add(element2);
			
        } catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
		int serviceLineItemCounter = 0;
        for (ServiceInformation serviceLineItem : serv){
			//AuthServLineActionForm servLineItemForm = inAuthForm.getServLineForm(lineItem); 	//lineItem is counter
		    if ( serviceLineItemCounter == 0) {
		    	firstServBeginDate = serviceLineItem.getBeginDate();
		    	lastServEndDate  = serviceLineItem.getEndDate();
		    }
		    servBeginDate = serviceLineItem.getBeginDate();
		    servEndDate = serviceLineItem.getEndDate();	
		   
		    //1st try/catch block
		    try {
		    	if (firstServBeginDate.after(servBeginDate)) {
		    		firstServBeginDate = servBeginDate ;   
		    	}
			}
		    catch (Exception e){
			    //logger.debug("mapSA AuthForm >> : Error while comparing the service Begin Date.");
			    System.out.print(e.getMessage());
			    System.out.print(e.getStackTrace());
		    }
		    
		    //2nd try/catch block
		    try {
			    if (lastServEndDate.before(servEndDate)) {
			    	lastServEndDate = servEndDate ;
			    }		
			}
		    catch (Exception e){
		    	//logger.debug("mapSA AuthForm >> : Error while comparing the service End Date.");
			    System.out.print(e.getMessage());
			    System.out.print(e.getStackTrace());
		    }
		    
		    serviceLineItemCounter++;
		}	
		// TODO
		// at this point I am going to use the subcriber Gender field Srv-agreement-begin-date
		// and the zip-code field to store the srv-agreement-end-date
		// When the PASchema_new.xsd change then we should create real fields 
		// to store Srv-agreement-begine-date and Srv-agreement-end-date
		
        /*authFormSchema.setSubscriberGender(Day.getNoOfDays(firstServBeginDate.toString()).toPlainString());
		authFormSchema.setRequesterZipCd(Day.getNoOfDays(lastServEndDate.toString()).toPlainString());
		assertNotNull(Day.getNoOfDays(firstServBeginDate.toString()).toPlainString());
		assertNotNull(Day.getNoOfDays(lastServEndDate.toString()).toPlainString());
		System.out.println(Day.getNoOfDays(firstServBeginDate.toString()).toPlainString() + Day.getNoOfDays(lastServEndDate.toString()).toPlainString());
		*/
        
        //TODO
//		authFormSchema.setSubscriberGender(getNumberOfDaysFrom(firstServBeginDate).toString());
//		authFormSchema.setRequesterZipCd(getNumberOfDaysFrom(lastServEndDate).toString());
//		assertNotNull(getNumberOfDaysFrom(firstServBeginDate).toString());
//		assertNotNull(getNumberOfDaysFrom(lastServEndDate).toString());
//		System.out.println(getNumberOfDaysFrom(firstServBeginDate).toString() + "  " + getNumberOfDaysFrom(lastServEndDate).toString());
	
	}
	
	
}
