package com.us.mn.state.mnits.pasa.model;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.junit.Test;
import org.junit.BeforeClass;
//import org.junit.Assert.assertThat;
import org.junit.Assert;




import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import us.mn.state.dhs.caps.schema.AuthServReqActionFormSchema;

import com.us.mn.state.mnits.pasa.validator.AuthFormValidator;
import com.us.mn.state.mnits.pasa.web.PASAController;
import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.User;

public class authFormUnitTest {

	private final Logger logger = LoggerFactory.getLogger(PASAController.class);
	private boolean isDebug = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;
    private static Validator validator;
    
    //@BeforeClass
    public static void setupValidatorInstance() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }
    
	//@Test
	public void whenFormHasProblems_thenShouldNotGiveConstraintViolations() {
	    AuthForm form = new AuthForm();
	    Set<ConstraintViolation<AuthForm>> violations = validator.validate(form, null);

	    //assertThat(violations.size());
	    //assertTrue(GenericValidator.isDate("02/28/2020", "MM/dd/yyyy", true));
	    //assertFalse(GenericValidator.isDate("02/29/2019", "MM/dd/yyyy", true));
/*	    
	    public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL  			= "1" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_DENTAL  			= "2" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL_SUPPLY  	= "4" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_HCSA  				= "9" ;
		
		public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL  			= "1" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_DENTAL  			= "35" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL_SUPPLY  	= "12" ;
		public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA  				= "42" ;*/
	}

	
	@Test
	public void StringFormatTests() throws ParseException{
		logger.debug("Running format tests ...");
		
		String valueToTest = "test-123";
		String patternToMatch = "";
		
		 if (valueToTest.matches("^[a-zA-Z0-9@]+$")) {
			 System.out.println("this string is fine");
		 } else {
			 System.out.println("something is not right");
		 }
		 assertFalse(valueToTest.matches("^[a-zA-Z0-9\\s]+$"));
		 assertFalse(valueToTest.matches("^[a-zA-Z0-9@]+$"));
		 
		 assertTrue(valueToTest.matches("^[a-zA-Z0-9-_]+$"));
		 //assertTrue(valueToTest.matches("^[a-zA-Z0-9@]+$"));
			 
		//error message when special characters are used in Supplement ID field

		
		//Home Health Care PA Allows Special Characters on Contact Last Name and Contact First Name fields

		
		//PA/SA Allows Special Characters on Communication Number field and form can be submitted
		valueToTest = "E:test @tt.co1-22_/123#";
		patternToMatch = "^(.+)@(.+)$";	//"^[a-zA-Z0-9\\s@_:/-]+$"
		
		 //phone number uses ()		//email uses . and @ so patternToMatch = "^(.+)@(.+)$";
		 if (valueToTest.matches(patternToMatch)) {	//^[a-zA-Z0-9\\s-]+$
			 System.out.println("this comTEXT string is fine");
		 } else {
			 System.out.println("something in comTEXT is not right");
 }
		
		//PA/SA Contact Name field accepts more than 60 characters and non-alphanumeric special characters

	
	}
	
	@Test
	public void HHC_BlankField() throws ParseException{
		logger.debug("Running Blank Field tests ...");
		//Health Care PA Allows Blank Value on Time Period Qualifier (Home Care Frequency) Required Field

	}
	
	@Test
	public void DentalCare_MissingFields() throws ParseException{
		logger.debug("Running  Missing Field tests ...");
		
		//Dental Care PA missing following info
		
		//modifiers
		
		//cavities
		
		//surface code
	}
	
	
	@Test
	public void ListFields() {
		List<String> data = new ArrayList<String>();
		List<String> dataUpdated = new ArrayList<String>();
		data.add("");
		data.add("");
		System.out.println(data);
		
		for (String code: data) {
			System.out.println(code.trim());
			if (! StringUtils.isEmpty(code)) {	dataUpdated.add(code.trim());	}		
		}
		System.out.println("After: " + dataUpdated.toString());
		
    	if (data.size()  > 0 ) {
			String cleanup = data.toString();
			data.clear();
			data.add(0, cleanup.substring(cleanup.indexOf(',')+1, cleanup.length()-1).trim());
		}
    	System.out.println("After: " + data.toString());
	}
	

	
	@Test
	public void DateValidity_string() throws ParseException{
		logger.debug("Running some date tests");
		String dateString = "Mon Aug 03 19:00:00 CDT 2020";
		boolean isDateValid = GenericValidator.isDate(dateString,"MM/dd/yyyy", true);
		System.out.println("date valid is " + isDateValid); 
		
		DateFormat formatter = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
	    Date dTemp=formatter.parse(dateString);;
	    
	    formatter=new SimpleDateFormat("MM/dd/yyyy");
	    String d_temp=formatter.format(dTemp);
	    System.out.println("val : " + d_temp);
	    
		isDateValid = GenericValidator.isDate(d_temp,"MM/dd/yyyy", true);
		if (isDateValid) {System.out.println("date is valid"); }
		
	}
	
	//@Test
	public void DateValidity_sdf() throws ParseException{
		String dateString = "Mon Aug 03 19:00:00 CDT 2020";
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date startdate = sdf.parse(dateString);
		boolean isDateValid = GenericValidator.isDate(startdate.toString(),"MM/dd/yyyy", true);
		if (isDateValid) {System.out.println("sdf date is valid"); }
		
	}
	
	//@Test
	public void DateValidity_straight() throws ParseException{
		String dateString = "Mon Aug 03 19:00:00 CDT 2020";
		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
		Date startdate = sdf.parse(dateString);
		boolean isDateValid = GenericValidator.isDate(startdate.toString(),"MM/dd/yyyy", true);
		if (isDateValid) {System.out.println("sdf date is valid"); }
	}
	
	
	
	// Century Date Calculations
	private	String getNumberOfDaysFrom(Date thisDate) {
		SimpleDateFormat myFormat = new SimpleDateFormat("mm/dd/yyyy");
		Date startdate;
		long finalcount = 0;
	
		try {
			startdate = myFormat.parse("12/31/1963");
			// System.out.println("thisDate" + " -> "+ thisDate.toString());
			long diff = thisDate.getTime() - startdate.getTime();
			finalcount = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("Days: " + String.valueOf(finalcount));
		return String.valueOf(finalcount);
	}

	
	public static void main(String[] args)   {
        //Create ValidatorFactory which returns validator
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
         
        //It validates bean instances
        Validator validator = factory.getValidator();
 
        User user = new User();
 
        //Validate bean
        Set<ConstraintViolation<User>> constraintViolations = validator.validate(user);
 
        //Show errors
        if (constraintViolations.size() > 0) {
            for (ConstraintViolation<User> violation : constraintViolations) {
                System.out.println(violation.getMessage());
            }
        } else {
            System.out.println("Valid Object");
        }
    }
}
