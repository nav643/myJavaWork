package com.us.mn.state.mnits.pasa.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.us.mn.state.mnits.pasa.dao.GeneralInfoServiceByNpiDao;
import com.us.mn.state.mnits.pasa.model.GeneralInfoServiceByNpi;


@RunWith(MockitoJUnitRunner.class)
public class GeneralInfoServiceByNpiServiceImplTest {


	@InjectMocks
	GeneralInfoServiceByNpiServiceImpl generalInfoServiceByNpiService;
	
	@Mock
	GeneralInfoServiceByNpiDao generalInfoServiceByNpiDao;
	
	
	 @Before
     public void setupMocks()
     {
         GeneralInfoServiceByNpi testInfo = new GeneralInfoServiceByNpi();
         List<GeneralInfoServiceByNpi> testList = new ArrayList<GeneralInfoServiceByNpi>();
         testInfo.setProviderNumber("ABC");
         testList.add(testInfo);
         when(generalInfoServiceByNpiDao.findByNpi("123")).thenReturn(testList);
          
     }
	
	@Test
    public void findByNpiTest()
    {
      List result = generalInfoServiceByNpiService.findByNpi("123");
      assertNotNull(result);
    }
	
	
	@Test
    public void findByNpiDaoCallTest()
    {
      generalInfoServiceByNpiService.findByNpi("123");
      verify (generalInfoServiceByNpiDao, times(1)).findByNpi("123");
    }
	
	
}
