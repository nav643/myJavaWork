package com.us.mn.state.mnits.pasa.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;


@Configuration
@PropertySource(value="classpath:validation.properties", name="valid.props")
public class validationPropertiesFile {

	public static void main(String[] args) throws IOException {
	
		//in = new FileInputStream("C:\\Users\\pwmxy04\\workspace\\PASA\\pasa\\src\\main\\resources\\messages\\validation.properties");	//
		//in = new FileInputStream(getClass().class.getResource("/messages/validation.properties")));
		InputStream in = ObjectFieldsAndPropertyFiles.class.getResourceAsStream("/messages/validation.properties");		//validation.properties or valid.props
		Properties props = new Properties();
	    props.load(in);
	    for(Object key : props.keySet()){
		   System.out.println(props.get(key));
		}
    }
}
