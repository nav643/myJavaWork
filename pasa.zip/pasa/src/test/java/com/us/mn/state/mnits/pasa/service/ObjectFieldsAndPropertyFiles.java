package com.us.mn.state.mnits.pasa.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;

//import org.apache.commons.beanutils.PropertyUtils;

import java.util.Collection;
import java.util.HashSet;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;

import com.us.mn.state.mnits.pasa.model.AuthForm;



@Configuration
@PropertySource(value="classpath:validation.properties", name="valid.props")

public class ObjectFieldsAndPropertyFiles {
    @Autowired
	static Environment env;
    
    private String firstProperty;
    private String secondProperty;


    public String getFirstProperty() {
        return firstProperty;
    }

    public void setFirstProperty(String firstProperty) {
        this.firstProperty = firstProperty;
    }

    public String getSecondProperty() {
        return secondProperty;
    }

    public void setSecondProperty(String secondProperty) {
        this.secondProperty = secondProperty;
    }

    
    public static void main(String[] args) {
    	final File f = new File(ObjectFieldsAndPropertyFiles.class.getProtectionDomain().getCodeSource().getLocation().getPath());
    	System.out.println(f.getPath());  	
    	
    	System.out.println("************ printing absolute Path **************");
    	String absolutePath = new File(".").getAbsolutePath();
    	System.out.println(absolutePath);
    	
    	//Class path!
    	System.out.println("************ printing CLASSPATH **************");
    	String classpath = System.getProperty("java.class.path");
    	System.out.println(classpath);
    	
    	System.out.println("************ printing class path array **************");
    	String[] classpathEntries = classpath.split(File.pathSeparator);
    	for (int i=0; i<classpathEntries.length; i++) {    	System.out.println(classpathEntries[i]); }
    	
    	System.out.println("************ printing class path as list array **************");
    	//List props = classpathEntries.
    	
    	oldWay();
    	//newWay();
        
        //Give me all fields of AuthForm Object
        //listObjectFieldNames();
        
    }

	/**
	 * 
	 */
	protected static void oldWay() {
		InputStream in;
		
    	try {
    		//in = new FileInputStream("C:\\Users\\pwmxy04\\workspace\\PASA\\pasa\\src\\main\\resources\\messages\\validation.properties");	//
    		//in = new FileInputStream(getClass().class.getResource("/messages/validation.properties")));
    		in = ObjectFieldsAndPropertyFiles.class.getResourceAsStream("/messages/validation.properties");		//validation.properties or valid.props
    		Properties props = new Properties();
	        props.load(in);
	        for(Object key : props.keySet()){
			   System.out.println(props.get(key));
			}
	        
		} catch (FileNotFoundException fe) {
			// TODO Auto-generated catch block
			fe.printStackTrace();
		} catch (IOException ioe) {
			// TODO Auto-generated catch block
			ioe.printStackTrace();
		}
	}

    
    private static void newWay(){
        try {
			AbstractEnvironment ae = (AbstractEnvironment) env;
			@SuppressWarnings("rawtypes")
			org.springframework.core.env.PropertySource source = ae.getPropertySources().get("valid.props");
			
			Properties props = (Properties)source.getSource();
			
			for(Object key : props.keySet()){
			   System.out.println(props.get(key));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
	/**
	 * @throws SecurityException
	 */
	protected static void listObjectFieldNames() throws SecurityException {
		//ObjectWithSomeProperties object = new ObjectWithSomeProperties();
    	AuthForm object = new AuthForm();
        
		// Load all fields in the class (private included)
        Field [] attributes =  object.getClass().getDeclaredFields();

        for (Field field : attributes) {
            // Dynamically read Attribute Name
            System.out.println("ATTRIBUTE NAME: " + field.getName());

            try {
                // Dynamically set Attribute Value
                //PropertyUtils.setSimpleProperty(object, field.getName(), "A VALUE");
                //System.out.println("ATTRIBUTE VALUE: " + PropertyUtils.getSimpleProperty(object, field.getName()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
	}
    

}
