package com.us.mn.state.mnits.pasa.web;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.GenericValidator;
//import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
//import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import us.mn.state.dhs.caps.schema.ErrorStructure;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.us.mn.state.mnits.pasa.helper.AuthConstants;
import com.us.mn.state.mnits.pasa.helper.AuthResponseForm;
import com.us.mn.state.mnits.pasa.helper.AuthUtility;
import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.ServiceInformation;
import com.us.mn.state.mnits.pasa.model.Subscriber;
import com.us.mn.state.mnits.pasa.service.PriorAuthorizationService;
import com.us.mn.state.mnits.pasa.validator.AuthFormValidator;



@Controller
public class PASAController {

	private final Logger logger = LoggerFactory.getLogger(PASAController.class);
	private boolean isDebug = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;
	private boolean isLowerRegions = false;

	@Autowired
	AuthFormValidator priorAuthFormValidator;


	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(priorAuthFormValidator);
	}

	  
	private PriorAuthorizationService pasaService;

	@Autowired
	public void setAuthorizationService(PriorAuthorizationService pasaService) {
		this.pasaService = pasaService;
	}

	@RequestMapping(value = "/version", method = RequestMethod.GET)
	public String getVersion( HttpServletRequest request, Model model) throws IOException {
		
		
//		InputStream is = this.getClass().getClassLoader().getResourceAsStream("META-INF/maven/com.us.mn.state.mnits/pasa/pom.xml");
//		BufferedReader buffReader = new BufferedReader(new InputStreamReader(is));
//		String contents = buffReader.lines().collect(Collectors.joining(System.lineSeparator()));
//		System.out.println(contents);
		
//		MavenXpp3Reader reader = new MavenXpp3Reader();
//        org.apache.maven.model.Model mavenModel = reader.read(buffReader);
//        System.out.println(mavenModel.getId());
//        System.out.println(mavenModel.getGroupId());
//        System.out.println(mavenModel.getArtifactId());
//        System.out.println(mavenModel.getVersion());
        
        // If you want to get fancy:
        //model.getDependencies().stream().forEach(System.out::println); 
		

		String fileName = "/version.txt";
		String line = getVersionFileAsStream(fileName);

		model.addAttribute("sessionUserID", getSessionUserId(request));
		model.addAttribute("msg", "Showing the application version");
		model.addAttribute("appVersion", line);
    	return "version";
	}

	private String getVersionFileAsStream(String fileName) {
		System.out.println("getResourceAsStream : " + fileName);
		InputStream is = getFileFromResourceAsStream(fileName);
		String line = "";

		try (InputStreamReader streamReader = new InputStreamReader(is,
				StandardCharsets.UTF_8);
				BufferedReader reader = new BufferedReader(streamReader)) {

			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return line;
	}
	
	
    // get a file from the resources folder
    // works everywhere, IDEA, unit test and JAR file.
    private InputStream getFileFromResourceAsStream(String fileName) {

        // The class loader that loaded the class
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(fileName);

        // the stream holding the file content
        if (inputStream == null) {
            throw new IllegalArgumentException("file not found! " + fileName);
            //handleMissingParams(authForm, result, model, request, e)
        } else {
            return inputStream;
        }

    }
	
	
	
	
	
	//An Errors/BindingResult argument is expected to be declared immediately after the model attribute, the @RequestBody or the @RequestPart arguments to which they apply
	//save(@ModelAttribute("authForm") @Validated AuthForm authForm, BindingResult result, Model model, HttpServletRequest request
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String update(@ModelAttribute("authForm") AuthForm authForm, BindingResult result, Model model, HttpServletRequest request ) {
		logger.debug("in edit()/update() : {GET}");
		
		//if form has timed out, call the get method for /authPA -- not the post method
		String dhsnpi = request.getHeader("dhsnpi");
		if (dhsnpi == null || StringUtils.isEmpty(dhsnpi)) {	//if (authForm == null || request.getSession(false)==null) { 		// || !request.isRequestedSessionIdValid()
			logger.debug("In /edit Get() --> Form or Session not valid and is in the EDIT mode but has to be redirecting to GET since dhsnpi is null or empty");
			return "redirect:/authPA"; 
		} else {
			logger.debug("In /edit Get() --> Session is valid after hitting MMIS, getting some error codes but being ignored for further processing");
		}
		
		model.addAttribute("sessionUserID", this.getSessionUserId(request));
		model.addAttribute("NPIEnabled", this.getSessionUserRoleInfo(request));
		if (isDebug) { logger.debug("Back in /edit Get() --> after getting the session details mentioned above"); }
		System.out.println("Back in /edit Get() --> after getting the session details mentioned above");
		
		if (result.hasErrors()) {
			logger.debug("In /edit Get() --> Binding errors encountered");
			model.addAttribute("css", "info");
			model.addAttribute("msg", "EDIT Page - Validation ERRORS");

			if (isDebug) {	
				int index = 0;
				for (ObjectError error : result.getAllErrors()) {
					index++;
					logger.error("Error " + index + ": \n" + 
						error.toString()	//Error 1: Field error in object 'authForm' on field 'pe.diagnosisCodes': rejected value [[]];
											//codes [NotEmpty.authForm.diagnosisCodes.authForm.pe.diagnosisCodes,NotEmpty.authForm.diagnosisCodes.pe.diagnosisCodes,
											//NotEmpty.authForm.diagnosisCodes.diagnosisCodes,NotEmpty.authForm.diagnosisCodes.java.util.List,NotEmpty.authForm.diagnosisCodes]; 
											//arguments []; default message [null]
					);
				}
			}
			model.addAttribute("exception", result.getErrorCount());

			return "main";
		} else {
			//Happy Path - No binding errors, let's edit the form
			if (isDebug) { logger.debug("In /edit Get() --> Happy Path in EDIT/update mode - no binding errors found hence moving along"); }

			//This is a get call, must get the form here	
			AuthForm authFormToEdit = (AuthForm) request.getSession().getAttribute("authForm");
			AuthResponseForm responseForm = authFormToEdit.getResponseForm();
			
			System.out.println("Since this is EDIT page -> ID: " + responseForm.getConfirmation_id());
			System.out.println("Since this is EDIT page -> deferred: " + responseForm.isDeferred());
			System.out.println("Since this is EDIT page -> invalid: " + responseForm.isPaInvalid());
			System.out.println("Since this is EDIT page -> denied: " + responseForm.isPaDenied());
			System.out.println("Since this is EDIT page -> AdlInfo: " + responseForm.isPaAddInfoRequired());
			
			//update these fields
			responseForm.setConfirmation_id((String) request.getSession().getAttribute("PAnum"));
			responseForm.setDeferred(false);
			
			if (isDebug) { logger.debug("In /edit Get() --> Happy Path in EDIT/update mode - leaving the method"); }
			model.addAttribute("authForm", authFormToEdit);
	    	return "main";
		}
	}
	
	
	
	@RequestMapping(value = "/IgnoreErrorsContinue", method = RequestMethod.GET)
	public String IgnoreErrorsAndContinue(Model model, HttpServletRequest request) throws MalformedURLException {
		logger.debug("IgnoreErrorsContinue()");
		
		String dhsnpi = request.getHeader("dhsnpi");
		if (dhsnpi == null || StringUtils.isEmpty(dhsnpi)) {	//if (request.getSession(false)==null)  {  //|| !request.isRequestedSessionIdValid()
			logger.debug("Session not valid hence redirecting to GET since dhsnpi is null or empty");
			return "redirect:/authPA"; 
		} else {
			logger.debug("Session is valid after hitting MMIS, getting some error codes but being ignored for further processing");
		}
			
		AuthForm authForm = (AuthForm) request.getSession().getAttribute("authForm");
		
		model.addAttribute("sessionUserID", this.getSessionUserId(request));
		model.addAttribute("NPIEnabled", this.getSessionUserRoleInfo(request));
		authForm.getResponseForm().setConfirmation_id((String) request.getSession().getAttribute("PAnum"));

		// call services
		try {
			getServiceResponse(authForm);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (authForm.getAuthErrorsArrayList().size() == 0) {
			//Happy Path  no validation errors
			if (isDebug) {	logger.debug("Happy path in ignoreErrorsContinue - Session is continuing after getting the service Response again"); }
			request.getSession().setAttribute("PAnum", authForm.getResponseForm().getConfirmation_id());
			if (isDebug) {
				model.addAttribute("css", "success");
				model.addAttribute("msg", "return PA - RESUBMIT");
			}
			
			StringBuffer procedureCodes = new StringBuffer();
			List<ServiceInformation> serviceInfo = authForm.getServices();

			for (ServiceInformation serviceLineItem : serviceInfo) {
				if (procedureCodes.length() == 0)   { 
					procedureCodes.append(serviceLineItem.getProcedureCode());
				} else { 
					procedureCodes.append(", " + serviceLineItem.getProcedureCode());
				}
			}
			procedureCodes.trimToSize();
			logger.debug("Procedure Codes: " + procedureCodes.toString());

			model.addAttribute("ProcedureCodes", procedureCodes.toString());
			model.addAttribute("subscriberId", authForm.getSub().getSubscriberId());
			model.addAttribute("PAnum", authForm.getResponseForm().getConfirmation_id());

			model.addAttribute("authForm", authForm);

			return "success";
		} else {
			if (isDebug) {
				model.addAttribute("css", "info");
				model.addAttribute("msg", "Validation ERRORS");
			}

			StringBuffer errorsBlock = new StringBuffer();
			isLowerRegions = figureOutDevRegion(request);
			if (authForm.getAuthErrorsArrayList() != null) {
				ArrayList<ErrorStructure> errorList = authForm.getAuthErrorsArrayList();
				for (ErrorStructure currentError : errorList) {
					errorsBlock.append("<li>" + currentError.getErrorCode() + " " + currentError.getErrorDescription() + "</li>");
					if (isDebug) {
						logger.debug("Adding internal remark and description for internal debugging purpose");
						logger.debug(currentError.getErrorRemark() + "  " + currentError.getErrorInternalDescription());
					}
					if (isLowerRegions) {
						errorsBlock.append("<li>" + currentError.getErrorRemark() + "  " + currentError.getErrorInternalDescription() + "</li>");
					}
				}
				
				if (isDebug) {
					model.addAttribute("css", "danger");
					model.addAttribute("msg", "return PA - RESUBMIT");
				}
				
				model.addAttribute("errorsBlockList", errorsBlock.toString());
				model.addAttribute("MMIScode", "PA_INVALID"); // responseForm.getResponseForm().getPAServiceResponseCode()
				model.addAttribute("authForm", authForm);
				
				request.getSession().setAttribute("PAnum", authForm.getResponseForm().getConfirmation_id());
				request.getSession().setAttribute("authForm", authForm);
			}

			return "fail";
		}
		
	}

	
	
private boolean figureOutDevRegion(HttpServletRequest request) throws MalformedURLException {
	
	//request.getHeader("Host").indexOf("localhost:8080/") > -1 | request.getHeader("Host").indexOf("mn-its-dev.") > -1)
	//<c:set var="baseURL" value="${pageContext.request.localName}"/> //or ".localAddr"
    URL requestURL = new URL(request.getRequestURL().toString());
    String port = requestURL.getPort() == -1 ? "" : ":" + requestURL.getPort();
    String info = requestURL.getProtocol() + "://" + requestURL.getHost() + port;
    boolean response = false;

    request.getLocalName();     
    response = requestURL.toString().indexOf("localhost:8080/") > -1;
    response = request.getHeader("Host").indexOf("mn-its-dev.") > -1;
    //response = request.getHeader("Host").indexOf("mn-its-stst.") > -1;
    
	logger.debug("Local or DEV region has been found ... DATA will be prefilled AND EXTRA ERROR CODE info will be printed ");
    
	return response;
}

/**************** debug only ************************
	@RequestMapping(value = "/fail", method = RequestMethod.GET)
	public String fail(Model model, HttpServletRequest request) {
		logger.debug("fail()");
		
		return "fail";
	}
	
	
	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public String success(Model model, HttpServletRequest request) {
		logger.debug("success()");
		
		return "success";
	}
***************************************************************/	
	
	
	// authorize - GET
	@RequestMapping(value = "/authPA", method = RequestMethod.GET)
	public String authorization(Model model, HttpServletRequest request, AuthForm authForm) {
		
		logger.debug("authorization() :  {GET}");
		//if form has timed out, call the get method for /authPA -- not the post method
		
		logger.debug("findNpi()");
		String sessionNpi = request.getHeader("dhsnpi");
		
		// TODO This if statement is for local environment
		if (sessionNpi == null || sessionNpi.length() == 0) {
			sessionNpi = "A342517700";
		    HttpSession session = request.getSession();
		    session.setMaxInactiveInterval(1500);    // session timeout in 1500 seconds = 25 minutes
		} else {
			request.getSession().setMaxInactiveInterval(900);	//900 seconds = 15 minutes
		}
		
		if (isDebug) {
			logger.debug("Session User_NPI: '" + sessionNpi + "' in PASA app for user " + getSessionUserId(request));
			this.getSessionUserRoleInfo(request);
	
			//certain relevant info
			AuthUtility.printHttpHeaders(request);
		    //AuthUtility.listTheBrowser(request);
		}

	    model.addAttribute("sessionNpi", sessionNpi);
	    model.addAttribute("NPIEnabled", this.getSessionUserRoleInfo(request));
		model.addAttribute("sessionUserID", this.getSessionUserId(request));
		
		model.addAttribute("css", "info");
		model.addAttribute("msg", "");
		
		if (authForm == null) {
			model.addAttribute("authForm", new AuthForm());
		} else {
			model.addAttribute("authForm", authForm);
		}
	    
		return "main";
	}


	// authorize - POST - save INFO
	@SuppressWarnings("unchecked")
	@RequestMapping(value = {"/authPA", "/edit"}, method = RequestMethod.POST)
	public String save(@ModelAttribute("authForm") @Validated AuthForm authForm, BindingResult result, Model model, HttpServletRequest request) throws MalformedURLException {
		
		logger.debug("authorization() : {POST} using /authPA or /edit");
		//if form has timed out, call the get method for /authPA -- not the post method
		
		if (isDebug) {
			logger.debug("Request Id (Legacy Id): " + authForm.getRequestId());
			HttpSession session = request.getSession(); 
		    //session.setMaxInactiveInterval(30);    // session timeout in seconds
		}
		
		//TODO add all validations with @validated
		//@RequestParam("sub.DOB")  @DateTimeFormat(pattern = "yyyy-MM-dd") Date dob mm/dd/yyyy -> yyyy-MM-dd
		
		//TODO- Until further solution - clean up above two fields	    
//	    if (authForm.getSvc() != null) {
////			if (authForm.getServices().size() > 0) {
////				String cleanup = authForm.getSvc().getModifiers().toString();
////				authForm.getSvc().getModifiers().clear();
////				authForm.getSvc().getModifiers().add(0, cleanup.substring(cleanup.indexOf(',')+1, cleanup.length()-1).trim());
////			}	    	
//	    	
//	    	if (authForm.getSvc().getDentalInformation().getToothSurfaceCodes().size()  > 0 ) {
//				List<String> toothSurfaceCodes = authForm.getSvc().getDentalInformation().getToothSurfaceCodes();
//				List<String> dataUpdated = new ArrayList<String>();
//				
//				System.out.println("tooth surface codes: " + toothSurfaceCodes.toString());
//				for (String code: toothSurfaceCodes) {
//					if (! StringUtils.isEmpty(code)) {	dataUpdated .add(code.trim());	}	
//				}
//				authForm.getSvc().getDentalInformation().setToothSurfaceCodes(dataUpdated);
//				System.out.println("Clean up surface codes: " + dataUpdated.toString());
//			}
//			
//	    	if (authForm.getSvc().getDentalInformation().getOralCavityDesignation().size()  > 0 ) {
//				List<String> cavityDesignations = authForm.getSvc().getDentalInformation().getOralCavityDesignation();
//				List<String> dataUpdated = new ArrayList<String>();
//				
//				System.out.println("tooth cavities: " + cavityDesignations.toString());
//				for (String code: cavityDesignations) {
//					if (! StringUtils.isEmpty(code)) {	dataUpdated .add(code.trim());	}	
//				}
//				authForm.getSvc().getDentalInformation().setOralCavityDesignation(dataUpdated);
//				System.out.println("Clean up cavities " + dataUpdated.toString());
//			}
//	    }
	    	
////	    	if (authForm.getSvc().getDentalInformation().getOralCavityDesignation().size() > 0) {
////				String cleanup = authForm.getSvc().getDentalInformation().getOralCavityDesignation().toString();
////				authForm.getSvc().getDentalInformation().getOralCavityDesignation().clear();
////				authForm.getSvc().getDentalInformation().getOralCavityDesignation().add(0, cleanup.substring(cleanup.indexOf(',')+1, cleanup.length()-1).trim());
////			}
//			
//			if (isDebug) {
//				//need to fix this with yousuf soon
//				//need to fix the tabs length on the top
//				//need to fix
//				logger.debug("Cavity: " + authForm.getSvc().getDentalInformation().getToothSurfaceCodes());
//				logger.debug("Tooth surface: " + authForm.getSvc().getDentalInformation().getOralCavityDesignation());
//			}
//	    }
	    
		
		

			//Translate my objects into correct format for processing
			
		//List<ServiceInformation> serviceList = mapper.readValue(authForm.getServiceLineItems(), (new ArrayList<ServiceInformation>()).getClass());
		int serviceLineItemsCount = authForm.getServiceLineItems().length();
		List<ServiceInformation> serviceLineItemsList = null;
		
		//TODO - Stringify JSON for service line items
			
		if (serviceLineItemsCount > 0) {
			try {
				ObjectMapper mapper = new ObjectMapper();
			    //Set default time zone as JVM timezone due to one day difference between original date and formatted date.
				//mapper.setTimeZone(TimeZone.getDefault());
				serviceLineItemsList = mapper.readValue(authForm.getServiceLineItems(), new TypeReference<List<ServiceInformation>>() { });
			} catch (InvalidFormatException ife) {
				// TODO Auto-generated catch block
				logger.debug(ife.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//CollectionType javaType = mapper.getTypeFactory().constructCollectionType(List.class, ServiceInformation.class);     
			//List<ServiceInformation> asList1 = mapper.readValue(authForm.getServiceLineItems(), javaType);
			
			//Get some fields ready for processing
			for (ServiceInformation serviceLineItem: serviceLineItemsList) {
				
				DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
				//get the begin dates
				try {
					if (serviceLineItem.getBeginDate() != null && !StringUtils.isEmpty(serviceLineItem.getBeginDate().toString())){
					    //boolean isDateValid = GenericValidator.isDate(,"MM/dd/yyyy", false);
						Date fieldToProcess = serviceLineItem.getBeginDate();
						if (isDateValid(fieldToProcess.toString())) {
							serviceLineItem.setBeginDate(formatter.parse(fieldToProcess.toString()));
						}
					}
					
					//get the end dates
					if (serviceLineItem.getEndDate() != null && !StringUtils.isEmpty(serviceLineItem.getEndDate().toString())){
						Date fieldToProcess = serviceLineItem.getEndDate();
						if (isDateValid(fieldToProcess.toString())) {
							serviceLineItem.setEndDate(formatter.parse(fieldToProcess.toString()));
						}
					}
				} catch (ParseException e) {
					
					//date formatter related parsing exceptions
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		    	if (serviceLineItem.getDentalInformation().getToothSurfaceCodes().size()  > 0 ) {
					List<String> toothSurfaceCodes = serviceLineItem.getDentalInformation().getToothSurfaceCodes();
					List<String> dataUpdated = new ArrayList<String>();
					
					System.out.println("tooth surface codes: " + toothSurfaceCodes.toString());
					for (String code: toothSurfaceCodes) {
						if (! StringUtils.isEmpty(code)) {	dataUpdated .add(code.trim());	}	
					}
					serviceLineItem.getDentalInformation().setToothSurfaceCodes(dataUpdated);
					System.out.println("Clean up surface codes: " + dataUpdated.toString());
				}
				
		    	if (serviceLineItem.getDentalInformation().getOralCavityDesignation().size()  > 0 ) {
					List<String> cavityDesignations = serviceLineItem.getDentalInformation().getOralCavityDesignation();
					List<String> dataUpdated = new ArrayList<String>();
					
					System.out.println("tooth cavities: " + cavityDesignations.toString());
					for (String code: cavityDesignations) {
						if (! StringUtils.isEmpty(code)) {	dataUpdated .add(code.trim());	}	
					}
					serviceLineItem.getDentalInformation().setOralCavityDesignation(dataUpdated);
					System.out.println("Clean up cavities " + dataUpdated.toString());
				}
			}
			authForm.setServices(serviceLineItemsList);
		} else {
			logger.debug("No line items found to process");
			//authForm.setServices(null);
		}


		//get session user ID and other role based info?
		model.addAttribute("sessionUserID", this.getSessionUserId(request));
		model.addAttribute("NPIEnabled", this.getSessionUserRoleInfo(request));
		
		//process binding errors
		if (result.hasErrors()) {
			
			//**********MANAGE VALIDATION ERRORS *********
			StringBuffer errorList = new StringBuffer();
			logger.debug("Ready to show binding errors");
			printErrors(result, errorList);
			
			//"Validation Errors - Please read them below"+"<br>"+
			model.addAttribute("css", "danger");
			model.addAttribute("msg", errorList.toString());
			model.addAttribute("isDebug", false);


			if (isDebug) {
				//print validation errors one by one and TODO: massage them as needed for showing on the front page in red alarm CSS msg box
				
				String dataForTroubleShooting = listClassLoaders();
				model.addAttribute("loadedClasses", dataForTroubleShooting);
				model.addAttribute("isDebug", false);
			} else {	
				
				//All good to go
				//model.addAttribute("msg", result.getErrorCount() + " validation errors need your attention");
				for (ObjectError error : result.getAllErrors()) {
					errorList.append(error.getCode()+"\n");
				}
			}
			
			return "main";
		} else {
			//no validation errors - YAY
			if (isDebug) {
				System.out.println("DOB " + authForm.getSub().getDOB());
				System.out.println("Event " + authForm.getPe().getEventDate());
				System.out.println("begin " + authForm.getSvc().getBeginDate());
				System.out.println("end " + authForm.getSvc().getEndDate());
/*				try {
					SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
					//Display dates here but getting parse errors - Unparseable date: "Thu Jan 24 00:00:00 CST 1980" at com.us.mn.state.mnits.pasa.web.PASAController.save(PASAController.java:476)
					System.out.println("DOB " + authForm.getSub().getDOB() + " -> " + myFormat.format(myFormat.parse(authForm.getSub().getDOB().toString())));
					System.out.println("Event " + authForm.getPe().getEventDate());
					System.out.println("begin " + authForm.getSvc().getBeginDate() + " -> " + myFormat.parse(authForm.getSvc().getBeginDate().toString()));
					System.out.println("end " + authForm.getSvc().getEndDate());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			}
			
			
			//Get ready for the response
			AuthForm responseForm = new AuthForm();
		   
			//call the right service (PA, SA) and get back the response
			try {
				logger.debug("Calling the PA/SA service -> getServiceResponse(authForm)");
					responseForm = getServiceResponse(authForm);
				logger.debug("Service has returned data (getServiceResponse(authForm)).  Initializing new error object - unnecessarily! ");
				//ArrayList<ErrorStructure> testList = new ArrayList<ErrorStructure>();
				//testList.add(new ErrorStructure());
				//responseForm.setAuthErrorsArrayList(testList);
			} catch (Exception e) {
				logger.debug("ran into errors while Calling the PA/SA service -> getServiceResponse(authForm)");
				e.printStackTrace();
			}

			if (isDebug) {
				//creating a fake response form object and PANum just to get thru the errors
				responseForm.setResponseForm(new AuthResponseForm()); 
				responseForm.getResponseForm().setConfirmation_id("0123456789");
				responseForm.getResponseForm().setPAServiceResponseCode("PA_INVALID");	//PA_LOCAL_PASA_USER
			}
			
			request.getSession().setAttribute("PAnum", responseForm.getResponseForm().getConfirmation_id());
			
			logger.debug("Error list size: " + responseForm.getAuthErrorsArrayList().size());
			
			//NOW check for response for errors FROM MMIS
			String view = processErrorsFromMMIStoBuildResponse(authForm, model, request, responseForm);
			
			return view;
		}	//line 490
		//return "main";
	}

	private String processErrorsFromMMIStoBuildResponse(AuthForm authForm,
			Model model, HttpServletRequest request, AuthForm responseForm)
			throws MalformedURLException {
		String response;
		
		if (responseForm.getAuthErrorsArrayList().size() == 0 && !responseForm.getResponseForm().isPaInvalid()) {
			logger.debug("HAPPY PATH - NO MMIS errors occured: ");
			//*********HAPPY PATH***************
			if (isDebug) {
				model.addAttribute("css", "success");
				model.addAttribute("msg", "return PA - FROM TEST DATA in LOCAL but real data in other environments");
				model.addAttribute("isDebug", false);
			}

			model.addAttribute("subscriberId", responseForm.getSub().getSubscriberId());
			model.addAttribute("PAnum", responseForm.getResponseForm().getConfirmation_id());

			StringBuffer procedureCodes = new StringBuffer();
			List<ServiceInformation> serviceInfo =  responseForm.getServices();

			for (ServiceInformation serviceLineItem : serviceInfo) {
				if (procedureCodes.length() == 0)   { 
					procedureCodes.append(serviceLineItem.getProcedureCode());
				} else { 
					procedureCodes.append("<br>" + serviceLineItem.getProcedureCode());
				}
			}
			procedureCodes.trimToSize();
			logger.debug("Procedure Codes: " + procedureCodes.toString());

			model.addAttribute("ProcedureCodes", procedureCodes.toString());
			model.addAttribute("authForm", responseForm);
			//if (isDebug) { return "fail"; } else { return "success"; }
			response =  "success";
		} else {
			//******** FIX ERRORS FROM MMIS AND SHOW 5 OPTIONS ON FAIL SCREEN ********
			logger.debug("Service response was Invalid or MMIS errors occured: ");
			StringBuffer errorsBlock = new StringBuffer();
			isLowerRegions = figureOutDevRegion(request);
			//if (responseForm.getAuthErrorsArrayList() != null) {
				ArrayList<ErrorStructure> errorList = responseForm.getAuthErrorsArrayList();
				logger.debug("ErrorList object is formed for: " + errorList.size() + " errors/codes");

				for (ErrorStructure currentError : errorList) {
					if (currentError.getErrorCode().equals("45")) {
						errorsBlock.append("<li>" + currentError.getErrorInternalDescription() + "</li>");
					} else {
						if (isDebug) {
							errorsBlock.append("<li>" + 
								currentError.getErrorCode()  + " " + currentError.getErrorDescription() + "   " +
								currentError.getErrorRemark()  + "/" + currentError.getErrorInternalStatus() + "|" +
								currentError.getErrorInternalStatus()  + "/" + currentError.getErrorInternalDescription() +
											"</li>");
								//This request is incomplete or invalid (${ MMIScode }). The claim status codes below will provide additional information.
							logger.debug("Adding internal remark and description for debugging purpose");
							logger.debug(currentError.getErrorRemark() + "  " + currentError.getErrorInternalDescription());
						} else {
							errorsBlock.append("<li>" + currentError.getErrorCode()  + " " + currentError.getErrorDescription());
							//This request is incomplete or invalid. The claim status codes below will provide additional information.
							
							if (isLowerRegions) {
								logger.debug("Printing extra error code info (internal remark and description) for debugging purpose");
								if (!currentError.getErrorDescription().contains("ERRMSC System Error")) {
									errorsBlock.append("  --><b>more info</b>---" + currentError.getErrorRemark() + "  " + currentError.getErrorInternalDescription() + "---");
								} else if (currentError.getErrorDescription().contains("ERRJMS")) {
									errorsBlock.append("  --><br><b>more info</b>---" + currentError.getErrorRemark() + "  " + currentError.getErrorInternalDescription() + "---");
								} //else {}
							}
							errorsBlock.append("</li>");
						}
					}
				}
				
				if (isDebug) {
					authForm.setResponseForm(responseForm.getResponseForm());
					model.addAttribute("css", "danger");
					model.addAttribute("msg", "return PA - FROM TEST DATA");
					model.addAttribute("isDebug", false);
				}
				
				if (isLowerRegions) {
					logger.debug("Dump all this info in the log ...." + errorsBlock.toString());
				}

//					******** IF USES CHOOSES TO IGNORE ERRORS, FOLLOWING 3 FIELDS MUST BE SET ************
//			        <AuthResponseXML>
//			            <confirmation_id>02169402003</confirmation_id>
//			            <deferred>false</deferred>
//			            <PAServiceResponseCode>PA_DEFAULT</PAServiceResponseCode>
//		            </AuthResponseXML>
		        
				model.addAttribute("errorsBlockList", errorsBlock.toString());
				model.addAttribute("MMIScode", responseForm.getResponseForm().getPAServiceResponseCode());	
				//responseForm.getResponseForm().getPAServiceResponseCode()
				//model.addAttribute("authForm", authForm);	
				
				request.getSession().setAttribute("PAnum", responseForm.getResponseForm().getConfirmation_id());
				request.getSession().setAttribute("authForm", authForm);
			//}
			response =  "fail";
		}
		return response;
	}


	/** METHOD CALLING THE SERVICES FOR MMIS
	 * @param authForm
	 * @param responseForm
	 */
	protected AuthForm getServiceResponse(AuthForm authForm) throws Exception{
		if (authForm.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA)) {
			logger.debug("Before HCSA Submission from MVC Controller");
			
			//HCSA service for Home health Care
			authForm.setValidRequest(true);
			pasaService.doServiceAuthorization(authForm);
			logger.debug("After HCSA Submission from MVC Controller & " + authForm.getAuthErrorsArrayList().size() + " MMIS errors to report");

		} else {
			logger.debug("Before PA Submission from MVC Controller");
			
			//PA service for other 3 menu items
			authForm.setValidRequest(true);
			pasaService.doPriorAuthorization(authForm);
			logger.debug("After PA Submission from MVC Controller & " + authForm.getAuthErrorsArrayList().size() + " MMIS errors to report");
		}
		
		return authForm;
	}


	// *************** HELPER FUNCTIONS *****************

	private void printErrors(BindingResult result, StringBuffer errorList) {
		// TODO print following errors in debug console
		int index = 0;
		for (ObjectError error : result.getAllErrors()) {
			index++;
			logger.error("Error " + index + ": \n" + 
				error.toString()	//Error 1: Field error in object 'authForm' on field 'pe.diagnosisCodes': rejected value [[]];
									//codes [NotEmpty.authForm.diagnosisCodes.authForm.pe.diagnosisCodes,NotEmpty.authForm.diagnosisCodes.pe.diagnosisCodes,
									//NotEmpty.authForm.diagnosisCodes.diagnosisCodes,NotEmpty.authForm.diagnosisCodes.java.util.List,NotEmpty.authForm.diagnosisCodes]; 
									//arguments []; default message [null]
				
//		} catch (IllegalArgumentException ile) {
//			ile.printStackTrace();
//			System.out.println(ile.getCause());
//			System.out.println(ile.getMessage());
//			System.out.println(ile.getLocalizedMessage());
//			
//			errors.reject("Date field is invalid");
//			
//			//Failed to convert property value of type 'java.lang.String' to required type 'java.util.Date' for property 'svc.beginDate'; 
//			//nested exception is org.springframework.core.convert.ConversionFailedException: 
//			//Failed to convert from type [java.lang.String] to type [@org.springframework.format.annotation.DateTimeFormat 
//			//@com.fasterxml.jackson.annotation.JsonFormat java.util.Date] for value '19/07/2020'; 
//			//nested exception is java.lang.IllegalArgumentException: Parse attempt failed for value [19/07/2020]
		
			);
		}
		
		//massage this validation error message for the red msg box on the website
		logger.error("Also getting ErrorList prepared for the website validation messages \n"); 
		InputStream in = getClass().getResourceAsStream("/messages/validation.properties");		//validation.properties or valid.props;
		Properties props = new Properties();
		boolean illegalArgumentException = false;
		boolean conversionFailedException = false;
        
    	try {
    		//in = new FileInputStream("C:\\Users\\pwmxy04\\workspace\\PASA\\pasa\\src\\main\\resources\\messages\\validation.properties");	//
    		//in = new FileInputStream(getClass().class.getResource("/messages/validation.properties")));
    		props.load(in);
    		int i=0;
	        //for(Object key : props.keySet()){ 		
	        	//System.out.println(props.get(key));
		        for (ObjectError oError : result.getAllErrors()) {
		        	if (!StringUtils.isEmpty(oError.getCode())) {	
						String message = oError.getDefaultMessage();
						if (message != null) {
							illegalArgumentException = message.contains("IllegalArgumentException");
							conversionFailedException= message.contains("org.springframework.core.convert.ConversionFailedException");
							if (isDebug) { logger.debug("A conversion error is detected for " + oError.getDefaultMessage()); }
						} else {
							illegalArgumentException = false;
							conversionFailedException = false;
							errorList.append(props.get(oError.getCode()) + "<br>");
						}
						if (oError instanceof FieldError) { 
			        		FieldError fieldError = (FieldError) oError;
			        		if (isDebug) { logger.debug("Field " + fieldError.getField() + " for rejected value: " + fieldError.getRejectedValue()); }
							if (fieldError.getCodes().length > 0 && illegalArgumentException && conversionFailedException) {	
								
								//skip the service start and end dates since they need the item number as well
								if (!fieldError.getField().contains("svc.")) { 
									errorList.append(props.get(fieldError.getField()) + "<br>"); 
								}
								//errorList.append("Value " + fieldError.getRejectedValue() + " is invalid. Enter a valid date in the format MM/DD/YYYY "  + "<br>");
							}
						} else {
							errorList.append(oError.getCode() + "<br>"); 	
						}
		        	} else {
		        		if (!StringUtils.isEmpty(oError.getDefaultMessage())) {	errorList.append(oError.getDefaultMessage() +"<br>"); }
		        	}
				} //end of for loop 
				//	

				//System.out.println("Looping for i = "+ i);

		        //System.out.println("Looping "+ i);
		        i++;
			//}
    	} catch (FileNotFoundException fe) {
			// TODO Auto-generated catch block
			fe.printStackTrace();
		} catch (IOException ioe) {
			// TODO Auto-generated catch block
			ioe.printStackTrace();
		}
	}


	// *************** SERVICES TAB BY ITSELF *********************
	@RequestMapping(value = "/services", method = RequestMethod.GET)
	public String services(@ModelAttribute("authForm") AuthForm authForm, Model model) {
		logger.debug("servicesFor()");

		//model.addAttribute("userForm", user);

		//populateDefaultModel(model);

		model.addAttribute("css", "info");
		model.addAttribute("msg", "SA (Service Screen) - FROM TEST DATA");
		model.addAttribute("isServicesPage", true);
		model.addAttribute("authForm", authForm);
		return "authorization";
	}



	// The page will clear the session cookies and redirect to MNITS home page.
	@RequestMapping(value = "/mnitsHome", method = RequestMethod.GET)
	public String mnitsHome(Model model) {
		logger.debug("mnitsHome()");
		return "mnitsHome";
	}

	// This Logout will use MNITS home page logout.jsp to logging out the user.
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(Model model) {
		logger.debug("logout()");
		return "logout";
	}



	@ExceptionHandler(Exception.class)
	public ModelAndView handleMissingParams(Exception e, HttpServletRequest request) {
	   //java.lang.IllegalStateException: An Errors/BindingResult argument is expected to be declared immediately after the model attribute, the @RequestBody or the @RequestPart arguments to which they apply: public java.lang.String com.us.mn.state.mnits.pasa.web.PASAController.update(org.springframework.validation.BindingResult,org.springframework.ui.Model,javax.servlet.http.HttpServletRequest)
		//at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:982)

		logger.debug("In error page()");
		int index = 0;
		
		logger.debug(e.getMessage() + " | " + e.getCause());
		for (StackTraceElement msg : e.getStackTrace()) {
			logger.debug("eLine " + index + ":  " + msg.toString());
			index++;
		}
		
	    ModelAndView mav = new ModelAndView();
	    String sessionUserId = "";
	    String dhsnpi = request.getHeader("dhsnpi");
	    sessionUserId = StringUtils.isEmpty(dhsnpi)  ? "PASA local user" : this.getSessionUserId(request) ; 
	    
	    logger.debug("Exception and realted stack trace will be written in the error JSP page for", sessionUserId);
		mav.addObject("sessionUserID", sessionUserId);
		mav.addObject("css", "danger");
		//mav.addObject("msg", "Here is the Exception and related info");
		mav.addObject("exception", e);
		mav.setViewName("error");
		
		//e.getMessage() and e.getStackTrace() do not work
		//mav.addObject("loadedClasses", dataForTroubleShooting);

		return mav;
	}


	/** for debugging purposes
	 * @param clBuffer
	 */
	protected String listClassLoaders() {
		StringBuffer clBuffer = new StringBuffer();
	    clBuffer.append("Initializing class loading list: \n");
	    clBuffer.append("<br>");

	    ClassLoader cl = ClassLoader.getSystemClassLoader();
        URL[] urls = ((URLClassLoader)cl).getURLs();
        int index=0;

        for(URL url: urls){
            //System.out.println(url.getFile());
            logger.debug(url.getFile());
            clBuffer.append("<b>" + index + ".</b> " + url.getFile() + "\n" + "<br>");
            index++;
        }

        return  clBuffer.toString();
	}



	/**
	 * Get User ID from session
	 *
	 * @param request HttpServletRequest
	 */
	private String getSessionUserId(HttpServletRequest request) {
		String sessionUserID = "";
		try {
			sessionUserID = request.getHeader("ldapuserid");
			if (sessionUserID == null || sessionUserID.length() == 0) {
				//if (isDebug) { 
					sessionUserID = request.getHeader("userid");
					logger.debug("userid from headers -> " + sessionUserID);
					logger.debug("User " + sessionUserID + " has been found for the session. header was unsuccessful hence getting it from the principal object!");
					// Getting the header UserID from the User Principle Object.
					sessionUserID = request.getUserPrincipal().getName();	
					logger.debug("In getSessionUserId() --> User (getUserPrincipal)" + sessionUserID + " has been found for the session. header was unsuccessful hence getting it from the principal object!");
					
				//}
		
				
			} else {
				//sessionUserID = "PASA local User";
				System.out.println("User (ldapuserid) " + sessionUserID + " has been found for the session successfully!");
			}
			
		} catch (Exception ex) { // This exception will happen only on local server.
			// So setting the UserID for local environment.
			sessionUserID = "PASA local User";
			HttpSession session = request.getSession();
		    session.setMaxInactiveInterval(30);
		}
		return sessionUserID;
	}
	
	
	
	//Get needed http headers info
	private Boolean getSessionUserRoleInfo(HttpServletRequest request) {
		String sessionUserID = "";
		String userRole = "";
		String userRoleLevel = "";

		sessionUserID = getSessionUserId(request);
		
		userRole = request.getHeader("mnitsapproles");
		if (userRole == null || userRole.length() == 0) {
			if (isDebug) { 
				logger.debug("Role " + userRole + " has been determined for this user. header was unsuccessful hence getting it from the AuthType object!");
			}
			// Getting the header UserID from the User Principle Object.
			userRole = request.getAuthType();
			System.out.println("userRole request.getHeader(mnitsapproles) didn't generate anything " + userRole); 
		} else {
			logger.debug("In getSessionUserRoleInfo() --> Role " + userRole + " has been determined for this user successfully!");
		}
		
		userRoleLevel = request.getHeader("dhsdeladmrole");
		if (userRoleLevel == null || userRoleLevel.length() == 0) {
			if (isDebug) { 
				logger.debug("Level " + userRoleLevel + " has been determined for this user's role. header was unsuccessful hence getting it from the AuthType object!!");
			}
			// Getting the header UserID from the User Principle Object.
			userRoleLevel = request.getAuthType();
			System.out.println("userRoleLevel request.getHeader(dhsdeladmrole) didn't generate anything. header was unsuccessful hence getting it from the AuthType object! " + userRoleLevel); 
		} else {
			logger.debug("In getSessionUserRoleInfo() --> Level " + userRoleLevel + " has been determined for this user's role level successfully!");
		}

		
		if (isDebug) { 
			logger.debug("Writing this user's relevant info -->" + 
				"dhsdeladmrole: " + userRoleLevel + "\n"						+ //DHSL30 - DHS App Admin
				"| uid: " + sessionUserID + "\n"								+ //MYunus@A342517700
				"| userid: " + request.getHeader("userid") + "\n"				+ //MYunus@A342517700
				"| npinumber: " + request.getHeader("npinumber") + "\n"			+ //A342517700
				"| providerid: " + request.getHeader("providerid") + "\n"		+ //342517700
				"| mnitsapproles: " + request.getHeader("mnitsapproles") + "\n"	+ //newclaim,mbotherresponses,authrequest,mbeligibilityresponses,mbclaimresponses,Interactive,evsEligibility,eligibility,provenrollment,mbproviderdatashare,cmh,mbcntydatashare,mbprovenrollinfo,healthcarehomes,mbauthletters,batchnew,providerlists,mbmcodata,requeststatus
				"| ldapuserid: " + request.getHeader("ldapuserid") + "\n"		+ //MYunus@A342517700
				"| dhsproviderid: " + request.getHeader("dhsproviderid") + "\n"	+ //342517700
				"| dhsnpi: " + request.getHeader("dhsnpi") + "\n"				  //A342517700
			);
		}
		
		//for testing in local host
		//userRoleLevel = "DHSL55 - App Location Admin";
		
		if (!sessionUserID.equals("PASA local User") && (userRoleLevel.indexOf("DHSL50") > -1 ||	userRoleLevel.indexOf("DHSL55") > -1 ||	userRoleLevel.indexOf("DHSL60") > -1)) {
			//This will return a string of either of these values for all of the external Provider users:�
			//"DHSL50 - App Admin";
			//"DHSL55 - App Location Admin";
			//"DHSL60 - App User";
			
			// This if statement is for DHS internal account
			if (request.getHeader("dhsnpi") != null && request.getHeader("dhsnpi").equals("A342517700")) {
				logger.debug("---Running the post for DHS NPI " + request.getHeader("dhsnpi") + "/" + request.getHeader("dhsproviderid") + 
						"/" + request.getHeader("dhsdeladmrole") + " and session timeout for half hour---");
				request.getSession().setMaxInactiveInterval(1800);    // session timeout in seconds
			} else {
				//non DHS user and their npi - HAPPY path for real world
				//request.getSession().setMaxInactiveInterval(900);
				logger.debug("In getSessionUserRoleInfo() --> Running the post for non-DHS NPI " + request.getHeader("npinumber") + "/" + request.getHeader("providerid") + 
						" | user: " + request.getHeader("userid") + " and session timeout for 15 minutes ---");
			}
			logger.debug("In getSessionUserRoleInfo() --> all done, leaving here");
			return true;
		} else {
			if (isDebug) { logger.debug("ID: " + sessionUserID + " timeout: " + request.getSession().getMaxInactiveInterval()); }
			
			//These values are for most of the internal users.
			//"DHSL30 - DHS App Admin";
			//"DHSL40 - DHS App HelpDesk"; 
			return false;
		}
	}



	// Header page to show the HTTP Headers information
	@RequestMapping(value = "/httpHeaders", method = RequestMethod.GET)
	public String httpHeaders(Model model) {
		logger.debug("httpHeaders()");
		return "httpHeaders";
	}


	 private boolean isDateValid(String dateStr) {
	        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	        sdf.setLenient(false);
	        try {
	            sdf.parse(dateStr);
	        } catch (ParseException e) {
	            return false;
	        }
	        return true;
	 }
	 
	//TODO: revisit and add following
	//add dhs to the packages

	private void createSessionUser(HttpServletRequest request) {
		// TODO Auto-generated method stub
		if (request != null) {
			String userID = request.getHeader("userid");
			String userNpi = request.getHeader("dhsnpi");
			String firstName = request.getHeader("givenname");
			String lastName = request.getHeader("sn");
			System.out.println("User_ID: '" + userID + "' in PA/SA app.");
			System.out.println("User_NPI: '" + userNpi + "' in PA/SA app.");
			System.out.println("First_Name: '" + firstName + "' in PA/SA app.");
			System.out.println("Last_Name: '" + lastName + "' in PA/SA app.");
			
			Subscriber subscriber = new Subscriber();
			
			if (userNpi != null && userNpi.trim().length() > 0) {
				subscriber.setUserID(userID);
				subscriber.setUserNpi(userNpi);
			} else { // This else block is for local environment
				subscriber.setUserID("pa/saUser");
				subscriber.setUserNpi("A342517700");
			}
			//subscriber.setNpiInGroup85(npiService.npiInGroup85(subscriber.getUserNpi()));
			request.getSession().setAttribute("sessionUser", subscriber);
		}
	}


}