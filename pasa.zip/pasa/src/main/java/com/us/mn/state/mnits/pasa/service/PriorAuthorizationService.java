package com.us.mn.state.mnits.pasa.service;

import org.springframework.ws.soap.client.SoapFaultClientException;

import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.AuthorizationDetail;

public interface PriorAuthorizationService {

	AuthForm doPriorAuthorization(AuthForm authForm) throws SoapFaultClientException;
	AuthForm doServiceAuthorization(AuthForm authForm) throws SoapFaultClientException;
}