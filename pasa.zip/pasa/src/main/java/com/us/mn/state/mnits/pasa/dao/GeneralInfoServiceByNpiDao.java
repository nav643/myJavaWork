package com.us.mn.state.mnits.pasa.dao;

import java.util.List;

import com.us.mn.state.mnits.pasa.model.GeneralInfoServiceByNpi;

public interface GeneralInfoServiceByNpiDao {
	List<GeneralInfoServiceByNpi> findByNpi(String npi);
	List<GeneralInfoServiceByNpi> findConsolidatedNpi(String npi);
	List<GeneralInfoServiceByNpi> getProviderByID(String providerID, String npi);
}
