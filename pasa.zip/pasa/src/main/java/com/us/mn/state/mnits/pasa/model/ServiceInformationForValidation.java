package com.us.mn.state.mnits.pasa.model;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Digits;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;


public class ServiceInformationForValidation {
	private String servLineKey = null;	// !!! The current Overlay Service Line key value
	private String beginDate;
	private String endDate;
	private String procedureCode;
	@Digits(fraction = 0, integer = 10)
	private String quantity;
	private String description;
	@Digits(fraction = 1, integer = 100000000)
	private String lineAmount;
	private String Comments;
	private List<String> Modifiers;
	private String TimePeriodQualifier;	//Home Care Frequency
	private String ServiceDescriptionModelNumber;
	private String model_number = null;	
	private boolean validRequest = true;  
	
	private Provider provider = new Provider();
	private DentalInformation dentalInformation = new DentalInformation();

	public ServiceInformationForValidation() {
		super();
	}


	public ServiceInformationForValidation(String servLineKey, String beginDate, String endDate,
			String procedureCode, String quantity, String description,
			String lineAmount, String comments, List<String> modifiers,
			String timePeriodQualifier, String serviceDescriptionModelNumber,
			String model_number, boolean validRequest, Provider provider,
			DentalInformation dentalInformation) {
		super();
		this.servLineKey = servLineKey;
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.procedureCode = procedureCode;
		this.quantity = quantity;
		this.description = description;
		this.lineAmount = lineAmount;
		Comments = comments;
		Modifiers = modifiers;
		TimePeriodQualifier = timePeriodQualifier;
		ServiceDescriptionModelNumber = serviceDescriptionModelNumber;
		this.model_number = model_number;
		this.validRequest = validRequest;
		this.provider = provider;
		this.dentalInformation = dentalInformation;
	}


	public String getServLineKey() {
		return servLineKey;
	}
	public void setServLineKey(String servLineKey) {
		this.servLineKey = servLineKey;
	}
	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getProcedureCode() {
		return procedureCode;
	}

	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLineAmount() {
		return lineAmount;
	}

	public void setLineAmount(String lineAmount) {
		this.lineAmount = lineAmount;
	}

	public List<String> getModifiers() {
		return Modifiers;
	}

	public void setModifiers(List<String> modifiers) {
		Modifiers = modifiers;
	}

	public String getTimePeriodQualifier() {
		return TimePeriodQualifier;
	}

	public void setTimePeriodQualifier(String timePeriodQualifier) {
		TimePeriodQualifier = timePeriodQualifier;
	}

	public String getServiceDescriptionModelNumber() {
		return ServiceDescriptionModelNumber;
	}

	public void setServiceDescriptionModelNumber(
			String serviceDescriptionModelNumber) {
		ServiceDescriptionModelNumber = serviceDescriptionModelNumber;
	}

	public String getComments() {
		return Comments;
	}

	public void setComments(String comments) {
		Comments = comments;
	}

	public Provider getProvider() {
		return provider;
	}

	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	
	public DentalInformation getDentalInformation() {
		return dentalInformation;
	}
	public void setDentalInformation(DentalInformation dentalInfo) {
		this.dentalInformation = dentalInfo;
	}
	public String getModel_number() {
		return model_number;
	}
	public void setModel_number(String model_number) {
		this.model_number = model_number;
	}
	public boolean isValidRequest() {
		return validRequest;
	}
	public void setValidRequest(boolean validRequest) {
		this.validRequest = validRequest;
	}
	
}
