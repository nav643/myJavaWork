package com.us.mn.state.mnits.pasa.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;

import com.us.mn.state.mnits.pasa.service.AuthLoggingConstants;

import us.mn.state.dhs.caps.schema.AdditionalInfoProcGroup;
import us.mn.state.dhs.caps.schema.AdditionalInformation;
import us.mn.state.dhs.caps.schema.AdditionalInformationGroup;

public class AuthAdditionalInformation implements Serializable, AuthLoggingConstants {
	
	// A collection questions and answers
	// (Currently only one question will be part of this ArrayList)
	private ArrayList<AdditionalInformation> currentAdditionalInfoList = null;
	
	private AdditionalInformation currentAdditionalInfo = null;
	
	private String actionIndicator = null;
	
	private boolean firstAdditionalInfoQuestion = false;
	
	private String currProcCode = null;
	
	private String currLineNum = null;
	
	// This object is passed from back end and you don't touch this object.
	// You just need to pass this object back as the way it is
	private ArrayList<AdditionalInfoProcGroup> authAdditonalInfoProcGroup = null;
	
	/**
	 *  Constructor
	 */
	public AuthAdditionalInformation() {
		   super() ;
	}

	public ArrayList<AdditionalInformation> getCurrentAdditionalInfoList() {
		return currentAdditionalInfoList;
	}

	public void setCurrentAdditionalInfoList(
			ArrayList<AdditionalInformation> currentAdditionalInfoList) {
		this.currentAdditionalInfoList = currentAdditionalInfoList;
	}

	public ArrayList<AdditionalInfoProcGroup> getAuthAdditonalInfoProcGroup() {
		return authAdditonalInfoProcGroup;
	}

	public void setAuthAdditonalInfoProcGroup(
			ArrayList<AdditionalInfoProcGroup> authAdditonalInfoProcGroup) {
		this.authAdditonalInfoProcGroup = authAdditonalInfoProcGroup;
	}

	public AdditionalInformation getCurrentAdditionalInfo() {
		return currentAdditionalInfo;
	}

	public void setCurrentAdditionalInfo(AdditionalInformation currentAdditionalInfo) {
		this.currentAdditionalInfo = currentAdditionalInfo;
	}

	public String getActionIndicator() {
		return actionIndicator;
	}

	public void setActionIndicator(String actionIndicator) {
		this.actionIndicator = actionIndicator;
	}

	public boolean isFirstAdditionalInfoQuestion() {
		return firstAdditionalInfoQuestion;
	}

	public void setFirstAdditionalInfoQuestion(boolean firstAdditionalInfoQuestion) {
		this.firstAdditionalInfoQuestion = firstAdditionalInfoQuestion;
	}

	public String getCurrLineNum() {
		return currLineNum;
	}

	public void setCurrLineNum(String currLineNum) {
		this.currLineNum = currLineNum;
	}

	public String getCurrProcCode() {
		return currProcCode;
	}

	public void setCurrProcCode(String currProcCode) {
		this.currProcCode = currProcCode;
	}
	

}