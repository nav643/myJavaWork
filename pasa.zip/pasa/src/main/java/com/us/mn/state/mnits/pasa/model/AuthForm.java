package com.us.mn.state.mnits.pasa.model;

import java.util.ArrayList;
import java.util.List;

import us.mn.state.dhs.caps.schema.ErrorStructure;

import com.us.mn.state.mnits.pasa.helper.AuthAdditionalInformation;
import com.us.mn.state.mnits.pasa.helper.AuthResponseForm;

import javax.validation.constraints.NotNull; 

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;



public class AuthForm {

	private String selectedServiceTypeCode;
	@NotNull
	private String requestId;	//legacyId
	private String requestNpi; //TODO
	private String requestIdFromPopup; //TODO
	private String requestNpiFromPopup; //TODO
	private String requestTaxonomyCodeFromPopup; //TODO
	private String orgName; // TODO: orgName or Last Name
	private String orgContactFirstName;
	// Org name or Last name
	private String orgContactLastName;	
	private String firstName;
	private String address;
	private String city;
	private String state;
	private String zip;
	
	private String contactName;
	// Below fields are for HHC
	private String contactFirstName;
	private String contactLastName;
	private String supplementId;
	
	private String communicationNumber;
	private String communicationType;
	//@NotEmpty(message = "Name may not be empty")
	private List<String> communicationText;
	
	private Subscriber sub = new Subscriber();
	private PatientEvent pe = new PatientEvent();
	private ServiceInformation svc = new ServiceInformation();		//TODO rename this variable
	private List<ServiceInformation> services = new ArrayList<ServiceInformation>();		//TODO rename this variable
	private String serviceLineItems;

	
	private AuthResponseForm responseForm = null;   
	private AuthAdditionalInformation authAdditionalInfo = null;
	
	// A collection of errors come from MMIS after auth request submitted
	// List contains a collection of ErrorStructure objects
	private ArrayList<ErrorStructure> authErrorsArrayList = null;
	
	/** True if Auth request passed all request validations */
	public  boolean validRequest = false;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}

//	public String toJson () {  
//	  return ToStringBuilder.reflectionToString(this,ToStringStyle.JSON_STYLE);  
//   	}
	
	public String getSelectedServiceTypeCode() {
		return selectedServiceTypeCode;
	}
	public void setSelectedServiceTypeCode(String selectedServiceTypeCode) {
		this.selectedServiceTypeCode = selectedServiceTypeCode;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequestNpi() {
		return requestNpi;
	}
	public void setRequestNpi(String requestNpi) {
		this.requestNpi = requestNpi;
	}
	public String getRequestIdFromPopup() {
		return requestIdFromPopup;
	}
	public void setRequestIdFromPopup(String requestIdFromPopup) {
		this.requestIdFromPopup = requestIdFromPopup;
	}
	public String getRequestNpiFromPopup() {
		return requestNpiFromPopup;
	}
	public void setRequestNpiFromPopup(String requestNpiFromPopup) {
		this.requestNpiFromPopup = requestNpiFromPopup;
	}
	public String getRequestTaxonomyCodeFromPopup() {
		return requestTaxonomyCodeFromPopup;
	}
	public void setRequestTaxonomyCodeFromPopup(String requestTaxonomyCodeFromPopup) {
		this.requestTaxonomyCodeFromPopup = requestTaxonomyCodeFromPopup;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	public String getOrgContactFirstName() {
		return orgContactFirstName;
	}
	public void setOrgContactFirstName(String orgContactFirstName) {
		this.orgContactFirstName = orgContactFirstName;
	}
	public String getOrgContactLastName() {
		return orgContactLastName;
	}
	public void setOrgContactLastName(String orgContactLastName) {
		this.orgContactLastName = orgContactLastName;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactFirstName() {
		return contactFirstName;
	}
	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}
	public String getContactLastName() {
		return contactLastName;
	}
	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}
	public String getSupplementId() {
		return supplementId;
	}
	public void setSupplementId(String supplementId) {
		this.supplementId = supplementId;
	}

	
	
	
	public String getCommunicationNumber() {
		return communicationNumber;
	}
	public void setCommunicationNumber(String communicationNumber) {
		this.communicationNumber = communicationNumber;
	}
	public String getCommunicationType() {
		return communicationType;
	}
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	public List<String> getCommunicationText() {
		return communicationText;
	}
	public void setCommunicationText(List<String> communicationText) {
		this.communicationText = communicationText;
	}
	
	
	public Subscriber getSub() {
		return sub;
	}
	public void setSub(Subscriber sub) {
		this.sub = sub;
	}
	public PatientEvent getPe() {
		return pe;
	}
	public void setPe(PatientEvent pe) {
		this.pe = pe;
	}
	public ServiceInformation getSvc() {
		return svc;
	}
	public void setSvc(ServiceInformation svc) {
		this.svc = svc;
	}

	public List<ServiceInformation> getServices() {
		return services;
	}
	public void setServices(List<ServiceInformation> services) {
		this.services = services;
	}
	public AuthResponseForm getResponseForm() {
		return responseForm;
	}
	public void setResponseForm(AuthResponseForm responseForm) {
		this.responseForm = responseForm;
	}
	public AuthAdditionalInformation getAuthAdditionalInfo() {
		return authAdditionalInfo;
	}
	public void setAuthAdditionalInfo(AuthAdditionalInformation authAdditionalInfo) {
		this.authAdditionalInfo = authAdditionalInfo;
	}
	public ArrayList<ErrorStructure> getAuthErrorsArrayList() {
		return authErrorsArrayList;
	}
	public void setAuthErrorsArrayList(ArrayList<ErrorStructure> authErrorsArrayList) {
		this.authErrorsArrayList = authErrorsArrayList;
	}
	public boolean isValidRequest() {
		return validRequest;
	}
	public void setValidRequest(boolean validRequest) {
		this.validRequest = validRequest;
	}
	public String getServiceLineItems() {
		return serviceLineItems;
	}
	public void setServiceLineItems(String serviceLineItems) {
		this.serviceLineItems = serviceLineItems;
	}
	
	
}
