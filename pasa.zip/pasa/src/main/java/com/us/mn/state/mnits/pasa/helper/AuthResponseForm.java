package com.us.mn.state.mnits.pasa.helper;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Vector;

import com.us.mn.state.mnits.pasa.helper.AuthLoggingConstants;
import com.us.mn.state.mnits.pasa.helper.AuthConstants;


/**
 * @author pwqhp55
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AuthResponseForm implements Serializable, AuthLoggingConstants {
	
	/** The Transaction Control Number of the created claim */
	private BigDecimal tcn = null;
	
	/** The value of WL-C47-OLTP-RETURN-CODE returned by MMIS */
	private String oltpReturnCode = null;
	
	/** The value of WL-C47-MNITS-RETURN-CODE  returned by MMIS */
	private String mnitsReturnCode = null;
	
	// The confirmation id is the SA_number generated from oracle database
	private String confirmation_id = null;
	
	// The list of Procedure Codes
	private Vector procCodes = new Vector();
	
	// PA Service Response Code sent back from MMIS
	private String PAServiceResponseCode = null;

	// PA Service Response Text sent back from MMIS (This will store the description of PA response code)
	private String PAServiceResponseText = null;		
	
	/** 
	 * A flag indicating that the response is deferred.  That is, the OCDC
	 * transaction seems to have been submitted, but the asynchonous response
	 * was not immediately avaliable.  This is usually an exceptional condition
	 * that must be reported to the user.
	 */
	private boolean deferred = false;
	
	/**
	 *  Constructor
	 */
	public AuthResponseForm() {
		   super() ;
	}
	
	// Check to see if the Prior Auth is approved
	public boolean isPaApproved()
	{
		if (PAServiceResponseCode.equals("PA_APPROVE"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// Check to see if the Prior Auth is not required
	public boolean isPaNotRequired()
	{
		if (PAServiceResponseCode.equals("PA_NOTREQ"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	// Check to see if the Prior Auth is deferred for decision from CDMI
	public boolean isPaDeferred()
	{
		if (PAServiceResponseCode.equals("PA_DEFER"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// Check to see if the Prior Auth has errors
	public boolean isPaInvalid()
	{
		if (PAServiceResponseCode.equals("PA_INVALID"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// Check to see if the Prior Auth is required additional information
	public boolean isPaAddInfoRequired()
	{
		if (PAServiceResponseCode.equals("PA_ADDINFO"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// Check to see if the user choose to ignore errors from Errors Screen and continue
	public boolean isPaValid()
	{
		if (PAServiceResponseCode.equals("PA_DEFAULT"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	// Check to see if the authorization request is denied
	public boolean isPaDenied()
	{
		if (PAServiceResponseCode.equals("PA_DENY"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
    /**
     * @return Returns the confirmation_id.
     */
    public String getConfirmation_id() {
        return confirmation_id;
    }
    
    /**
     * @param object The confirmation_id to set.
     */
    public void setConfirmation_id(String object) {
        this.confirmation_id = object;
    }
    
	public Iterator getProcedureCodes(){
		return procCodes.iterator();
	}
	
	public void setProcedureCodes(Vector procCodes){
	this.procCodes = procCodes;
	}    
    
	/**
	 * @return
	 */
	public String getOltpReturnCode() {
		return oltpReturnCode;
	}

	/**
	 * @return
	 */
	public String getMnitsReturnCode() {
		return mnitsReturnCode;
	}

	/**
	 * @return
	 */
	public BigDecimal getTcn() {
		return tcn;
	}

	/**
	 * @param string
	 */
	public void setOltpReturnCode(String string) {
		oltpReturnCode = string;
	}

	/**
	 * @param string
	 */
	public void setMnitsReturnCode(String string) {
		mnitsReturnCode = string;
	}

	/**
	 * @param decimal
	 */
	public void setTcn(BigDecimal decimal) {
		tcn = decimal;
	}

	/**
	 * @return Returns the deferred.
	 */
	public boolean isDeferred() {
		return deferred;
	}
	/**
	 * @param deferred The deferred to set.
	 */
	public void setDeferred(boolean deferred) {
		this.deferred = deferred;
	}

	public String getPAServiceResponseCode() {
		return PAServiceResponseCode;
	}

	public void setPAServiceResponseCode(String serviceResponseCode) {
		PAServiceResponseCode = serviceResponseCode;
	}

	public String getPAServiceResponseText() {
		return PAServiceResponseText;
	}

	public void setPAServiceResponseText(String serviceResponseText) {
		PAServiceResponseText = serviceResponseText;
	}

}
