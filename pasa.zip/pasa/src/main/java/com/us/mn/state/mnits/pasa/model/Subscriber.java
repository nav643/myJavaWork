package com.us.mn.state.mnits.pasa.model;

public class Subscriber extends Individual{
	private String subscriberId;
	
	private String userID;
	private String userNpi;
	private boolean isNpiInGroup85;

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserNpi() {
		return userNpi;
	}

	public void setUserNpi(String userNpi) {
		this.userNpi = userNpi;
	}

	public boolean isNpiInGroup85() {
		return isNpiInGroup85;
	}

	public void setNpiInGroup85(boolean isNpiInGroup85) {
		this.isNpiInGroup85 = isNpiInGroup85;
	}
	
//	@Override
//	public String toString() {
//		return "User [id=" + id + ", name=" + name + ", email=" + email + ", address=" + address
//				+ ", password=" + password + ", confirmPassword=" + confirmPassword
//				+ ", newsletter=" + newsletter + ", framework=" + framework  
//				+ ", number=" + number + ", country=" + country + ", skill=" + skill + "]" + isNew();
//	}
}
