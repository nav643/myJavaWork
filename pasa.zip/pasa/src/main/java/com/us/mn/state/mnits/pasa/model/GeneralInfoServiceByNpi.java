package com.us.mn.state.mnits.pasa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.Date;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI")
public class GeneralInfoServiceByNpi {
	@Id
	@Column(name = "PROV_NUMBER")
	private String providerNumber;

	@Column(name = "NPI_NUMBER")
	private String npiNumber;

	@Column(name = "ORGTAXNAME")
	private String orgTaxName;

	@Column(name = "ORGADD1")
	private String orgAddress1;

	@Column(name = "ORGADD2")
	private String orgAddress2;

	@Column(name = "ORGCITY")
	private String orgCity;

	@Column(name = "ORGSTATE")
	private String orgState;

	@Column(name = "ORGZIP")
	private String orgZip;
	
	@Column(name = "ORGZIP9")
	private String orgZip9;

	@Column(name = "PROV_TYPE", insertable = false, updatable = false)
	private String providerType;
	
	@ManyToOne
	@JoinColumn(name = "PROV_TYPE")
	@NotFound(action = NotFoundAction.IGNORE)
	private ProviderTypes providerTypes;

	@Column(name = "NPI_XREF_EFF_END")
	private Date xrefEndDate;
	
	public String getNpiNumber() {
		return npiNumber;
	}

	public void setNpiNumber(String npiNumber) {
		this.npiNumber = npiNumber;
	}

	public String getProviderNumber() {
		return providerNumber;
	}

	public void setProviderNumber(String providerNumber) {
		this.providerNumber = providerNumber;
	}

	public String getOrgTaxName() {
		return (orgTaxName == null) ? "" : orgTaxName;
	}

	public void setOrgTaxName(String orgTaxName) {
		this.orgTaxName = orgTaxName;
	}

	public String getOrgAddress1() {
		return (orgAddress1 == null) ? "" : orgAddress1;
	}

	public void setOrgAddress1(String orgAddress1) {
		this.orgAddress1 = orgAddress1;
	}

	public String getOrgAddress2() {
		return (orgAddress2 == null) ? "" : orgAddress2;
	}

	public void setOrgAddress2(String orgAddress2) {
		this.orgAddress2 = orgAddress2;
	}

	public String getOrgCity() {
		return (orgCity == null) ? "" : orgCity;
	}

	public void setOrgCity(String orgCity) {
		this.orgCity = orgCity;
	}

	public String getOrgState() {
		return (orgState == null) ? "" : orgState;
	}

	public void setOrgState(String orgState) {
		this.orgState = orgState;
	}

	public String getOrgZip() {
		return (orgZip == null) ? "" : orgZip;
	}

	public void setOrgZip(String orgZip) {
		this.orgZip = orgZip;
	}

	public ProviderTypes getProviderTypes() {
		return providerTypes;
	}

	public void setProviderTypes(ProviderTypes providerTypes) {
		this.providerTypes = providerTypes;
	}

	public String getOrgZip9() {
		return orgZip9;
	}

	public void setOrgZip9(String orgZip9) {
		this.orgZip9 = orgZip9;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public Date getXrefEndDate() {
		return xrefEndDate;
	}

	public void setXrefEndDate(Date xrefEndDate) {
		this.xrefEndDate = xrefEndDate;
	}
}

