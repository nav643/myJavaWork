package com.us.mn.state.mnits.pasa.web;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.us.mn.state.mnits.pasa.model.TestForm;

@Controller
public class testController {

	private final Logger logger = LoggerFactory.getLogger(PASAController.class);
//	private Subscriber subscriber = new Subscriber();
//
//	@Autowired
//	AuthFormValidator priorAuthFormValidator;
//
//	@InitBinder
//	protected void initBinder(WebDataBinder binder) {
//		binder.setValidator(priorAuthFormValidator);
//	}

	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String testCheck(Model model, HttpServletRequest request) {
		logger.debug("test()");
		
		model.addAttribute("css", "info");
		model.addAttribute("msg", "Test Screen - FROM TEST DATA");
		//model.addAttribute("login", new Login());
		model.addAttribute("testForm", new TestForm());

		return "test";
	}
	
	
	@RequestMapping(value = "/test", method = RequestMethod.POST)
	public String save(@ModelAttribute("/test") TestForm testForm, BindingResult result, Model model) { 
		logger.debug("test() : {}");
		
		if (result.hasErrors()) {
			//pasaService.loadScreen();
			model.addAttribute("css", "danger");
			model.addAttribute("msg", "return TEST - FROM TEST DATA - danger");
			return "test";
		} else {
			model.addAttribute("css", "success");
			model.addAttribute("msg", "You passed in " + testForm.getTab1().toString() + testForm.getTab2().toString());
			model.addAttribute("testForm", testForm);
		
		}
		System.out.println(testForm.getTab1().toString());
		System.out.println(testForm.getTab2().toString());
		
		// POST/REDIRECT/GET
		return "test";
	}
	
	
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ModelAndView handleMissingParams(HttpServletRequest req, MissingServletRequestParameterException e) {
		logger.debug("Exception: ", e.getMessage());
	    ModelAndView mav = new ModelAndView();
		mav.addObject("exception", e);
		mav.setViewName("error");
		return mav;
	}
	
}