package com.us.mn.state.mnits.pasa.config;

import java.util.Properties;

//import javax.naming.Context;
//import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EnableTransactionManagement
public class SpringDBConfig {
	
	private final Logger logger = LoggerFactory.getLogger(SpringDBConfig.class);

	@Autowired
	DataSource dataSource;

	@Bean
	public DataSource getDataSource() throws NamingException {
		DataSource datasource = null;
		
		try{
			datasource= (DataSource) new JndiTemplate().lookup("jdbc/mnits_reg_v5");
		    //dataSource = new BasicDataSource();
			//@Resource(name="jdbc/mnits_reg_v5")
			//Context ctx = new InitialContext();
			//dataSource = (DataSource)ctx.lookup("java:comp/env/jdbc/mnits_reg_v5");
			
		}
		catch (Exception e){
			logger.debug("Error creating datasource: " + e.getMessage());
		}
		return datasource; 
	}
	
//	@Bean
//	public static DataSource getDataSource() {
//	    BasicDataSource dataSource = new BasicDataSource();
////	    dataSource.setDriverClassName("yourDriverClasName");
////	    dataSource.setUrl("yourDbUrl");
////	    dataSource.setUsername("yourDbUser");
////	    dataSource.setPassword("yourDbPassowrd");
//	    dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
//	    dataSource.setUrl("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)(HOST=mmist1-scan.mmis.int.state.mn.us)(PORT=2521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=D1_MNITS_REGISTRATION)))");
//	    dataSource.setUsername("wa_provider_reg");
//	    dataSource.setPassword("pw_registration");	    
//	    return dataSource;
//	}   
	

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource);
		sessionFactory.setPackagesToScan(new String[] { "com.us.mn.state.mnits.pasa.model" });
		sessionFactory.setHibernateProperties(hibernateProperties());

		return sessionFactory;
	}

	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		properties.put("hibernate.show_sql", false);
		properties.put("hibernate.format_sql", true);
		return properties;
	}

	@Bean
	public HibernateTransactionManager transactionManager(SessionFactory s) {
		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;
	}

}