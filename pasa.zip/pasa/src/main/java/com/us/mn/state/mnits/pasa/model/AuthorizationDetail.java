package com.us.mn.state.mnits.pasa.model;

import java.util.List;

public class AuthorizationDetail {

	List<String> serviceTypeCode;
	Provider requester;
	Subscriber subscriber;
	PatientEvent event;
	
	public List<String> getServiceTypeCode() {
		return serviceTypeCode;
	}
	public void setServiceTypeCode(List<String> serviceType) {
		serviceTypeCode = serviceType;
	}
	
	public Provider getRequester() {
		return requester;
	}
	public void setRequester(Provider requester) {
		this.requester = requester;
	}
	public Subscriber getSubscriber() {
		return subscriber;
	}
	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}
	public PatientEvent getEvent() {
		return event;
	}
	public void setEvent(PatientEvent event) {
		this.event = event;
	}
	
	
}
