package com.us.mn.state.mnits.pasa.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.us.mn.state.mnits.pasa.model.GeneralInfoServiceByNpi;

@Repository
@Transactional
public class GeneralInfoServiceByNpiDaoImpl implements
		GeneralInfoServiceByNpiDao {
	private final Logger logger = LoggerFactory
			.getLogger(GeneralInfoServiceByNpiDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<GeneralInfoServiceByNpi> findConsolidatedNpi(String npi) {
		List<GeneralInfoServiceByNpi> result = new ArrayList<GeneralInfoServiceByNpi>();
		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(GeneralInfoServiceByNpi.class)
					.add(Restrictions.eq("npiNumber", npi))
					.add(Restrictions.eq("providerType", "33"))
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			result =  criteria.list();
		} catch (Exception e) {
			logger.error("ExceptionThrown: " + e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeneralInfoServiceByNpi> getProviderByID(String providerID, String npi) {
		List<GeneralInfoServiceByNpi> result = new ArrayList<GeneralInfoServiceByNpi>();
		try {
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(GeneralInfoServiceByNpi.class)
					.add(Restrictions.eq("providerID", providerID))
					.add(Restrictions.eq("npiNumber", npi))
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			result = criteria.list();
		} catch (Exception e) {
			logger.error("ExceptionThrown: " + e);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GeneralInfoServiceByNpi> findByNpi(String npi) {
		List<GeneralInfoServiceByNpi> result = new ArrayList<GeneralInfoServiceByNpi>();
		try {
			Criteria criteria = sessionFactory.getCurrentSession()
					.createCriteria(GeneralInfoServiceByNpi.class)
					.add(Restrictions.eq("npiNumber", npi))
					.add(Restrictions.ne("providerTypes.providerType", "33"))
					.add(Restrictions.or(
							Restrictions.eq("xrefEndDate", null),
							Restrictions.gt("xrefEndDate", new Date())
						))
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			result = (List<GeneralInfoServiceByNpi>) criteria.list();
		} catch (Exception e) {
			logger.debug("Exception: " + e.getMessage());
		}
		return result;
	}

}