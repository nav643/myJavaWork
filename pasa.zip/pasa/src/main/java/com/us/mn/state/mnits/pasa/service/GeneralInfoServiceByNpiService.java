package com.us.mn.state.mnits.pasa.service;

import java.util.List;
import com.us.mn.state.mnits.pasa.model.Location;

public interface GeneralInfoServiceByNpiService {
	List<Location> findByNpi (String npi);
}
