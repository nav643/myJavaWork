package com.us.mn.state.mnits.pasa.model;

import java.util.Date;
import java.util.List;

public class Login {
	String username;
	String password;
	String email;
	
	List<String> serviceTypeCode;
	
	//Communication (telephone)
	String communicationNumber;
	String communicationType;
	String communicationText;
	
	//Requester Info
	String requestId;
	String requesterOrgName;
	String requesterFirstName;
	String requesterAddress;
	String requesterCity;
	String requesterState;
	String requesterZip;
	String contactName;
	
	//Subscriber Info
	String subscriberId;
	String subscriberFirstName;
	String subscriberLastName;
	String subscriberMiddleName;
	Date subscriberDOB;
	String subscriberGender;
	
	//Patient Event info
	

	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getEmail() {
		return "testEmail";
	}
	
	
	
	public List<String> getServiceTypeCode() {
		return serviceTypeCode;
	}
	public void setServiceTypeCode(List<String> serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
	

	public String getCommunicationNumber() {
		return communicationNumber;
	}
	public void setCommunicationNumber(String communicationNumber) {
		this.communicationNumber = communicationNumber;
	}
	public String getCommunicationType() {
		return communicationType;
	}
	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	public String getCommunicationText() {
		return communicationText;
	}
	public void setCommunicationDetail(String communicationDetail) {
		this.communicationText = communicationText;
	}
	
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequesterOrgName() {
		return requesterOrgName;
	}
	public void setRequesterOrgName(String requesterOrgName) {
		this.requesterOrgName = requesterOrgName;
	}
	public String getRequesterFirstName() {
		return requesterFirstName;
	}
	public void setRequesterFirstName(String requesterFirstName) {
		this.requesterFirstName = requesterFirstName;
	}
	
	
	
	public String getRequesterAddress() {
		return requesterAddress;
	}
	public void setRequesterAddress(String requesterAddress) {
		this.requesterAddress = requesterAddress;
	}
	public String getRequesterCity() {
		return requesterCity;
	}
	public void setRequesterCity(String requesterCity) {
		this.requesterCity = requesterCity;
	}
	public String getRequesterState() {
		return requesterState;
	}
	public void setRequesterState(String requesterState) {
		this.requesterState = requesterState;
	}
	public String getRequesterZip() {
		return requesterZip;
	}
	public void setRequesterZip(String requesterZip) {
		this.requesterZip = requesterZip;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	
	
	
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getSubscriberFirstName() {
		return subscriberFirstName;
	}
	public void setSubscriberFirstName(String subscriberFirstName) {
		this.subscriberFirstName = subscriberFirstName;
	}
	public String getSubscriberLastName() {
		return subscriberLastName;
	}
	public void setSubscriberLastName(String subscriberlastName) {
		this.subscriberLastName = subscriberLastName;
	}
	public String getSubscriberMiddleName() {
		return subscriberMiddleName;
	}
	public void setSubscriberMiddleName(String subscribermiddleName) {
		this.subscriberMiddleName = subscriberMiddleName;
	}
	public Date getSubscriberDOB() {
		return subscriberDOB;
	}
	public void setSubscriberDOB(Date subscriberDOB) {
		this.subscriberDOB = subscriberDOB;
	}
	public String getSubscriberGender() {
		return subscriberGender;
	}
	public void setSubscriberGender(String subscriberGender) {
		this.subscriberGender = subscriberGender;
	}
	


	
	
}
