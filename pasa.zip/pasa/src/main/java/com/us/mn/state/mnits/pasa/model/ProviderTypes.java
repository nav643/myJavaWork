package com.us.mn.state.mnits.pasa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROVIDER.PROVIDER_TYPES")
public class ProviderTypes {
	@Id
	@Column(name = "PROVIDER_TYPE")
	private String providerType;

	@Column(name = "TYPE_DESCRIPTION")
	private String TypeDescription;

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getTypeDescription() {
		return TypeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		TypeDescription = typeDescription;
	}

}
