package com.us.mn.state.mnits.pasa.model;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class PatientEvent {
	private String certificationTypeCode;
	private List<String> diagnosisCodes;
	@DateTimeFormat(pattern="MM/dd/yyyy")
	private Date eventDate;
	private String traceNumber;
	private String messageText;
	
	public String getCertificationTypeCode() {
		return certificationTypeCode;
	}
	public void setCertificationTypeCode(String certificationTypeCode) {
		this.certificationTypeCode = certificationTypeCode;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public String getTraceNumber() {
		return traceNumber;
	}
	public void setTraceNumber(String traceNumber) {
		this.traceNumber = traceNumber;
	}
	public List<String> getDiagnosisCodes() {
		return diagnosisCodes;
	}
	public void setDiagnosisCodes(List<String> diagnosisCodes) {
		this.diagnosisCodes = diagnosisCodes;
	}
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	
}
