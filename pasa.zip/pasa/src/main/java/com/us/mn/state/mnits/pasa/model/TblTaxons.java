package com.us.mn.state.mnits.pasa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MNITS_COMMON.TBLTAXONS")
public class TblTaxons {
	@Id
	@Column(name = "TAXONOMY_CODE")
	private String taxonomyCode;

	@Column(name = "TAXONOMY_DESC")
	private String taxonomyDescription;

	public String getTaxonomyCode() {
		return taxonomyCode;
	}

	public void setTaxonomyCode(String taxonomyCode) {
		this.taxonomyCode = taxonomyCode;
	}

	public String getTaxonomyDescription() {
		return taxonomyDescription;
	}

	public void setTaxonomyDescription(String taxonomyDescription) {
		this.taxonomyDescription = taxonomyDescription;
	}

}
