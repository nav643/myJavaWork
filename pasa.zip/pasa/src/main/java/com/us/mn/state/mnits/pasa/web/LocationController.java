package com.us.mn.state.mnits.pasa.web;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mn.dhsdirect.mnits.user.ProviderInformationHandler;
import mn.dhsdirect.utils.StringConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.us.mn.state.mnits.pasa.helper.AuthUtility;
import com.us.mn.state.mnits.pasa.model.Location;
import com.us.mn.state.mnits.pasa.service.GeneralInfoServiceByNpiService;



@RestController
public class LocationController {

	private final Logger logger = LoggerFactory.getLogger(LocationController.class);
	private boolean isDebug = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;

	@Autowired
	private GeneralInfoServiceByNpiService generalInfoServiceByNpiService;


	
	@RequestMapping(value = "/locations/json", method = RequestMethod.GET, produces="application/json")
	public List<Location> getLocationsByNpi(Model model, @RequestParam String npi) {
		
		List<Location> locations = new ArrayList<Location>();
		try {
			logger.debug("locations/json Processing for single location/address npi: " + npi);
			locations = generalInfoServiceByNpiService.findByNpi(npi);
			//1801909239 (consolidated)

		} catch (Exception e) {
			logger.debug("Exception: ", e.getMessage());
		}

		return locations;
	}
	
	//provider type is not 33
	@RequestMapping(value = "/getLocationInfo", method = RequestMethod.POST)
	public @ResponseBody Location loadSingleLocationData(@RequestParam String npi, HttpServletRequest request, HttpServletResponse response) {
		Location location = new Location();
		//String npi = request.getParameter("npi");
		
		List<Location> locations = null;
		try {
			logger.debug("Processing for single location/address npi: " + npi);
			locations = generalInfoServiceByNpiService.findByNpi(npi);
		} catch (Exception e) {
			logger.debug("Exception: ", e.getMessage());
		}
		
		if (locations.size() == 1) {
			Location loc = locations.get(0);
			logger.debug("Fill the single location info for " + npi);
			location.setProviderName(loc.getProviderName());
			location.setName(loc.getName());
			location.setAddress1(loc.getAddress1());
			location.setAddress2(loc.getAddress2());
			location.setCity(loc.getCity());
			location.setState(loc.getState());
			location.setZip(loc.getZip());
			
			return location;	//single location and its data
		} else {
			//more than one location, call npi-popup-mvc list
			logger.debug("Multi location returned so call npi=popup for " + npi);
			return null; ///npi-popup-mvc/locations/A342517700?locationJson=testJsonResponse";
		}
	}
	
	

	

	@RequestMapping(value = "/lp", method = RequestMethod.GET)
	public String loadProvider(Model model, HttpServletRequest request) {
		logger.debug("loadProvider Information()");
		
		ProviderInformationHandler providerInfo = null ;
		try {
			providerInfo = AuthUtility.loadProvider("A342517700");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		model.addAttribute("provider Info", providerInfo);
		//providerInfo = AuthUtility.loadProvider(servReqForm.getRequester_npi().toUpperCase()) ;

		if (providerInfo.getOnFile().booleanValue()) {
			if (!(providerInfo.getNpiprov_type().equals("33"))) {
				model.addAttribute("css", "success");
				model.addAttribute("msg", "Provider info");
			}
			// The provider ID is not found
			else {
				// "No provider ID matches with the NPI/UMPI that you entered."));
				logger.debug("AuthServReqModel >> verifyNpi: No provider ID matches with the NPI/UMPI that you entered.");
				model.addAttribute("css", "danger");
				model.addAttribute("msg", "No Provider found");
			}
		}
		// The provider type = 33
		else {
			// "The NPI/UMPI has been identified as a consolidated NPI/UMPI. Please use the look up button next to the NPI/UMPI field to select a taxonomy code/location."));
			logger.debug("AuthServReqModel >> verifyNpi: The NPI/UMPI has been identified as a consolidated NPI/UMPI.");
			model.addAttribute("css", "success");
			model.addAttribute("msg", "Consolidated provider found");
		}
		
		if (isDebug) {
			if (!StringConverter.isEmpty(providerInfo.getId())) {
				// Reset the Requester provider ID in the Service Request
				logger.debug("************ PRINTING PROVIDER INFO *************");
				logger.debug(providerInfo.getId());
				logger.debug(providerInfo.getNpiprov_type());
				logger.debug(providerInfo.getLast_name());
				logger.debug(providerInfo.getFirst_name());
				logger.debug(providerInfo.getAddress1()	+ providerInfo.getAddress2());
				logger.debug(providerInfo.getAddress1());
				logger.debug(providerInfo.getAddress2());
				logger.debug(providerInfo.getCity());
				logger.debug(providerInfo.getState());
				logger.debug(providerInfo.getZip());
			}
		}
		
		return "options";
	}
	
}