package com.us.mn.state.mnits.pasa.helper;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.omg.CORBA.DynAnyPackage.Invalid;

public class DateStringCoverting {
	
	public static Date convertStringToDate(String dateString) throws Exception {
		Date convertedDate = null;
		String[] dateFormat = {"MMddyyyy", "MM/dd/yyyy", "MM-dd-yyyy"};
		try {
			convertedDate = DateUtils.parseDateStrictly(dateString, dateFormat);
		} catch (ParseException e1) {
			System.err.println("Error while converting from String to Date");
		}
		return convertedDate;
	}
	
//	public static boolean validDate(String dateString, String ... dateFormat) {
//		boolean valid = false;
//		try {		
//			DateUtils.parseDateStrictly(dateString, dateFormat);
//			valid = true;
//
//		} catch (ParseException e1) {
//			e1.printStackTrace();
//		}
//		return valid;
//	}
	
	public static boolean validDate(String dateString) {
		boolean valid = false;
		String[] dateFormat = {"MMddyyyy", "MM/dd/yyyy", "MM-dd-yyyy"};
		try {		
			DateUtils.parseDateStrictly(dateString, dateFormat);
			valid = true;
			
		} catch (ParseException e1) {
			valid = false;
		}
		return valid;
	}	
	
	// CPS ticket 15886 and 16119 by QHP 02/26/2013
	public static boolean validMmisCutOffDate(String dateString) {	
		boolean valid = false;
   		Date enteredDate 	= new Date();
   		Date MmisUpperCutOffDate = new Date();		
   		Date MmisLowerCutoffDate = new Date();
   		
		try{
			enteredDate = DateStringCoverting.convertStringToDate(dateString);
			try{
				MmisUpperCutOffDate = DateStringCoverting.convertStringToDate("12/31/2063");  // MMIS upper cut off date "12/31/2063"
				if (enteredDate.after(MmisUpperCutOffDate)) {
					System.out.println("The entered Date is greater than the MMIS upper cut off date (12/31/2063).");
					valid = false;
				}
				else {
					System.out.println("The entered Date is smaller than the MMIS upper cut off date (12/31/2063).");
					try {
						MmisLowerCutoffDate = DateStringCoverting.convertStringToDate("01/01/1964");  // MMIS lower cut off date "01/01/1964"
						if (enteredDate.before(MmisLowerCutoffDate)) {
							System.out.println("The entered Date is smaller than the MMIS lower cut off date (01/01/1964).");
							valid = false;
						}
						else {
							System.out.println("The entered Date is greater than the MMIS lower cut off date (01/01/1964).");
							valid = true;
						}
					}
					catch (Exception e){
						System.out.println("The MMIS lower cut off date is invalid. " + "01/01/1964");
						valid = false;						
					}
				}				
			}
			catch (Exception e){
				System.out.println("The MMIS upper cut off date is invalid. " + "12/31/2063");
				valid = false;
			}			
		}
		catch (Exception e) {
			System.out.println("The Entered Date off date is invalid. " + dateString);
			valid = false;
		}
			
		return valid;
	}

}
