/*
 * Created on Nov 20, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.us.mn.state.mnits.pasa.helper;

import java.util.ArrayList;

/**
 * @author pwqhp55
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuthConstants {
	
	/** The name of the session attribute that will hold the HCSA form set */
	public static final String SESSION_ATTRIBUTE_FORMSET = "authFormSet";
	
	/** The name of communication number subform */
	public static final String COMMUNICATION_NUMBER_SUBFORM = "CommNumForm";
	
	/** The name of Diagnosis Code subform */
	public static final String DIAGNOSIS_CODE_SUBFORM = "DiagnosisCodeForm";
	
	/** The name of Modifier subform */
	public static final String MODIFIER_SUBFORM = "ModifierForm";
	
	/** The Related Causes subform */
	public static final String RELATED_CAUSE_SUBFORM = "RelatedCauseForm";	
	
	/** The Oral Cavity Designation subform */
	public static final String ORAL_CAVITY_SUBFORM = "OraCavityForm";	
	
	/** The Tooth Information subform */
	public static final String TOOTH_SURF_SUBFORM = "ToothSurfForm";	

	
	/** 
	 * Claim disposition value -- indicates a new hcsa.
	 * The user can continue to edit the claim.
	 */
	public static final int DISPO_NEW = 0;
	
	/** Deferred action value -- no action */
	public static final int ACTION_NONE = 0;
	
	/** Deferred action value -- trigger auth validation from the browser */
	public static final int ACTION_VALIDATE = 1;
	
	/** Deferred action value -- trigger auth submission from the browser */
	public static final int ACTION_SUBMIT = 2;
	
		
	/** The disposition of the hcsa.  Determines the course of further processing. */
	public int dispo = DISPO_NEW;
	
	/** 
	* Hcsa  disposition value -- indicates the auth has been modified since the last validation.
	* The user can continue to edit the auth .
	*/
	public static final int DISPO_DIRTY = 1;
	
	/** 
	 * The hcsa action that is to be deferred to a subsequent process.
	 * (e.g. The JSP will generate HTML code to force the browser to call this action.)
	 */
	public int deferredAction = ACTION_NONE;				// Default: no action	
	
	public static final String LOAD_TEST_CASE  = 				"loadTestCase";	
	public static final String LOAD_TEST_CASE_SUCCESS  = 		"loadTestCaseSuccess";	
	
	public static final String INVALID_REQUEST 		= 			"invalidRequest";
	public static final String SUBMIT_NO_RESPONSE	= 			"submitNoResponse";
	
	public static final String PA_SUBMITED_WITH_VALIDATION_ERRORS  	= 	"submitedWithValidationErrors";
	public static final String PA_SUBMITED_WITH_APPROVED  	    	= 	"submitedWithApproved";
	public static final String PA_SUBMITED_BUT_NOT_REQUIRED     	= 	"submitedButNotRequired";
	public static final String PA_SUBMITED_WITH_DEFERRED     		= 	"submitedWithDeferred";
	public static final String PA_SUBMITED_WITH_ERRORS     			= 	"submitedWithErrors";
	public static final String PA_SUBMITED_BUT_ADD_INFO_REQUIRED  	= 	"submitedButAddInfoRequired";
	public static final String PA_SUBMITED_WITH_DENIED  			= 	"submitedWithDenied";

	// Auth Misc Actions constants
	public static final String CREATE_NEW_AUTH  					= 	"createNewAuth";
	public static final String CREATE_NEW_AUTH_SUCCESS  			= 	"createNewAuthSuccess";
	public static final String BACK_TO_AUTH_REQ  					= 	"backToAuthReq";
	public static final String BACK_TO_AUTH_REQ_SUCCESS  			= 	"backToAuthReqSuccess";
	public static final String IGNORE_ERRORS_CONTINUE				= 	"ignoreErrorsContinue";
	
	// Server Enviroment Setting
	public static final String ENVIROMENT_VARIABLE_NAME	= 		"APP_ENV";		
	public static final String DEV_ENV_NAME 			= 		"DEV";	
	public static final String STST_ENV_NAME 			= 		"STST";	
	public static final String ATST_ENV_NAME 			= 		"ATST";	
	public static final String PROD_ENV_NAME 			= 		"PROD";			
	
	// MQ variables for DEV
	public static final String MQ_CHANNEL_DEV				= 	"S_HCDEV_03" ;
	public static final String MQ_HOST_NAME_DEV				= 	"10.169.169.170" ;
	public static final String MQ_PORT_DEV					= 	"1414" ;
	public static final String MQ_QUEUE_MANAGER_NAME_DEV	= 	"QM_HCDEV_03" ;
	public static final String MQ_IN_QUEUE_NAME_DEV			= 	"SOC.MW000000.UTST.MQ278.RESP" ;
	public static final String MQ_OUT_QUEUE_NAME_DEV		= 	"SOC.MW000000.UTST.MQ278.MW9P" ;
	
	// MQ variable for STST
	public static final String MQ_CHANNEL_STST				= 	"S_HMSTST_01" ;
	public static final String MQ_HOST_NAME_STST			= 	"10.167.167.9" ;
	public static final String MQ_PORT_STST					= 	"1414" ;
	public static final String MQ_QUEUE_MANAGER_NAME_STST	= 	"QM_HCS280_01" ;	
	public static final String MQ_IN_QUEUE_NAME_STST		= 	"SOC.MW000000.STST.MQ278.RESP" ;	
	public static final String MQ_OUT_QUEUE_NAME_STST		= 	"SOC.MW000000.STST.MQ278.MW9P" ;
	
	// MQ variables for ATST
	public static final String MQ_CHANNEL_ATST				= 	"S_HMATST_01" ;
	public static final String MQ_HOST_NAME_ATST			= 	"10.168.168.9" ;
	public static final String MQ_PORT_ATST					= 	"1414" ;	
	public static final String MQ_QUEUE_MANAGER_NAME_ATST	= 	"QM_HCA280_01" ;	
	public static final String MQ_IN_QUEUE_NAME_ATST		= 	"SOC.MW000000.ATST.MQ278.RESP" ;	
	public static final String MQ_OUT_QUEUE_NAME_ATST		= 	"SOC.MW000000.ATST.MQ278.MW9P" ;	

	// MQ variables for PROD
	public static final String MQ_CHANNEL_PROD				= 	"S_HCPROD" ;
	public static final String MQ_HOST_NAME_PROD			= 	"10.165.165.9" ;
	public static final String MQ_PORT_PROD					= 	"2414" ;
	public static final String MQ_QUEUE_MANAGER_NAME_PROD	= 	"QM_HCA280_01" ;			
	public static final String MQ_IN_QUEUE_NAME_PROD		= 	"SOC.MW000000.PROD.MQ278.RESP" ;	
	public static final String MQ_OUT_QUEUE_NAME_PROD		= 	"SOC.MW000000.PROD.MQ278.MW9P" ;	
	
	// Enviroments shared MQ variables setting
	public static final String MQ_WAIT_INTERVAL				= 	"20000" ; 
	public static final String CCF_CONNECTION_TIME_OUT		= 	"10000" ;
	public static final String CCF_MAX_CONNECTIONS			= 	"20" ;
	public static final String CCF_MIN_CONNECTIONS			= 	"0" ;
	public static final String CCF_REAP_TIME				= 	"180" ;
	public static final String CCF_UNUSED_TIME_OUT			= 	"1800" ;
	public static final String CCF_TRACE_LEVEL				= 	"0" ;
	
	// Constants of Datasource to get the PA Number information
	public static final String PA_NUMBER_DEFAULT_DS = "java:comp/env/jdbc/mnits_pa_num";	
	public static final String GET_PA_NUMBER_SEQ_SQL = "SELECT PKG_CREATE_CTRLNUM.FX_NEW_DEFAULT_PATCN AS PANUM FROM DUAL";

	// Service Agreement Form Constants
	public static final String AUTHORIZATION_CATEGORY_TYPE_DEFAULT   	= "1" ;
	public static final String AUTHORIZATION_CER_TYPE_CODE_DEFAULT		= "I" ;
//	public static final String SERVICE_REQUEST_TOTAL_CHARGE  			= "0" ;
//	public static final String SERVICE_REQUEST_RELATED_CAUSES  			= "AA" ;
//	public static final String SERVICE_SERVICE_RELEASE_INFORMATION  	= "Y" ;
//	public static final String SERVICE_SERVICE_DELAY_REASON  			= "1" ;		
	
	public static final String ADD_INFO_QUESTION_TYPE_RADIO 			= "RADIO";
	public static final String ADD_INFO_QUESTION_TYPE_CHECKBOX 			= "CHECK";	
	
	public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL  			= "1" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_DENTAL  			= "2" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL_SUPPLY  	= "4" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MMIS_HCSA  				= "9" ;
	
	public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL  			= "1" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_DENTAL  			= "35" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL_SUPPLY  	= "12" ;
	public static final String AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA  				= "42" ;

}
