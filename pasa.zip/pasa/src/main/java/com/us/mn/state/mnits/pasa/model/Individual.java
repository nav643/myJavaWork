package com.us.mn.state.mnits.pasa.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Individual {

	private String firstName;
	private String lastName;
	private String middleName;
	@DateTimeFormat(pattern="MM/dd/yyyy")
	private Date DOB;
	private String Gender;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	
	
}
