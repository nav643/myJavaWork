package com.us.mn.state.mnits.pasa.model;

import java.util.List;

public class DentalInformation {
	private String toothNumber;
	private List<String> toothSurfaceCodes;
	private List<String> oralCavityDesignation;
	private String prosthesis;
	
//	private String service_provider_npi_umpi = null;
//	private String service_provider_id = null;	
//	private String service_provider_organization_last_name = null;	
//	private String service_provider_first_name = null;	
//	private String toothNumber = null;	
//	private String toothSurfInfo = null;				// Multiwidget	
//	private String toothinfo = null;				// Multiwidget	
//	private String oraCavDes = null;				// Multiwidget
//	private String prosthesis = null;
	
	public DentalInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public DentalInformation(String toothNumber,
			List<String> toothSurfaceCodes, List<String> oralCavityDesignation,
			String prosthesis) {
		super();
		this.toothNumber = toothNumber;
		this.toothSurfaceCodes = toothSurfaceCodes;
		this.oralCavityDesignation = oralCavityDesignation;
		this.prosthesis = prosthesis;
	}


	public String getToothNumber() {
		return toothNumber;
	}
	public void setToothNumber(String toothNumber) {
		this.toothNumber = toothNumber;
	}
	public List<String> getToothSurfaceCodes() {
		return toothSurfaceCodes;
	}
	public void setToothSurfaceCodes(List<String> toothSurfaceCodes) {
		this.toothSurfaceCodes = toothSurfaceCodes;
	}
	public List<String> getOralCavityDesignation() {
		return oralCavityDesignation;
	}
	public void setOralCavityDesignation(List<String> oralCavityDesignation) {
		this.oralCavityDesignation = oralCavityDesignation;
	}
	public String getProsthesis() {
		return prosthesis;
	}
	public void setProsthesis(String prosthesis) {
		this.prosthesis = prosthesis;
	}
	
}
