package com.us.mn.state.mnits.pasa.model;

import java.util.Date;

public class HealthService {
	private Date beginDate;
	private String procedureCode;
	private ServiceInformation serviceInfo;
	private DentalInformation dentalInfo;
	
	public Date getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}
	public String getProcedureCode() {
		return procedureCode;
	}
	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}
	public ServiceInformation getServiceInfo() {
		return serviceInfo;
	}
	public void setServiceInfo(ServiceInformation serviceInfo) {
		this.serviceInfo = serviceInfo;
	}
	public DentalInformation getDentalInfo() {
		return dentalInfo;
	}
	public void setDentalInfo(DentalInformation dentalInfo) {
		this.dentalInfo = dentalInfo;
	}
	
	
}
