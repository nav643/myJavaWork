package com.us.mn.state.mnits.pasa.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

//Spring MVC and logging
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;









//data processing
import us.mn.state.dhs.caps.schema.PARequest;
import us.mn.state.dhs.caps.schema.PAResponse;
import us.mn.state.dhs.caps.schema.PriorAuthorizeRequest;
import us.mn.state.dhs.caps.schema.PriorAuthorizeResponse;

//PA service objects - ServiceFactory is explicitly used in code
import us.mn.state.dhs.caps.apa.webservice.client.service.PAWebService;
import us.mn.state.dhs.caps.common.utils.XMLUtils;

//HCSA service objects - ServiceFactory is explicitly used in code
import us.mn.state.dhs.caps.hsca.webservice.client.helper.HCSAWebServiceInterface;

//data objects for dhs schema - OLD 
import us.mn.state.dhs.caps.schema.AdditionalInfoProcGroup;
import us.mn.state.dhs.caps.schema.AdditionalInformation;
import us.mn.state.dhs.caps.schema.AdditionalInformationGroup;
import us.mn.state.dhs.caps.schema.AuthServLineActionFormSchema;
import us.mn.state.dhs.caps.schema.AuthServReqActionFormSchema;
import us.mn.state.dhs.caps.schema.AuthServRespActionFormSchema;
import us.mn.state.dhs.caps.schema.CommNumFormSchema;
import us.mn.state.dhs.caps.schema.DiagnosisCodesFormSchema;
import us.mn.state.dhs.caps.schema.ErrorStructure;
import us.mn.state.dhs.caps.schema.HcsaAdditionalInfoFormSchema;
import us.mn.state.dhs.caps.schema.ModifierFormSchema;
import us.mn.state.dhs.caps.schema.ObjectFactory;
import us.mn.state.dhs.caps.schema.OraCavityFormSchema;
import us.mn.state.dhs.caps.schema.ToothSurfFormSchema;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.common.base.Splitter;
//object needed for NEW app - New PASA objects
import com.us.mn.state.mnits.pasa.helper.AuthAdditionalInformation;
import com.us.mn.state.mnits.pasa.helper.AuthConstants;
import com.us.mn.state.mnits.pasa.helper.AuthResponseForm;
import com.us.mn.state.mnits.pasa.helper.Day;
import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.AuthorizationDetail;
import com.us.mn.state.mnits.pasa.model.DentalInformation;
import com.us.mn.state.mnits.pasa.model.PatientEvent;
import com.us.mn.state.mnits.pasa.model.Provider;
import com.us.mn.state.mnits.pasa.model.ServiceInformation;
import com.us.mn.state.mnits.pasa.model.Subscriber;

@Service("pasaService")
public class PriorAuthorizationServiceImpl implements PriorAuthorizationService {
	private final Logger logger = LoggerFactory.getLogger(PriorAuthorizationServiceImpl.class);
	private boolean isDebug = java.lang.management.ManagementFactory
			.getRuntimeMXBean().getInputArguments().toString()
			.indexOf("-agentlib:jdwp") > 0;
			
	ObjectMapper mapper = new ObjectMapper();
	//Set default time zone as JVM timezone due to one day difference between original date and formatted date.
	//mapper.setTimeZone(TimeZone.getDefault());

	public AuthForm doPriorAuthorization(AuthForm authForm) {

		ObjectFactory objectFactory = new ObjectFactory();
		PARequest thisPARequest = objectFactory.createPARequest();
		PAResponse response = objectFactory.createPAResponse();
		PriorAuthorizeResponse priorAuthorizeResponse = objectFactory.createPriorAuthorizeResponse();

		// map AuthForm in new PA/SA to PriorAuthorize
		logger.debug("Before mapping AuthForm to PriorAuthorize in new PA/SA");

		// logger.debug("Printing non-JSON object");
		// System.out.print(authForm);
		//
		// try {
		// logger.debug("Printing JSON of AuthForm");
		// String json = mapper.writeValueAsString(authForm);
		// System.out.println(json);
		// } catch (JsonProcessingException e) {
		// System.out.println("An error to convert object to json");
		// e.printStackTrace();
		// }

		thisPARequest = mapPriorAuthForm(authForm);

		try {
			logger.debug("Printing JSON of Request Object");
			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(authForm);
			System.out.println(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.debug("After mapping AuthForm to PriorAuthorize in new PA/SA");
		CheckForRequiredFields(thisPARequest.getAuthRequestXML());
		logger.debug("After finishing checking for required fields in mapped object in new PA/SA");

		PriorAuthorizeRequest priorAuthorizeRequest = objectFactory.createPriorAuthorizeRequest();

		// set the in block for XML
		priorAuthorizeRequest.setIn(thisPARequest);
		// System.out.println(priorAuthorizeRequest);

		// Create PAWebService from it's own service factory
		PAWebService paWebService = (us.mn.state.dhs.caps.apa.webservice.locator.ServiceFactory.getInstance()).getPAWebService();

		// Submit Authorization
		logger.debug("Before calling PAWebservice");
		priorAuthorizeResponse = paWebService.doAuthInformation(priorAuthorizeRequest);  //new PriorAuthorizeResponse(); // TODO   
		logger.debug("After calling PAWebservice");

		// the out block for XML
		response = priorAuthorizeResponse.getOut();
		printOut6ResponseElements(response, authForm); 

		// unmap PriorAuthorizeResponse to AuthForm
		logger.debug("Before unmap PriorAuthorizeResponse PA to AuthForm");
		if (isDebug) { // TODO
			response = objectFactory.createPAResponse();
			// response.setAuthRequestXML(objectFactory.createAuthRequestXML(new
			// AuthServReqActionFormSchema())); //AuthServRespActionFormSchema
			response.setAuthResponseXML(new AuthServRespActionFormSchema());
		}
		authForm = unmapAuthForm(response, authForm);
		logger.debug("After unmap  PriorAuthorizeResponse PA to AuthForm in new PA/SA app");

		return authForm;
	}

	@SuppressWarnings("unused")
	public AuthForm doServiceAuthorization(AuthForm authForm) {
		AuthForm returnForm = new AuthForm();	//do something about expired session

		ObjectFactory objectFactory = new ObjectFactory();
		PARequest thisSARequest = objectFactory.createPARequest();
		PAResponse response = objectFactory.createPAResponse();
		PriorAuthorizeResponse serviceAgreementResponse = objectFactory.createPriorAuthorizeResponse();

		// map AuthForm in new PA/SA to PriorAuthorize
		logger.debug("Before mapping AuthForm in new PA/SA to ServiceAgreement hcsa");
		thisSARequest = mapServiceAgreementAuthForm(authForm);
		

		try {
			logger.debug("Printing JSON of Request Object for SA");
			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(authForm);
			System.out.println(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.debug("After mapping AuthForm in new PA/SA to ServiceAgreement hcsa");
		// CheckForRequiredFields(thisPARequest);
		logger.debug("After finishing checking for required fields in mapped object in new PA/SA");

		PriorAuthorizeRequest serviceAgreementRequest = objectFactory.createPriorAuthorizeRequest();

		// the IN block for the XML
		serviceAgreementRequest.setIn(thisSARequest);
		// System.out.println(thisPARequest.getAuthRequestXML().toString());

		// Create HCSAWebService from it's own service factory
		HCSAWebServiceInterface hcasWebService = (us.mn.state.dhs.caps.hcsa.webservice.client.locator.ServiceFactory
				.getInstance()).getHcsaWebService();

		// Submit HCSA Authorization
		logger.debug("Before calling HCSAWebservice");
		serviceAgreementResponse = hcasWebService.doAuthInformation(serviceAgreementRequest);  // new PriorAuthorizeResponse(); // TODO    
		logger.debug("After calling HCSAWebservice");

		// the OUT block for the XML
		response = serviceAgreementResponse.getOut();
		printOut6ResponseElements(response, authForm);

		// unmap PriorAuthorizeResponse to AuthForm in new PA/SA
		logger.debug("Before unmap ServiceAgreementResponse hcsa to AuthForm in new PA/SA");
		if (isDebug) { // TODO
			response = objectFactory.createPAResponse();
			response.setAuthResponseXML(new AuthServRespActionFormSchema());
		}
		returnForm = unmapAuthForm(response, authForm);
		logger.debug("After unmap ServiceAgreementResponse hcsa to AuthForm in new PA/SA");

		return returnForm;
	}

	// private AuthForm unmapAuthForm in new PA/SA(PAResponse paResponse,
	// AuthForm inFormSet) {
	// // TODO Auto-generated method stub
	// return null;
	// }

	private void printOut6ResponseElements(PAResponse response, AuthForm authForm) {
		logger.debug("Printing out 6 response element ...");
		ArrayList<ErrorStructure> errorList;
		if (response != null) {
			errorList = (ArrayList<ErrorStructure>) response.getErrors();
		} else {
			errorList = new ArrayList<ErrorStructure>();
		}
		authForm.setAuthErrorsArrayList(errorList);

		if (errorList.size() == 0) {
			logger.debug("no errors encourntered hence not much to print");
		} else {
			logger.debug("Here is the error list for ArrayList<ErrorStructure>");
			for (ErrorStructure currentError : errorList) {
				logger.debug("<b>" + currentError.getErrorCode() + "</b>"
						+ ", " + currentError.getErrorInternalStatus() + "/"
						+ currentError.getErrorInternalCode() + "  "
						+ currentError.getErrorInternalDescription());
			}

			AuthServRespActionFormSchema xml = response.getAuthResponseXML();
			logger.debug("Confirmation Id: " + xml.getConfirmationId());
			logger.debug("Deferred: " + xml.getDeferred());
			logger.debug("Mnits Return Code: " + xml.getMnitsReturnCode());
			logger.debug("Oltp ReturnCode: " + xml.getOltpReturnCode());
			logger.debug("PAServiceResponseCode: "
					+ xml.getPAServiceResponseCode());
			logger.debug("TCN: " + xml.getTcn());

			List<AdditionalInfoProcGroup> additionalInfo = response.getAuthAdditionalInformation();
			for (AdditionalInfoProcGroup info : additionalInfo) {
				logger.debug("Line Number: " + info.getLineNumber() + "\n");
				logger.debug("Procedure Code: " + info.getProcedureCode()
						+ "\n");
				logger.debug("Status: " + info.getAdditionalInfoStatus() + "\n");
				// info.getAdditionalInformationNeeded();
			}
		}
		logger.debug("Finished printing ... all 6 elements and error list (if any)");
	}

	private AuthForm unmapAuthForm(PAResponse inPA, AuthForm inForm) {
		if (inForm != null) {
			inForm.setResponseForm(unmapResponseXML(inPA.getAuthResponseXML()));
			// Check the status of the PAResponseCode if set to additional
			// questions - pop the last question
			if (inForm.getAuthAdditionalInfo() == null) {
				inForm.setAuthAdditionalInfo(new AuthAdditionalInformation());
			}
			if ("PA_ADDINFO".equals(inPA.getAuthResponseXML().getPAServiceResponseCode())) {
				setCurrentProcsAddnlInfo(inForm.getAuthAdditionalInfo(), inPA.getAuthAdditionalInformation());
				inForm.getAuthAdditionalInfo().setCurrentAdditionalInfo(
						getTopAdditionalInfo(inPA.getAuthAdditionalInformation()));
				inForm.getAuthAdditionalInfo().setAuthAdditonalInfoProcGroup(
						(ArrayList<AdditionalInfoProcGroup>) inPA.getAuthAdditionalInformation());
				inForm.setAuthErrorsArrayList((ArrayList) inPA.getErrors());
			}
		}
		return inForm;

	}

	private void setCurrentProcsAddnlInfo(AuthAdditionalInformation inInfo,
			List<AdditionalInfoProcGroup> inQuestionList) {
		AdditionalInfoProcGroup infoProcGroup = (AdditionalInfoProcGroup) inQuestionList
				.get(inQuestionList.size() - 1);
		inInfo.setCurrProcCode(infoProcGroup.getProcedureCode());
		inInfo.setCurrLineNum(infoProcGroup.getLineNumber());
		inInfo.setCurrentAdditionalInfo(getTopAdditionalInfo(inQuestionList));
	}

	private AdditionalInformation getTopAdditionalInfo(
			List<AdditionalInfoProcGroup> inQuestionList) {

		// Get the Additional Info List
		AdditionalInfoProcGroup infoProcGroup = (AdditionalInfoProcGroup) inQuestionList
				.get(inQuestionList.size() - 1);
		infoProcGroup.setAdditionalInfoStatus("PA_ADDINFO");
		AdditionalInformationGroup infoGroup = (AdditionalInformationGroup) infoProcGroup
				.getAdditionalInformationNeeded().get(infoProcGroup.getAdditionalInformationNeeded().size() - 1);
		infoProcGroup.getAdditionalInformationNeeded().remove(
				infoProcGroup.getAdditionalInformationNeeded().size() - 1);
		if (infoProcGroup.getAdditionalInformationNeeded().size() == 0) {
			inQuestionList.remove(inQuestionList.size() - 1);
		}
		return infoGroup.getAdditionalInformation().get(0);
	}

	private AuthResponseForm unmapResponseXML(
			AuthServRespActionFormSchema inRespXML) {
		AuthResponseForm outRespForm = new AuthResponseForm();
		outRespForm.setConfirmation_id(inRespXML.getConfirmationId());
		outRespForm.setDeferred(new Boolean(inRespXML.getDeferred()).booleanValue());
		outRespForm.setMnitsReturnCode(inRespXML.getMnitsReturnCode());
		outRespForm.setOltpReturnCode(inRespXML.getOltpReturnCode());
		if (inRespXML.getTcn() != null)
			outRespForm.setTcn(new BigDecimal(inRespXML.getTcn()));
		outRespForm.setPAServiceResponseCode(inRespXML.getPAServiceResponseCode());
		return outRespForm;
	}

	// ************* PRIOR AUTHORIZATION : MAP PA FORM *****************
	private PARequest mapPriorAuthForm(AuthForm inAuthForm) {
		ObjectFactory objCreator = new ObjectFactory();
		PARequest tempPA = objCreator.createPARequest();
		AuthResponseForm respForm = new AuthResponseForm();
		String paNumber = null;

		logger.debug("Running for NPI: " + inAuthForm.getRequestNpi() + " & legacy_id: " + inAuthForm.getRequestId());
		AuthServRespActionFormSchema inResp = objCreator.createAuthServRespActionFormSchema();
		AuthServReqActionFormSchema authFormSchema = objCreator.createAuthServReqActionFormSchema();

		// if ignoring errors and continuing then following 3 field must be
		// filled in
		if (inAuthForm.getResponseForm() != null
				&& inAuthForm.getResponseForm().getConfirmation_id() != null
				&& !"".equals(inAuthForm.getResponseForm().getConfirmation_id())) {
			// getting the PA number to ignore the errors and continue
			// processing
			paNumber = inAuthForm.getResponseForm().getConfirmation_id();
			logger.debug("Must be EDIT or IGNORE errors: Getting confirmation Id ->" + paNumber);

			// following 3 field must be filled in
			respForm.setConfirmation_id(paNumber);
			respForm.setDeferred(false);
			respForm.setPAServiceResponseCode("PA_DEFAULT");
		} else {
			// if new In-FORM being prepared
			paNumber = new String("0");
		}

		inResp = mapResponseXML(respForm);
		logger.debug("setting PA Number to start the response processing ..." + paNumber);
		authFormSchema.setPriorAuthNumber(paNumber);

		logger.debug("processing Service Type ..." + inAuthForm.getSelectedServiceTypeCode());
		if (inAuthForm.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL)) {
			authFormSchema.setAuthCategoryType(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL);
		} else if (inAuthForm.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_DENTAL)) {
			authFormSchema.setAuthCategoryType(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MMIS_DENTAL);
		} else if (inAuthForm.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_MEDICAL_SUPPLY)) {
			authFormSchema.setAuthCategoryType(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MMIS_MEDICAL_SUPPLY);
		}

		//Requester Information
		logger.debug("processing Requester info ...");
		saveRequesterInformation(inAuthForm, authFormSchema, false);
		
		//supplement Id - tribe ID
		logger.debug("processing Supplement Id ...");
		if (!StringUtils.isEmpty(inAuthForm.getSupplementId())) {
			authFormSchema.setRequesterHomeCareTribeId(inAuthForm.getSupplementId());
		}


		// Logic for communication numbers and storing all the data
		logger.debug("processing communication info ...");
		List<String> commTexts = inAuthForm.getCommunicationText();
		List<CommNumFormSchema> commNumFormSchemaList = new ArrayList<CommNumFormSchema>();
		saveCommunicationData(objCreator, authFormSchema, commTexts, commNumFormSchemaList);

		// Subscribe info
		logger.debug("processing subscriber info ...");
		Subscriber subscriber = inAuthForm.getSub();
		saveSubscriberInformation(subscriber, authFormSchema);

		// Patient Event
		logger.debug("processing Patient event info ...");
		PatientEvent patientEvent = savePatientEventInfo(inAuthForm, false, objCreator, authFormSchema);

//		PatientEvent patientEvent = inAuthForm.getPe();
//		authFormSchema.setCertType(patientEvent.getCertificationTypeCode());
//
//		if (patientEvent.getDiagnosisCodes() != null) {
//			for (String diagnosisCode : patientEvent.getDiagnosisCodes()) {
//				DiagnosisCodesFormSchema outDiagnosisCodesForm = objCreator.createDiagnosisCodesFormSchema();
//				outDiagnosisCodesForm.setDiagnosisCode(diagnosisCode);
//				authFormSchema.getDiagnosisCodes().add(outDiagnosisCodesForm);
//			}
//			logger.debug("finished processing diagnosis code(s) ...");
//		}
//		
//		authFormSchema.setPatientEventTraceNumber(patientEvent.getTraceNumber());
//		// authFormSchema.setHcsaAdditionalInfo(HcsaAdditionalInfo);
//		authFormSchema.setValidRequest(true); // TODO
//		authFormSchema.setLastupdatedate(Day.getNoOfDays(Day.getLocalMachineDate()).toPlainString());

		
		
		
		//Now Process Line Items and related fields.  There is a lot waiting to happen in here
		int serviceIndex = 0;
		//inAuthForm.setServices(Arrays.asList(inAuthForm.getSvc())); // TODO: get all service line items
		for (ServiceInformation svc : inAuthForm.getServices()) {
			svc.setServLineKey(String.valueOf(serviceIndex));
			logger.debug("processing Line Items --> ...");			
			AuthServLineActionFormSchema authLineSchema = mapAuthFormLineItems(svc,	objCreator, false);	//HCSA flag is false
			authFormSchema.getServiceLine().add(authLineSchema);
			serviceIndex++;
		}
		
		tempPA.setAuthRequestXML(authFormSchema);
		logger.debug("done processing Request ...");
		
		logger.debug("starting on processing Additional Info fields ...");		
		if (inAuthForm.getAuthAdditionalInfo() != null
				&& inAuthForm.getAuthAdditionalInfo().getAuthAdditonalInfoProcGroup() != null)
			tempPA.getAuthAdditionalInformation().addAll(
					inAuthForm.getAuthAdditionalInfo().getAuthAdditonalInfoProcGroup());
		// If an answer exists add it to the top of the AdditionalInfo
		if (inAuthForm.getAuthAdditionalInfo() != null
				&& inAuthForm.getAuthAdditionalInfo().getCurrentAdditionalInfo() != null) {
			AdditionalInformation addInfo = inAuthForm.getAuthAdditionalInfo().getCurrentAdditionalInfo();
			AdditionalInformationGroup addInfoGroup = objCreator.createAdditionalInformationGroup();
			addInfoGroup.getAdditionalInformation().add(addInfo);
			int addnlProcSize = tempPA.getAuthAdditionalInformation().size();
			boolean createNewGroup = false;
			if (addnlProcSize > 0) {
				AdditionalInfoProcGroup currProcGroup = tempPA.getAuthAdditionalInformation().get(addnlProcSize - 1);
				if (!"PA_ADDINFO".equals(currProcGroup.getAdditionalInfoStatus()))
					createNewGroup = true;
				else {
					currProcGroup.getAdditionalInformationNeeded().add(addInfoGroup);
				}
			} else {
				createNewGroup = true;
				if (createNewGroup) {
					AdditionalInfoProcGroup infoProcGroup = objCreator.createAdditionalInfoProcGroup();
					infoProcGroup.setAdditionalInfoStatus("PA_ADDINFO");
					infoProcGroup.setLineNumber(new Integer(addnlProcSize).toString());
					infoProcGroup.setProcedureCode(tempPA.getAuthRequestXML()
							.getServiceLine().get(addnlProcSize).getProcedurePerformed());
					infoProcGroup.getAdditionalInformationNeeded().add(addInfoGroup);
					tempPA.getAuthAdditionalInformation().add(infoProcGroup);
				}
			}
		}
		tempPA.setAuthResponseXML(inResp);
		// XMLUtils.printToStream(tempPA);
		logger.debug("done setting the Response ...");

		return tempPA;
	} // MAP PA FORM
	


	// ******************* HCSA: MAP SERVICE AGREEMENT (SA) FORM *********************
	private PARequest mapServiceAgreementAuthForm(AuthForm inAuthForm) { // SA
																			// Form
		ObjectFactory objCreator = new ObjectFactory();
		PARequest tempSA = objCreator.createPARequest();
		AuthResponseForm respForm = new AuthResponseForm();
		String paNumber = null;
		boolean HSCA = true;

		AuthServRespActionFormSchema inResp = objCreator.createAuthServRespActionFormSchema();
		AuthServReqActionFormSchema authFormSchema = objCreator.createAuthServReqActionFormSchema();

		// if ignoring errors and continuing then following 3 field must be
		// filled in
		// if(inAuthForm.getResponseForm() !=null &&
		// inAuthForm.getResponseForm().getConfirmation_id()!=null &&
		// !"".equals(inAuthForm.getResponseForm().getConfirmation_id())){
		// //getting the PA number to ignore the errors and continue processing
		// paNumber = inAuthForm.getResponseForm().getConfirmation_id();
		//
		// //following 3 field must be filled in
		// respForm.setConfirmation_id(paNumber);
		// respForm.setDeferred(false);
		// respForm.setPAServiceResponseCode("PA_DEFAULT");
		// }
		// else {
		// //if new In-FORM being prepared
		// paNumber = new String("0");
		// }

		if (respForm != null) {
			inResp = mapResponseXML(respForm);
		}
		authFormSchema.setPriorAuthNumber(paNumber);

		if (respForm != null && respForm.getConfirmation_id() != null
				&& !"".equals(respForm.getConfirmation_id())) {
			paNumber = respForm.getConfirmation_id();
			logger.debug("Must be EDIT or IGNORE errors: Getting confirmation Id ->" + paNumber);

			// following 3 field must be filled in
			respForm.setConfirmation_id(paNumber);
			respForm.setDeferred(false);
			respForm.setPAServiceResponseCode("PA_DEFAULT");
		} else {
			paNumber = new String("0");
		}

		authFormSchema.setPriorAuthNumber(paNumber);
		authFormSchema.setAuthCategoryType(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MMIS_HCSA);

		// Save all details of the requester
		logger.debug("Running for NPI: " + inAuthForm.getRequestNpi()+ " & legacy_id: " + inAuthForm.getRequestId());
		saveRequesterInformation(inAuthForm, authFormSchema, true);

		// Logic for communication numbers and storing all the data
		List<String> commTexts = inAuthForm.getCommunicationText();
		List<CommNumFormSchema> commNumFormSchemaList = new ArrayList<CommNumFormSchema>();
		saveCommunicationData(objCreator, authFormSchema, commTexts, commNumFormSchemaList);

		
		// process supplement ID (home care tribe id)
		if (inAuthForm.getSupplementId().isEmpty()) {	//!"" or !StingUtils.isEmpty()
			logger.debug("The supplement ID (home care tribe id) is empty so we have to initialize it to zero.");
			authFormSchema.setRequesterHomeCareTribeId("0");
		} else {
			logger.debug("The supplement ID (home care tribe id) is not empty");
			authFormSchema.setRequesterHomeCareTribeId(inAuthForm.getSupplementId());
		}

		// Subscribe info
		Subscriber subscriber = inAuthForm.getSub();
		saveSubscriberInformation(subscriber, authFormSchema);

		// Loop thru each service line item and determine Earliest Begin Date  And Latest End Date
		logger.debug("Determining earliest begin date and latest end date ...");
		determineEarliestBeginDateAndLatestEndDate(inAuthForm, authFormSchema);
		
		//These two dates are the hidden data to be stored and sent to MMIS
		logger.debug("2 very important HIDDEN DATA to send to SA");
		logger.debug(authFormSchema.getSubscriberGender());
		logger.debug(authFormSchema.getRequesterZipCd());
		
		// IMPORTANT NOTE: For SA, following two fields are being used to store some important hidden data
		// authFormSchema.setSubscriberGender(inAuthForm.getSubscriber_gender());
		// authFormSchema.setRequesterZipCd(inAuthForm.getRequester_zip_cd());

		// Patient Event
		PatientEvent patientEvent = savePatientEventInfo(inAuthForm, true, objCreator, authFormSchema);

		
		// Process HCSA additional information (saved as Message Text)
		String HcsaAdditionalInfoMessageText = patientEvent.getMessageText();
		//Arrays.toString("HcsaAdditionalInfoMessageText".split("(?<=\\G.{70})"));
		determineHcsaAdditionalInfo(authFormSchema,	HcsaAdditionalInfoMessageText);
		
		// Map these only for the first occr (Header level) - determine Hcsa
		// Codes And Set Flags
		// String procedureCodeFirstLine =
		// inAuthForm.getServices[0].getProcedure_performed();
		determineHcsaCodesAndSetFlags(inAuthForm, authFormSchema);

		// Map the service Line item data
		int serviceIndex = 0;
		for (ServiceInformation svc : inAuthForm.getServices()) {
			svc.setServLineKey(String.valueOf(serviceIndex));
			
			//generally HCSA has nothing to do with Dental and the form hides the
			//dental info input box.  so Set the object to null here
			svc.setDentalInformation(null);
		
			logger.debug("processing Line Items for SA transaction --> ...");			
			AuthServLineActionFormSchema authLineSchema = mapAuthFormLineItems(svc, objCreator, true);
			authFormSchema.getServiceLine().add(authLineSchema);
			serviceIndex++;
		}
		
		tempSA.setAuthRequestXML(authFormSchema);
		tempSA.setAuthResponseXML(inResp);
		// XMLUtils.printToStream(tempPA);
		return tempSA;
	} // mapSA AuthForm

	
	
	
	
	private PatientEvent savePatientEventInfo(AuthForm inAuthForm, boolean HCSA, 
			ObjectFactory objCreator, AuthServReqActionFormSchema authFormSchema) {
		
		PatientEvent patientEvent = inAuthForm.getPe();
		authFormSchema.setCertType(patientEvent.getCertificationTypeCode());
		
		if (patientEvent.getDiagnosisCodes() != null) {
			logger.debug("Processing diagnosis code(s) ...");
			for (String diagnosisCode : patientEvent.getDiagnosisCodes()) {
				DiagnosisCodesFormSchema outDiagnosisCodesForm = objCreator.createDiagnosisCodesFormSchema();
				outDiagnosisCodesForm.setDiagnosisCode(diagnosisCode);
				authFormSchema.getDiagnosisCodes().add(outDiagnosisCodesForm);
			}
		}

		if (HCSA) {
			logger.debug("Processing event date ...");
			if (patientEvent.getEventDate() != null && (!StringUtils.isEmpty(patientEvent.getEventDate().toString()))) {
				authFormSchema.setHcsaAssessmentDt(getNumberOfDaysFrom(patientEvent.getEventDate()).toPlainString());
			} else {
				authFormSchema.setHcsaAssessmentDt("");
			}
			//authFormSchema.setHcsaAdditionalInfo(HcsaAdditionalInfo);
		}

		authFormSchema.setPatientEventTraceNumber(patientEvent.getTraceNumber());
		authFormSchema.setValidRequest(true); // TODO
		authFormSchema.setLastupdatedate(Day.getNoOfDays(Day.getLocalMachineDate()).toPlainString());		
		return patientEvent;
	}

	

	
	/**
	 * @param inAuthForm
	 * @param authFormSchema
	 */
	protected void saveRequesterInformation(AuthForm inAuthForm, AuthServReqActionFormSchema authFormSchema, boolean HCSA) {
		String valueToProcess = "";
		//old App fields
		//authFormSchema.setRequesterId(authForm.getRequester_id());
		//authFormSchema.setRequesterIdFromPopup(authForm.getRequester_id_from_popup());
		//authFormSchema.setRequesterNpi(authForm.getRequester_npi());
		//authFormSchema.setRequesterNpiFromPopup(authForm.getRequester_npi_from_popup());
		//authFormSchema.setRequesterTaxonomyCode(authForm.getRequester_taxonomy_code());
		//authFormSchema.setRequesterLastOrgName(authForm.getRequester_last_org_name());
		//authFormSchema.setRequesterFirstName(authForm.getRequester_first_name());
		
		authFormSchema.setRequesterNpi(inAuthForm.getRequestNpi()); // A342517700 (single location) or 1801909239 (consolidated)
		authFormSchema.setRequesterId(inAuthForm.getRequestId()); // legacy_id
		valueToProcess = inAuthForm.getRequestNpiFromPopup();		//inAuthForm.getRequestNpiFromPopup() or inAuthForm.getRequestNpi()
		authFormSchema.setRequesterNpiFromPopup(StringUtils.isEmpty(valueToProcess) ? "" : valueToProcess);
		valueToProcess = inAuthForm.getRequestIdFromPopup();		//getRequestId()); // legacy_id
		authFormSchema.setRequesterIdFromPopup(StringUtils.isEmpty(valueToProcess) ? "" : valueToProcess);		
		authFormSchema.setRequesterTaxonomyCode(inAuthForm.getRequestTaxonomyCodeFromPopup());
		
		// <requester_last_org_name> and <requester_first_name/>
		authFormSchema.setRequesterLastOrgName(inAuthForm.getOrgName());
		authFormSchema.setRequesterFirstName(inAuthForm.getFirstName());

		authFormSchema.setRequesterContactFirstName(inAuthForm.getContactFirstName());
		if (HCSA) {
			authFormSchema.setRequesterContactLastName(inAuthForm.getContactLastName());
			//authFormSchema.setRequesterContactName(inAuthForm.getContactName());
		} else {
			//wierd but have to do this
			//authFormSchema.setRequesterContactName(inAuthForm.getContactLastName());
			authFormSchema.setRequesterContactLastName(inAuthForm.getContactName());
		}
		
		authFormSchema.setRequesterAddr(inAuthForm.getAddress().trim());
		authFormSchema.setRequesterCityNme(inAuthForm.getCity().trim());
		authFormSchema.setRequesterStCd(inAuthForm.getState().trim());
		
		//FOR HSCA, this field is being abused by sending some other data totally unrelated to this field
		authFormSchema.setRequesterZipCd(inAuthForm.getZip().trim());
	}

	
	
	/**
	 * @param objCreator
	 * @param authFormSchema
	 * @param commTexts
	 * @param commNumFormSchemaList
	 */
	protected void saveCommunicationData(ObjectFactory objCreator,
			AuthServReqActionFormSchema authFormSchema, List<String> commTexts,
			List<CommNumFormSchema> commNumFormSchemaList) {
		if (commTexts != null) {
			for (String commText : commTexts) {
				CommNumFormSchema commNum = mapCommNums(commText, objCreator);
				commNumFormSchemaList.add(commNum);
			}

			// Try to re-order the communication number as Telephone, Fax, and
			// then Email
			for (CommNumFormSchema commNumFormSchema : commNumFormSchemaList) {
				if (commNumFormSchema.getCommNumQual().equals("T")) {
					authFormSchema.getCommunicationNumbers().add(commNumFormSchema);
				}
			}
			for (CommNumFormSchema commNumFormSchema : commNumFormSchemaList) {
				if (commNumFormSchema.getCommNumQual().equals("F")) {
					authFormSchema.getCommunicationNumbers().add(commNumFormSchema);
				}
			}
			for (CommNumFormSchema commNumFormSchema : commNumFormSchemaList) {
				if (commNumFormSchema.getCommNumQual().equals("E")) {
					authFormSchema.getCommunicationNumbers().add(commNumFormSchema);
				}
			}
		}
	}


	

	/**
	 * @param inAuthForm
	 * @param authFormSchema
	 */
	private void saveSubscriberInformation(Subscriber subscriber, AuthServReqActionFormSchema authFormSchema) {
		logger.debug("Saving subscriber info  ...");
		authFormSchema.setSubscriberId(subscriber.getSubscriberId());
		authFormSchema.setSubscriberBirthDt(dateToString(subscriber.getDOB()));
		authFormSchema.setSubscriberLastName(subscriber.getLastName());
		authFormSchema.setSubscriberFirstName(subscriber.getFirstName());
		authFormSchema.setSubscriberMiddleName(subscriber.getMiddleName());
		
		//FOR HSCA, this field is being abused by sending some other data totally unrelated to this field
		authFormSchema.setSubscriberGender(subscriber.getGender());
	}




	private CommNumFormSchema mapCommNums(String commText, ObjectFactory objFac) {
		String[] numAndQualifier = commText.split(":");
		CommNumFormSchema outComm = objFac.createCommNumFormSchema();
		// outComm.setCommNumQual(numAndQualifier[0].substring(1)); //remove
		// paranthesis
		// outComm.setCommNum(numAndQualifier[1].substring(0,
		// numAndQualifier[1].length() - 1));
		outComm.setCommNumQual(numAndQualifier[0]);
		outComm.setCommNum(numAndQualifier[1]);
		return outComm;

	}
	


	private AuthServLineActionFormSchema mapAuthFormLineItems(ServiceInformation inLine, ObjectFactory objFac, boolean HCSA) {

		AuthServLineActionFormSchema outLine = objFac.createAuthServLineActionFormSchema();
		String valueToProcess = "";
		
		logger.debug("processing line item begin date ...");
		if (inLine.getBeginDate() != null) {
			outLine.setBeginDate(getNumberOfDaysFrom(inLine.getBeginDate()).toPlainString());
			//outLine.setBeginDate(Day.getNoOfDays(dateToString(inLine.getBeginDate())).toPlainString());
		} else {
			outLine.setBeginDate((new BigDecimal(0)).toPlainString());
		}
		logger.debug("processing line item end date ...");
		if (inLine.getEndDate() != null) {
			//int nbDays = firstDay.daysBetween(lastDay); 
			//BigDecimal days = new BigDecimal(nbDays);
			outLine.setEndDate(getNumberOfDaysFrom(inLine.getEndDate()).toPlainString());
			//outLine.setEndDate(Day.getNoOfDays(dateToString(inLine.getEndDate())).toPlainString());
		} else {
			outLine.setEndDate((new BigDecimal(0)).toPlainString());
		}
		
		logger.debug("processing line item procedure code ...");
		outLine.setProcedurePerformed(inLine.getProcedureCode());
		
		//Modifiers
		if (inLine.getModifiers() != null && !inLine.getModifiers().isEmpty()) {
			logger.debug("processing modifiers): '" + inLine.getModifiers() + "'");
			for (String modifier : inLine.getModifiers()) {
				ModifierFormSchema outMod = objFac.createModifierFormSchema();
				outMod.setModifier(modifier);
				outLine.getModifiers().add(outMod);
			}
		}
		
		logger.debug("processing line item quantity, line amount and comments ...");
		//Quantity and Line Amount
		outLine.setUnits(inLine.getQuantity());
		outLine.setTotalAmount(inLine.getLineAmount());
		if (!HCSA) {
			logger.debug("processing comments and model number (for non-HCSA only)...");			
//			if (StringUtils.isEmpty(inLine.getComments())) {
//				outLine.setComments("");
//			} else {
//				outLine.setComments(inLine.getComments());
//			}
			valueToProcess = inLine.getComments();
			outLine.setComments(StringUtils.isEmpty(valueToProcess) ? "" : valueToProcess);

			valueToProcess = inLine.getServiceDescriptionModelNumber();
			if (!StringUtils.isEmpty(valueToProcess)) {
				outLine.setModelNumber(valueToProcess);
			}
		} else {
			logger.debug("processing line item frequency (for HCSA only)  ...");
			outLine.setHcsaServiceFrequency(inLine.getTimePeriodQualifier());
		}
		
		logger.debug("processing line item provider info ...");
		//Provider related data
		Provider provider = inLine.getProvider();
		logger.debug("Provider mapAuthFormLineItems: " + provider.getNpi() + " | " + provider.getId() + " | " + provider.getFirstName() + " | " + provider.isServiceLineProviderNPInotInDB());
		saveServiceProviderInfo(outLine, provider);	
		
		logger.debug("processing line item dental info (if any) ...");
		//Dental data should NOT be processed for HCSA
		if (inLine.getDentalInformation() != null && !HCSA){
			//Get all Dental Needs Information - this should work for NON-HCSA transactions only
			//oral cavity, tooth surface, all that stuff
			saveDentalNeedsInforamtion(inLine, objFac, outLine);
		} else {
			logger.debug("HCSA transaction so no dental info processing will take place for this line item(s)  ...");
		}
		
		logger.debug("processing line item key and validity ...");
		outLine.setServLineKey(inLine.getServLineKey());
		outLine.setValidRequest(inLine.isValidRequest());

		//Print out the Line Item JSON
		try {
			logger.debug("Printing JSON of outLine");
			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(outLine);
			System.out.println(json);
		} catch (JsonProcessingException e) {
			System.out.println("An error to convert object to json");
			e.printStackTrace();
		}

		return outLine;
	}

	/**
	 * @param outLine
	 * @param provider
	 */
	private void saveServiceProviderInfo(AuthServLineActionFormSchema outLine, 	Provider provider) {
		logger.debug("processing provider info ..." + provider.getNpi() + " | ");
			logger.debug(provider.getId() + " | ");
			logger.debug(provider.getFirstName() + " | ");
		outLine.setServiceProviderNpiUmpi(provider.getNpi());
		outLine.setServiceProviderId(provider.getId());	//<service_provider_id>347470100</service_provider_id>
		logger.debug("Provider inside: " + provider.getNpi() + " | " + provider.getId() + " | " + provider.isServiceLineProviderNPInotInDB());
		outLine.setServiceProviderFirstName(provider.getFirstName());
		if (provider.getOrgName() != null && !provider.getOrgName().isEmpty()) {
			logger.debug(provider.getOrgName());
			outLine.setServiceProviderOrganizationLastName(provider.getOrgName());
		} else {
			outLine.setServiceProviderOrganizationLastName("");
		}
		logger.debug("finished processing provider info ...");
	}

	/**
	 * @param inLine
	 * @param objFac
	 * @param outLine
	 */
	protected void saveDentalNeedsInforamtion(ServiceInformation inLine,
			ObjectFactory objFac, AuthServLineActionFormSchema outLine) {
		
		// Dental Information
		DentalInformation dentalInformation = inLine.getDentalInformation();
		String valueToProcess = "";
		logger.debug("processing Dental information for non-HCSA transactions");
		if (dentalInformation != null) {	//this is non HCSA processing only coz HCSA always have NULL dental info
			
			//Tooth Number
			if (dentalInformation.getToothNumber() != null) {
				logger.debug("processing tooth number: '" + dentalInformation.getToothNumber() + "'");
				valueToProcess = dentalInformation.getToothNumber();
				outLine.setServiceToothNumber(StringUtils.isEmpty(valueToProcess) ? "" : valueToProcess);
			}
			
			//Tooth Surface Codes
			if (dentalInformation.getToothSurfaceCodes() != null&& dentalInformation.getToothSurfaceCodes().size()>0) {
				for (String toothSurfaceCode : dentalInformation.getToothSurfaceCodes()) {
					logger.debug("processing tooth surface(s): '" + toothSurfaceCode + "'");
					//if (!toothSurfaceCode.trim().isEmpty()) {
					ToothSurfFormSchema outToothSurf = objFac.createToothSurfFormSchema();
					outToothSurf.setSurf(toothSurfaceCode);
					outLine.getServiceToothSurf().add(outToothSurf);
					//}
				}
			}
			
			//Tooth Oral Cavities
			if (dentalInformation.getOralCavityDesignation() != null && dentalInformation.getOralCavityDesignation().size()>0) {
				for (String oralCavity : dentalInformation.getOralCavityDesignation()) {
					logger.debug("processing oral cavity(s): '" + oralCavity + "'");
					//if (!oralCavity.trim().isEmpty()) {
					OraCavityFormSchema outOra = objFac.createOraCavityFormSchema();
					outOra.setOraCavType(oralCavity);
					outLine.getOraCavDes().add(outOra);
					//}
				}
			}
			
			//Prosthesis
			if (dentalInformation.getProsthesis() != null) {
				logger.debug("processing Prosthesis: '" + dentalInformation.getProsthesis() + "'");
				valueToProcess = dentalInformation.getProsthesis();		//outLine.setProsthesis(dentalInformation.getProsthesis());
				outLine.setProsthesis(StringUtils.isEmpty(valueToProcess) ? "" : valueToProcess);
			}
		}
	}

	

	

	private AuthServRespActionFormSchema mapResponseXML(AuthResponseForm inResp) {
		AuthServRespActionFormSchema outRespForm = new AuthServRespActionFormSchema();
		outRespForm.setConfirmationId(inResp.getConfirmation_id());
		if (!(new Boolean(inResp.isDeferred()).toString().isEmpty())) {
			outRespForm
					.setDeferred(new Boolean(inResp.isDeferred()).toString());
		}
		outRespForm.setMnitsReturnCode(inResp.getMnitsReturnCode());
		outRespForm.setOltpReturnCode(inResp.getOltpReturnCode());
		if (inResp.getTcn() != null)
			outRespForm.setTcn(inResp.getTcn().toPlainString());
		outRespForm.setPAServiceResponseCode(inResp.getPAServiceResponseCode());
		return outRespForm;
	}
	
	
	
	/**
	 * @param inAuthForm
	 * @param authFormSchema
	 */
	protected void determineEarliestBeginDateAndLatestEndDate(
			AuthForm inAuthForm, AuthServReqActionFormSchema authFormSchema) {
		Date firstServBeginDate = null;
		Date lastServEndDate = null;
		Date servBeginDate = null;
		Date servEndDate = null;
		DateFormat myFormat = new SimpleDateFormat("MMddyyyy");

		// go thru all service line items and figure out the 1st Begin date and
		// last End date
		int serviceLineItemCounter = 0;
		// inAuthForm.setServices(Arrays.asList(inAuthForm.getSvc()));
		for (ServiceInformation serviceLineItem : inAuthForm.getServices()) {
			// AuthServLineActionForm servLineItemForm =
			// inAuthForm.getServLineForm(lineItem); //lineItem is counter
			if (serviceLineItemCounter == 0) {
				firstServBeginDate = serviceLineItem.getBeginDate();
				lastServEndDate = serviceLineItem.getEndDate();
			}
			servBeginDate = serviceLineItem.getBeginDate();
			servEndDate = serviceLineItem.getEndDate();

			// 1st try/catch block for the earliest Begin Date for any service
			try {
				if (firstServBeginDate.after(servBeginDate)) {
					firstServBeginDate = servBeginDate;
				}
			} catch (Exception e) {
				logger.debug("mapSA AuthForm >> : Error while comparing the service Begin Date to figure out the earliest Begin Date for any service.");
				System.out.print(e.getMessage());
				System.out.print(e.getStackTrace());
			}

			// 2nd try/catch block for the latest End date for any service
			try {
				if (lastServEndDate.before(servEndDate)) {
					lastServEndDate = servEndDate;
				}
			} catch (Exception e) {
				logger.debug("mapSA AuthForm >> : Error while comparing the service End Date to figure out the latest End date for any service.");
				System.out.print(e.getMessage());
				System.out.print(e.getStackTrace());
			}

			logger.debug ("Item " + (serviceLineItemCounter + 1));
			logger.debug("Earliest BeginDate for now -> "+ myFormat.format(firstServBeginDate));			// + " -> "	+ firstServBeginDate.toString()
			logger.debug("Latest EndDate for now -> "+ myFormat.format(lastServEndDate));				// + " -> "	+ lastServEndDate.toString()
			
			serviceLineItemCounter++;
		}
		// TODO
		// at this point I am going to use the subcriber Gender field
		// Srv-agreement-begin-date
		// and the zip-code field to store the srv-agreement-end-date
		// When the PASchema_new.xsd change then we should create real fields
		// to store Srv-agreement-begin-date and Srv-agreement-end-date
		if (firstServBeginDate != null & lastServEndDate != null) {
			logger.debug("firstServBeginDate" + " -> "	+ firstServBeginDate.toString());
			logger.debug("lastServEndDate" + " -> "	+ lastServEndDate.toString());
			authFormSchema.setSubscriberGender(getNumberOfDaysFrom(firstServBeginDate).toString());
			authFormSchema.setRequesterZipCd(getNumberOfDaysFrom(lastServEndDate).toString());
		}
	}

	
	
	
	
	/**
	 * @param inAuthForm
	 * @param authFormSchema
	 */
	protected void determineHcsaCodesAndSetFlags(AuthForm inAuthForm,
			AuthServReqActionFormSchema authFormSchema) {
		if (inAuthForm.getServices().size() > 0) {// TODO
			String procedureCodeFirstLine = inAuthForm.getServices().get(0)
					.getProcedureCode();
			logger.debug("The procedure code of the first service line: "
					+ procedureCodeFirstLine);

			if (procedureCodeFirstLine.trim().toUpperCase().equals("T1030")) {
				authFormSchema.setHcsaPaHomeHealthCode("");
				authFormSchema.setHcsaPaNurseCode("X");
				authFormSchema.setHcsaPaPdnRnCode("");
				authFormSchema.setHcsaPaPdnLpnCode("");
			} else if (procedureCodeFirstLine.trim().toUpperCase().equals("T1031")) { // 08/23/2019 RTC 35714
				authFormSchema.setHcsaPaHomeHealthCode("");
				authFormSchema.setHcsaPaNurseCode("X");
				authFormSchema.setHcsaPaPdnRnCode("");
				authFormSchema.setHcsaPaPdnLpnCode("");
			} else if (procedureCodeFirstLine.trim().toUpperCase().equals("T1021")) {
				authFormSchema.setHcsaPaHomeHealthCode("X");
				authFormSchema.setHcsaPaNurseCode("");
				authFormSchema.setHcsaPaPdnRnCode("");
				authFormSchema.setHcsaPaPdnLpnCode("");
			} else if (procedureCodeFirstLine.trim().toUpperCase().equals("T1002")) {
				authFormSchema.setHcsaPaHomeHealthCode("");
				authFormSchema.setHcsaPaNurseCode("");
				authFormSchema.setHcsaPaPdnRnCode("X");
				authFormSchema.setHcsaPaPdnLpnCode("");
			} else if (procedureCodeFirstLine.trim().toUpperCase().equals("T1003")) {
				authFormSchema.setHcsaPaHomeHealthCode("");
				authFormSchema.setHcsaPaNurseCode("");
				authFormSchema.setHcsaPaPdnRnCode("");
				authFormSchema.setHcsaPaPdnLpnCode("X");
			}

			// PL#2593 12/27/2011 Loi Adding Rating and shared cared to
			// mainframe mapping.
			if ((procedureCodeFirstLine.trim().toUpperCase().equals("T1021"))
					|| (procedureCodeFirstLine.trim().toUpperCase().equals("T1030"))
					|| (procedureCodeFirstLine.trim().toUpperCase().equals("T1031"))) { // 09/30/2019 RTC 35714 37641
				authFormSchema.setPaHcRating("HH");
			}
		}
	}

	/**
	 * @param authFormSchema
	 * @param HcsaAdditionalInfoMessageText
	 */
	
	protected void determineHcsaAdditionalInfo(AuthServReqActionFormSchema authFormSchema, String HcsaAdditionalInfoMessageText) {
		if (!HcsaAdditionalInfoMessageText.isEmpty()) {
			//int hcsa_service_add_info_message_text_length = HcsaAdditionalInfoMessageText.length();
			
			//Java 8 solution
			//for (String msg : Splitter.fixedLength(70).split(HcsaAdditionalInfoMessageText)) {
				
			//java 7
			String[] MessageStrings = HcsaAdditionalInfoMessageText.split("(?<=\\G.{70})");
			for (String msg : MessageStrings) {
				HcsaAdditionalInfoFormSchema hcsaAdditionalInfo = new HcsaAdditionalInfoFormSchema();
				hcsaAdditionalInfo.setAdditionalInfo(msg);
				authFormSchema.getHcsaAdditionalInfo().add(hcsaAdditionalInfo);
			}
		}
	}
	
	
	//**************** SMALL HELPER METHODS **************

	
	//OUTDATED function
	String dateToString(Date date) {
		if (date == null) {
			return new String("");
		}
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy"); 
		// this is correct date format. old format was breaking the XML and JMS response would timeout
		return dateFormat.format(date);
	}

	// Century Date Calculations
	private BigDecimal getNumberOfDaysFrom(Date thisDate) {
		SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		String dateToFormat = myFormat.format(thisDate);
		System.out.println("Processing against: " + dateToFormat);
/*		long finalcount = 0;
		Date startDate = null;
		
		startDate = myFormat.parse("12/31/1963");
		logger.debug("thisDate" + " -> "+ thisDate.toString() + "[" + myFormat.format(thisDate) + "] against "+ startDate.toString());
		long diffInMillies = Math.abs(thisDate.getTime() - startDate.getTime());
		finalcount = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);*/
		
//		long diff = Date2.getTime() - Date1.getTime();
//		System.out.println("Days: "	+ TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
//		return String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));		
		
		try {		
		//SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date startDate = myFormat.parse("12/31/1963");
		Date dateToProcess = myFormat.parse(dateToFormat);
			
			Day firstDay = new Day(startDate.getYear() + 1900, startDate.getMonth(), startDate.getDate());
			Day lastDay = new Day(dateToProcess.getYear() + 1900, dateToProcess.getMonth(),	dateToProcess.getDate());
			int nbDays = firstDay.daysBetween(lastDay); 
			BigDecimal days = new BigDecimal(nbDays);
			
			System.out.println("Days using the bigDecimal method: " + days.toPlainString());
//			BigDecimal days = new BigDecimal(nbDays);
			return days;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

		
		//logger.debug("Days from '" + myFormat.format(startDate) + "' are " + String.valueOf(finalcount));
		//BigDecimal days = new BigDecimal(finalcount);	
		//return String.valueOf(finalcount);	//if returning String
	}

	// private String convertToothNumFormat(String toothnum){
	// if(toothnum.length() == 1){
	// char ch = toothnum.charAt(0);
	// if (('0' <= ch) && (ch <= '9'))
	// toothnum="0"+toothnum;
	// }
	// return toothnum;
	// }

	private void CheckForRequiredFields(AuthServReqActionFormSchema req) {
		if (req.getRequesterContactName() == null) {
			logger.debug("	-->Contact name is empty or null");
		}
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		if (req.getCommunicationNumbers().size() == 0) {
			logger.debug("	-->Communcation numbers are empty or null");
		}
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req == null) {
		// logger.debug("	--> is empty or null");
		// }
		//

		if (req.getAuthCategoryType().equals(
				AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA)) { // AUTHORIZATION_CATEGORY_TYPE_MMIS_HCSA
																			// is
																			// 2
																			// but
																			// MNITS
																			// is
																			// 42
		// //check for 6 more fields
		// if (req.getRequesterContactFirstName() == null) {
		// logger.debug("	--> is empty or null");
		// }
		// if (req.getRequesterContactLastName() == null) {
		// logger.debug("	--> is empty or null");
		// }
		//
		}
	}

}