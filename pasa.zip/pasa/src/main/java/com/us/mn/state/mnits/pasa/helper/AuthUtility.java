package com.us.mn.state.mnits.pasa.helper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.us.mn.state.mnits.pasa.model.AuthForm;
import mn.dhsdirect.mnits.user.ActiveProviderInformation;
import mn.dhsdirect.mnits.user.ProviderInformationHandler;
import mn.dhsdirect.utils.StringConverter;

/**
 * @author pwqhp55
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AuthUtility implements AuthLoggingConstants {
	
	static Logger logger = LoggerFactory.getLogger(AuthUtility.class);
	
	  // Field descriptor #8 Ljava/lang/String;
	  public String FWD_SUCCESS = "success";
	  
	  // Field descriptor #8 Ljava/lang/String;
	  public String FWD_ERROR = "error";
	  
	  // Field descriptor #8 Ljava/lang/String;
	  public String FWD_WARNING = "warning";
	
	/**
	 * Set the current in-progress HCSA form set in the web context.
	 * @param form HcsaFormSet
	 * @param request HttpServletRequest The current HTTP request object
	 * @return HcsaFormSet
	 */	
	public static void setForm(AuthForm form, HttpServletRequest request) {
	
		/** Get the session object */
		HttpSession session = request.getSession(true);		// Create a new session if necessary
	
		/** Save the form to the session */
		session.setAttribute(AuthConstants.SESSION_ATTRIBUTE_FORMSET, form);
	}

	/**
	 * Get the current in-progress HCSA form set from the web context.
	 * @param request HttpServletRequest The current HTTP request object
	 * @return HcsaFormSet
	 */	
	public static AuthForm getForm(HttpServletRequest request) {
	
		AuthForm form = null;							// Return value of the method
		HttpSession session = request.getSession(false);	// Get the current session object, if any
		
		/** Look for an existing form set */
		if (session != null) {								// Look for it in the session, if any
			form = (AuthForm) request.getSession().getAttribute(AuthConstants.SESSION_ATTRIBUTE_FORMSET);
		}
		return form;
	}



	/**
	 * Get the current session.  Creates a new session, if requested.
	 * @param request HttpServletRequest The current HTTP request object
	 * @param create boolean true := Create a new session if one does not exist.
	 * @return HttpSession
	 */
	public static HttpSession getSession(HttpServletRequest request, boolean create) {
		HttpSession session = request.getSession(create);	// Get the current session object
	
		return session;
	}
	



	/**
	 * @param request
	 */
	public static void printHttpHeaders(HttpServletRequest request) {
		System.out.println("******************** Header variables ********************* ");
		System.out.println("Npi from header request: " + request.getHeader("dhsnpi"));
		System.out.println("UserId from header request: " + request.getHeader("userid"));
		System.out.println("providerid from header request: " + request.getHeader("providerid"));
		System.out.println("mnitsapprole from header request: " + request.getHeader("mnitsapprole"));
		System.out.println("dhsdeladmrole from header request: " + request.getHeader("dhsdeladmrole"));
		//if (isDebug) {
			logger.debug("ID: " + request.getSession(false).getId() + " timeout: " + request.getSession().getMaxInactiveInterval());
		//}
	}

	
	public static ProviderInformationHandler loadProvider(String npi) throws Exception {
	
		/** Create skeleton provider object */
		ActiveProviderInformation provider = new ActiveProviderInformation();

		/** Load from the database */
		if (StringConverter.isEmpty(npi)) {					// Providerid not specified
		} else {					
			try {
				provider.setNpinumber(npi);					// Set the NPI			    
			    System.out.println("Before running the Load() of ActiveProviderInformation") ;
				provider.load();
			    System.out.println("After running the Load() of ActiveProviderInformation") ;
			} 
			catch (Exception e) {							// Fatal.  Toss the exception
				throw new Exception("error.exception" + "Unable to load provider information" + "AuthUtility" + 
				  "AuthUtility" + "Calling ActiveProviderInformation.load(), " + "Calling ActiveProviderInformation.load(), " +  "Unable to load provider information");
			}
		}				
		return provider;
	    
	}
	
	
	
	public static void listTheBrowser(HttpServletRequest request) {
		// TODO Auto-generated method stub
	    String userAgent = "Unknown";
	    String osType = "Unknown";
	    String osVersion = "Unknown";
	    String browserType = "Unknown";
	    String browserVersion = "Unknown";
	    String deviceType = "Unknown";
	    String BrowesrName = null;
		

	    try {
	        userAgent = request.getHeader("User-Agent");
	        
	        //userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36 OPR/60.0.3255.165";
	        //userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0";
	        //userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36";
	        //userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134";
	        //userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 12_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.1 Mobile/15E148 Safari/604.1";
	        boolean exceptionTest = false;
	        
	        if(exceptionTest) throw new Exception("EXCEPTION TEST");

	        if (userAgent.indexOf("Windows NT") >= 0) {
	            osType = "Windows";
	            osVersion = userAgent.substring(userAgent.indexOf("Windows NT ")+11, userAgent.indexOf(";"));

	        } else if (userAgent.indexOf("Mac OS") >= 0) {
	            osType = "Mac";
	            osVersion = userAgent.substring(userAgent.indexOf("Mac OS ")+7, userAgent.indexOf(")"));

	            if(userAgent.indexOf("iPhone") >= 0) {
	                deviceType = "iPhone";
	            } else if(userAgent.indexOf("iPad") >= 0) {
	                deviceType = "iPad";
	            }

	        } else if (userAgent.indexOf("X11") >= 0) {
	            osType = "Unix";
	            osVersion = "Unknown";

	        } else if (userAgent.indexOf("android") >= 0) {
	            osType = "Android";
	            osVersion = "Unknown";
	        }
	        logger.trace("end of os section");

	        if (userAgent.contains("Edge/")) {
	            browserType = "Edge";
	            browserVersion = userAgent.substring(userAgent.indexOf("Edge")).split("/")[1];

	        } else if (userAgent.contains("Safari/") && userAgent.contains("Version/")) {
	            browserType = "Safari";
	            browserVersion = userAgent.substring(userAgent.indexOf("Version/")+8).split(" ")[0];

	        } else if (userAgent.contains("OPR/") || userAgent.contains("Opera/")) {
	            browserType = "Opera";
	            browserVersion = userAgent.substring(userAgent.indexOf("OPR")).split("/")[1];

	        } else if (userAgent.contains("Chrome/")) {
	            browserType = "Chrome"; 
	            browserVersion = userAgent.substring(userAgent.indexOf("Chrome")).split("/")[1];
	            browserVersion = browserVersion.split(" ")[0];

	        } else if (userAgent.contains("Firefox/")) {
	            browserType = "Firefox"; 
	            browserVersion = userAgent.substring(userAgent.indexOf("Firefox")).split("/")[1];
	        }            
	        logger.trace("end of browser section");

	    } catch (Exception ex) {
	        logger.error("ERROR: " +ex);            
	    }

	    logger.debug(
	              "\n userAgent: " + userAgent
	            + "\n osType: " + osType
	            + "\n osVersion: " + osVersion
	            + "\n browserType: " + browserType
	            + "\n browserVersion: " + browserVersion
	            + "\n deviceType: " + deviceType
	            );
	    
	    BrowesrName = userAgent;
	    logger.debug("Browser: " + BrowesrName);
	}
	

	private void processAction(String name, String action) {
		String newName = name;							// Name of forward, processed
		//String model = action.getCode();				// Name of the model


		logger.debug("I am in processAction method of controller.");			
		
		// Look for an existing auth Formset in the session of request object
		AuthForm authForm = new AuthForm(); //AuthUtility.getFormSet(request);		
		
//		if (newName.equals(FWD_ERROR)) {
//			newName = FWD_ERROR;
//		}
//		else if (!(authForm.getValidRequest())) {
//			newName = AuthConstants.PA_SUBMITED_WITH_VALIDATION_ERRORS ;		    
//		}
//		else {
			newName = FWD_SUCCESS;						
//		}
		
		if (newName.equals(FWD_SUCCESS))
		{			
			// The Prior Auth is approved
			if (authForm.getResponseForm().isPaApproved())
			{
				newName = AuthConstants.PA_SUBMITED_WITH_APPROVED;
				logger.debug("The Prior Auth is approved with action: " + newName);
			}
			// The Prior Auth is not required
			else if (authForm.getResponseForm().isPaNotRequired())
			{
				newName = AuthConstants.PA_SUBMITED_BUT_NOT_REQUIRED;
				logger.debug("The Prior Auth is not required with action: " + newName);
			}
			// The Prior Auth is deferred
			else if (authForm.getResponseForm().isPaDeferred())
			{
				newName = AuthConstants.PA_SUBMITED_WITH_DEFERRED;
				logger.debug("The Prior Auth is deferred with action: " + newName);
			}
			else if (authForm.getResponseForm().isPaDenied())
			{
				newName = AuthConstants.PA_SUBMITED_WITH_DENIED;
				logger.debug("The Prior Auth is dinied with action: " + newName);							
			}
			// The Prior Auth is with errors
			else if (authForm.getResponseForm().isPaInvalid())
			{
				newName = AuthConstants.PA_SUBMITED_WITH_ERRORS;
				logger.debug("The Prior Auth is with errors with action: " + newName);
			}
			// The Prior Auth needs additional information
			else if (authForm.getResponseForm().isPaAddInfoRequired())
			{
				newName = AuthConstants.PA_SUBMITED_BUT_ADD_INFO_REQUIRED;
				logger.debug("The Prior Auth needs additional information with action: " + newName);
			}
			else
			{
				newName = FWD_ERROR;		
				logger.debug("I am inside the " + this.getClass().getName() + ".processForward(). " +
		        "but cannot find the Forward Action"); 
			}
		}

	}
	
}
