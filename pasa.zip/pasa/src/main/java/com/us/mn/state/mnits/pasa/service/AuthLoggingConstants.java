
package com.us.mn.state.mnits.pasa.service;


/**
 * @author pwqhp55
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface AuthLoggingConstants {
	
	/* Pre-defined message types */
	/** Notes a validation error in user entry */
	public static final String ERR_FORM_VALID = "error.form.validation";
	public static final String ERR_FORM_EMPTY = "error.form.empty";
	
	/** Notes the exceeding of table row count limits*/
	public static final String TYPE_VALIDATION_LIMITS_EXCEEDED = "error.validation.limits";
	
	/** Notes an error in results data returned to the user */
	public static final String TYPE_VALIDATION_RESULT = "error.validation.result";
	
	/** Notes too general a query */
	public static final String ERR_MAX_ROWS = "warning.row.limits.exceeded";
	
	/** Notes an error in database persistence operations */
	public static final String TYPE_PERSISTER_ERROR = "error.persister";

	/** Notes a connection to MMIS */
	public static final String TYPE_HOST_CONNECT_MSG = "msg.trace.host.connect";	
	
	/** Notes an error trying to connect to MMIS */
	public static final String TYPE_HOST_CONNECT_ERROR = "error.host.connect";	
	
	/** Notes a warning trying to connect to MMIS */
	public static final String TYPE_HOST_CONNECT_WARNING = "warning.host.connect";	
	
	/** Notes an error reported by MMIS */
	public static final String TYPE_HOST_APP_ERROR = "error.host.app";	
	
	/** Notes warning reported by MMIS */
	public static final String TYPE_HOST_APP_WARNING = "warning.host.app";
	
	/** Notes an event of undetermined nature reported by MMIS */
	public static final String TYPE_HOST_NOTE = "msg.trace";
	
	/** Notes an error in the EJB engine */	
	public static final String TYPE_EJB_FAILURE = "failure.ejb";

	/** Notes a warning from the EJB engine */	
	public static final String TYPE_EJB_WARNING = "warning.ejb";

	/** Notes a security warning, accessing an unauthorized provider */	
	public static final String TYPE_SECURITY_WARNING_PVACCESS = "warning.security.pvaccess";
	
	/** Notes a security warning, accessing a non-rollup provider */	
	public static final String TYPE_SECURITY_WARNING_ROLLUP = "warning.security.rollup";
	
	/** Notes the exceeding of table row count limits*/

	/** Notes logs of database persistence operations */
	public static final String TYPE_PERSISTER_MSG = "msg.trace.persister";
	
	/* Pre-defined severity levels */
	
	/* Pre-defined system scopes */
	
}
