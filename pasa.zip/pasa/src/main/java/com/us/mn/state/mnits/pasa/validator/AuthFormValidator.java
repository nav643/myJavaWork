package com.us.mn.state.mnits.pasa.validator;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.us.mn.state.mnits.pasa.helper.AuthConstants;
import com.us.mn.state.mnits.pasa.model.AuthForm;
import com.us.mn.state.mnits.pasa.model.ServiceInformation;
import com.us.mn.state.mnits.pasa.model.ServiceInformationForValidation;
import com.us.mn.state.mnits.pasa.service.PriorAuthorizationService;
import com.us.mn.state.mnits.pasa.web.PASAController;

import org.apache.commons.validator.GenericValidator;

//http://docs.spring.io/spring/docs/current/spring-framework-reference/html/validation.html#validation-mvc-configuring
@Component
public class AuthFormValidator implements Validator {
	
	private final Logger logger = LoggerFactory.getLogger(PASAController.class);
	private boolean isDebug = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp") > 0;
	
	@Autowired
	PriorAuthorizationService pasaService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return AuthForm.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		//get the form to validate
		AuthForm formForValidation = (AuthForm) target;
		String valueToValidate = "";
		String patternToMatch = "";
		boolean isDateValid = false;
		
		//date comparison issues - RTC 51304
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date centuryStartDate = null;
		Date centuryDOBStartDate = null;
		Date centuryEndDate = null;		//end date for DOB century as well as PASA processing century
		try {
			centuryStartDate = formatter.parse("01/01/1964");
			centuryEndDate = formatter.parse("12/31/2063");	
			centuryDOBStartDate = formatter.parse("01/01/1801");
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
//		String dateString = serviceLineItem.getBeginDate().toString();
//		DateFormat formatter = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
//	    Date dTemp=formatter.parse(dateString);
//	    if (isDebug) { logger.debug("Begin Date value " +serviceLineItem.getBeginDate().toString() + " is accepted"); }
//	    
	    //change to new format
//	    formatter=new SimpleDateFormat("MM/dd/yyyy");
//	    String d_temp=formatter.format(dTemp);
//	    if (isDebug) { logger.debug("Conversion to MM/dd/yyy value " + d_temp + " is accepted"); }
		
		
		//if session has not timeout then run the validation rules below
		if (formForValidation != null ) { 	//&& httpSession!=null
			logger.debug("Validator: Form or Session not valid hence redirecting to GET");
			//return "redirect:/authPA"; 

			//***************************Request NPI cannot be empty!***************************	
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "requestNpi", "NotEmpty.authForm.requesterNpi");
//			valueToValidate = formForValidation.getRequestNpi();
//			patternToMatch = "^[a-zA-Z0-9]+$";
//			if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
//				errors.rejectValue("requestNpi", "", "AlphanumericOnly.authForm.requesterNpi");
//			} else {
//				if (!StringUtils.isEmpty(valueToValidate) && valueToValidate.length() != 10) {
//					//MHCP recognizes only a value of 10 digits in Requester NPI/UMPI.
//					errors.rejectValue("requestNpi", "", "Valid.authForm.length");
//				}
//			}
			
			
			
			//*************************** HCSA focused simple quick validation - contact names***************************
			if (AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA.equals(formForValidation.getSelectedServiceTypeCode())) {
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactFirstName", "NotEmpty.authForm.contactFirstName");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactLastName", "NotEmpty.authForm.contactLastName");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pe.eventDate", "NotEmpty.authForm.eventDate");
				
				//and&*$%#@!<>?{}~`
				//if contact name fields are not empty - check for alpha numeric
				
				valueToValidate = formForValidation.getContactFirstName();
				patternToMatch = "^[a-zA-Z0-9\\s-]+$";
				if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
				 errors.rejectValue("contactFirstName", "AlphanumericOnly.authForm.contactFirstName");
				}
				 
				valueToValidate = formForValidation.getContactLastName();
				if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
				 errors.rejectValue("contactLastName", "AlphanumericOnly.authForm.contactLastName");
				}

				if (formForValidation.getPe().getEventDate() != null) {		
					//if event date is not empty, let's make sure it passes century date tests and it is not after today
					Date patientEventDate = formForValidation.getPe().getEventDate();
									
					//more tests for century date
					if (patientEventDate.before(centuryStartDate) || patientEventDate.after(centuryEndDate)) {
						//if (dTemp.before(when) || dTemp.after(when)) {
						errors.rejectValue("pe.eventDate", "", "Invalid Patient Event Date. Choose a date in the range of 01/01/1964 and 12/31/2063");
					} else {
						Date todayDate = new Date();
						if (patientEventDate.after(todayDate) ) { 
							errors.rejectValue("pe.eventDate", "Invalid.authForm.eventDate"); 
						}
					}
				}
				
				
				//The end date is also a required field for HCSA.  its validations are below since it is a line item level field
				
				
				
			} else {
				//*************************** Medical, Durable and Dental focused simple quick validation - contact names***************************
					
				//non-HCSA
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "contactName", "NotEmpty.authForm.contactName");
				
				patternToMatch = "^[a-zA-Z0-9\\s-/]+$";
				//if name fields are not empty - check for alpha numeric
				
				//add null check and isEmpty () check
				valueToValidate = formForValidation.getContactName();
				if (valueToValidate != null && !StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
					errors.rejectValue("contactName", "AlphanumericOnly.authForm.contactName");
				}
			}
			
			
			
			
			
			
			// *************************** Communication info related***************************
			patternToMatch = "^[a-zA-Z0-9@_/-:.]+$";
			if(formForValidation.getCommunicationText() == null || formForValidation.getCommunicationText().size()==0 ) {
				//Communication Number is invalid. The Telephone Number only accepts numeric characters without '-' or '/'
				//Communication Number is invalid. The Fax Number only accepts numeric characters without '-' or '/'
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "communicationText", "NotEmpty.authForm.communicationNumber");
			} else {
				for (String communicationInfo : formForValidation.getCommunicationText()) {
					if (communicationInfo.matches(patternToMatch)) {
						if ((communicationInfo.indexOf('T') == 0 | communicationInfo.indexOf('F') == 0) & 
								(communicationInfo.indexOf('-') > -1 | communicationInfo.indexOf('/') > -1 | communicationInfo.length() < 12)) {
							errors.rejectValue("communicationText","invalidFormat.authForm.communicationPhoneNumber");	
						}
						
						//Check for email
						if (communicationInfo.indexOf('E') > -1 ) {
							patternToMatch = "^(.+)@(.+)$";
							if (!communicationInfo.matches(patternToMatch) | (communicationInfo.indexOf('@') == -1 | communicationInfo.indexOf('.') == -1)) {
								errors.rejectValue("communicationText","invalidFormat.authForm.communicationEmail");
							}
							patternToMatch = "^[a-zA-Z0-9@_/-:.]+$";
						}
					} else {
						errors.rejectValue("communicationText", "AlphanumericOnly.authForm.communicationText");
					}
					
				}	//finished checking all communication information
			}
			
			
			
			
			//***************************related to subscriber***************************
			valueToValidate = formForValidation.getSub().getSubscriberId();
			if (StringUtils.isEmpty(valueToValidate)){
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sub.subscriberId", "NotEmpty.authForm.subscriberId");
			} else if (valueToValidate.length() != 8){
				errors.rejectValue("sub.subscriberId", "invalidCharacterLength.authForm.subscriberId");
			} else if (!StringUtils.isNumeric(valueToValidate)) {
				errors.rejectValue("sub.subscriberId", "NumericOnly.authForm.subscriberId"); 
			}
	
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sub.DOB", "NotEmpty.authForm.subscriberDOB");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sub.lastName", "NotEmpty.authForm.subscriberLastName");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sub.firstName", "NotEmpty.authForm.subscriberFirstName");	//Invalid value for SUBSCRIBER First Name in the Authorization Tab. The SUBSCRIBER First Name is required.
	
			if (formForValidation.getSub().getDOB() != null) {
				//if DOB is not empty, let's make sure it passes century date tests
				Date subscriberDOB = formForValidation.getSub().getDOB();
				
				//more tests for century date
				if (subscriberDOB.before(centuryDOBStartDate) || subscriberDOB.after(centuryEndDate)) {
					//if (dTemp.before(when) || dTemp.after(when)) {
					errors.rejectValue("sub.DOB", "", "Invalid Subscriber DOB Date. Choose a date in the range of 01/01/1801 and 12/31/2063");
				}
			}
			
			
			//if name fields are not empty - check for alpha numeric
			valueToValidate = formForValidation.getSub().getFirstName();
			patternToMatch = "^[a-zA-Z0-9\\s-]+$";
			if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
				errors.rejectValue("sub.firstName", "AlphanumericOnly.authForm.sub.firstName");
			}
			
			valueToValidate = formForValidation.getSub().getMiddleName();
			if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {		//optional field
				if (!valueToValidate.matches(patternToMatch)) {
					errors.rejectValue("sub.middleName", "AlphanumericOnly.authForm.sub.middleName");
				}
			}
			
			valueToValidate = formForValidation.getSub().getLastName();
			if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
				errors.rejectValue("sub.lastName", "AlphanumericOnly.authForm.sub.lastName");
			}
			
			
			
			//*************************** Patient event - Diagnosis code ***************************
			//This is not a required field for Dental CARE
			if (!AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_DENTAL.equals(formForValidation.getSelectedServiceTypeCode())) {
				if(formForValidation.getPe().getDiagnosisCodes().size()==0 ) {
					errors.rejectValue("pe.diagnosisCodes", "NotEmpty.authForm.diagnosisCodes");
				} 		
			} 

			if(formForValidation.getPe().getDiagnosisCodes().size() > 5 ) {
				errors.rejectValue("pe.diagnosisCodes", "invalidLength.authForm.diagnosisCodes");
			} else {
				//MN-ITS expects a decimal point in this field and MN-ITS will determine placement of the decimal point. 
				//If the number entered is smaller than three digits in length (i.e. 27), MN-ITS will place the decimal point to the right of the last digit (i.e.27.).
				//If the number entered is larger than three digits in length (i.e.74365), MN-ITS will place the decimal point after the third and before the fourth digit (i.e. 743. 65).
				for (String diagnosisCode : formForValidation.getPe().getDiagnosisCodes()) {
					valueToValidate = diagnosisCode;
					patternToMatch = "^[a-zA-Z0-9.]+$";
					if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
						errors.rejectValue("pe.traceNumber", "AlphanumericOnly.authForm.pe.diagnosisCodes");
					} else if (diagnosisCode.length() < 3 | diagnosisCode.length() > 8 ) {	//
						errors.rejectValue("pe.diagnosisCodes", "invalidCharacterLength.authForm.diagnosisCodes");
					} else if (diagnosisCode.indexOf('.') == -1) {
						errors.rejectValue("pe.diagnosisCodes", "", "Diagnosis codes must have a decimal in each of them");
					}
				}
			}// checking it is dental care
			
			//Common Fields
			valueToValidate = formForValidation.getPe().getTraceNumber();
			patternToMatch = "^[a-zA-Z0-9\\s-]+$";
			if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
				errors.rejectValue("pe.traceNumber", "AlphanumericOnly.authForm.pe.traceNumber");
			}
		
			
			
			//***************************NON-Required / OPTIONAL HCSA fields***************************
			
			if (AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA.equals(formForValidation.getSelectedServiceTypeCode())) {		
				//Supplement id
				valueToValidate = formForValidation.getSupplementId();
				if (!StringUtils.isEmpty(valueToValidate)) {
					if (!StringUtils.isNumeric(valueToValidate)) {
						errors.rejectValue("supplementId",  "NumericOnly.authForm.supplementId");
					} 
					if (valueToValidate.length() != 3) {
						errors.rejectValue("supplementId", "invalidLength.authForm.supplementIdTribeId");
					}
				}
				
				//Message text restricted to 264 characters
				patternToMatch = "^[a-zA-Z0-9.,\\s-]+$";
				valueToValidate = formForValidation.getPe().getMessageText().toString();
				if (!StringUtils.isEmpty(valueToValidate)) {
					if (!valueToValidate.matches(patternToMatch)) {
						errors.rejectValue("pe.messageText", "AlphanumericOnly.authForm.pe.messageText");
					}
				}
			} else {
				
				//Non HCSA optional fields
			}
			
			//Common Fields
			//if (!StringUtils.isEmpty(formForValidation.getPe().getTraceNumber()))
			
			
			
			
			//***************************All line items related code***************************
			//Iterate thru all these items and figure out the validation errors for both options (medical and HHC)
			ObjectMapper mapper = new ObjectMapper();
			
			try {
				//get full line item object data as text
				List<ServiceInformationForValidation> serviceLineItemsListBuiltByMapper = mapper.readValue(formForValidation.getServiceLineItems(), new TypeReference<List<ServiceInformationForValidation>>() { });
				//formForValidation.setServices(serviceLineItemsListBuiltByMapper);
				//List<ServiceInformation> serviceLineItemsListBuiltByMapper = mapper.readValue(formForValidation.getServiceLineItems(), new TypeReference<List<ServiceInformation>>() { });
				
				// work with individual line items here
				if (serviceLineItemsListBuiltByMapper != null && serviceLineItemsListBuiltByMapper.size() > 0) {
										
					//try {		// for catch block at line 508 or close to it

						
			// ******************** confirm this object has non null values ***********************
						for (ServiceInformationForValidation serviceLineItem : serviceLineItemsListBuiltByMapper) {
							int index = 0;
							if (serviceLineItem.getBeginDate() == null && 
									StringUtils.isEmpty(serviceLineItem.getLineAmount()) &&
									StringUtils.isEmpty(serviceLineItem.getQuantity()) &&
									StringUtils.isEmpty(serviceLineItem.getProcedureCode())) {
								//minimumServiceLineItemsAreAllNotPresent = true;
								
								logger.debug(serviceLineItem + " Item #" + index  + "-> Standard (and non-HCSA) errors: for NULL service Line Item" );
								errors.rejectValue("svc.beginDate", "", "SV" + (index + 1) + ": Begin Date is required");
								errors.rejectValue("svc.procedureCode", "", "SV" + (index + 1) + ": Procedure Code is required");
								errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity is required");
								errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount is required");
								
								//HCSA - also throw message about these null item fields
								if (formForValidation.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA)) {
									logger.debug(serviceLineItem + " Item #" + index  + "-> HCSA errors: for NULL service Line Item" );
									errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": End Date is required");
									errors.rejectValue("svc.provider.npi", "", "SV" + (index + 1) + ": Service Provider NPI is required");
									errors.rejectValue("svc.timePeriodQualifier", "", "SV" + (index + 1) + ": Time Period Qualifier is required");
								}
							} else {
			// **************  work with individual line items here *******************
						//if (ServiceLineItemsAreNull && serviceLineItemsList.size() > 0) {
						
							//int index = 0;
							//for (ServiceInformation serviceLineItem : formForValidation.getServices()) {
								int currentErrorCount = errors.getFieldErrorCount();
								
								if (isDebug) {
									logger.debug("Line Item " + index  + " -> " + 
												serviceLineItem.getProcedureCode() + "|" + 	serviceLineItem.getBeginDate() + "|" + 
												serviceLineItem.getQuantity() + "|" + serviceLineItem.getLineAmount()
											);
									logger.debug("	-> Running Basic(empty) on BeginDate|Procedure Code|Quantity|LineAmount" );						
									logger.debug("	Entry: " + currentErrorCount + " field errors and " + currentErrorCount + " global error count");
								}
								
								
								//*************************** Line Item Begin Date ***************************
								if (serviceLineItem.getBeginDate() == null || StringUtils.isEmpty(serviceLineItem.getBeginDate().toString())){
									errors.rejectValue("svc.beginDate", "", "SV" + (index + 1) + ": Begin Date is required");
								} else {
									
									//--typeMismatch.authForm.svc.beginDate = Service Begin Date is invalid
		//							String dateString = serviceLineItem.getBeginDate().toString();
		//							DateFormat formatter = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
		//						    String d_temp=formatter.format(dTemp);
//									
//									Date dTemp=null;
//									String dateForValidation = serviceLineItem.getBeginDate();
//									//dTemp = serviceLineItem.getBeginDate();
//									//String d_temp=formatter.format(dTemp.toString());
//									
//									//Date dTemp=formatter.parse(dateString);
//									formatter=new SimpleDateFormat("MM/dd/yyyy");
//									String formattedDateForValidation=formatter.format(dateForValidation);
									boolean isBeginDateValid = isValid(serviceLineItem.getBeginDate());
									    
									//isDateValid = GenericValidator.isDate(formattedDateForValidation,"MM/dd/yyyy", true);
									if (!isBeginDateValid) {
										errors.rejectValue("svc.beginDate", "", "SV" + (index + 1) + ": Invalid Service Begin Date. Enter a valid date in the format MM/DD/YYYY");
									} else {
										Date dTemp=formatter.parse(serviceLineItem.getBeginDate());
										//serviceLineItem.setBeginDate(dTemp);
										//more tests for century date
										if (dTemp.before(centuryStartDate) || dTemp.after(centuryEndDate)) {
											//if (dTemp.before(when) || dTemp.after(when)) {
											errors.rejectValue("svc.beginDate", "", "SV" + (index + 1) + ": Invalid Service Begin Date. Choose a date in the range of 01/01/1964 and 12/31/2063");
										}
									}
										
								}
								
								
								//*************************** Line Item Procedure Code ***************************
								valueToValidate = serviceLineItem.getProcedureCode();
								if (StringUtils.isEmpty(valueToValidate)){
									errors.rejectValue("svc.procedureCode", "", "SV" + (index + 1) + ": Procedure Code is required");
								} else if (valueToValidate.length() < 5 ) {	//
									errors.rejectValue("svc.procedureCode", "", "SV" + (index + 1) + ": MHCP recognizes only CPT/HCPCS code values of five characters in Procedure Code.");
								} else {
									patternToMatch = "^[a-zA-Z0-9]+$";
									if ( !valueToValidate.matches(patternToMatch)) {
										errors.rejectValue("svc.procedureCode", "", "SV" + (index + 1) + ": Procedure Code can only accept Alphanumeric values.");
									}
								}
								
								
								
								//*************************** Line Item Quantity validations ***************************
								if (StringUtils.isEmpty(serviceLineItem.getQuantity())){
									errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity is required");
								} else {
									String quantity = serviceLineItem.getQuantity();
									//patternToMatch = "^[a-zA-Z0-9]+$";
									
									if ( !StringUtils.isNumeric(quantity)) {
										errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity can only accept Numeric values.");
									} else if ( NumberUtils.createInteger(quantity) == 0 ) {
										errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity cannot be zero.");
									} else if (quantity.length() > 15) { 
										logger.debug(serviceLineItem + " Item #" + index  + "-> Quantity character length" );
										errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity cannot be longer than 15 digits."); 
									} else if (quantity.indexOf('.') > -1) { 
										logger.debug(serviceLineItem + " Item #" + index  + "-> Quantity character length" );
										errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Invalid value '" + quantity + "' for Quantity in the Service Line " + "SV" + (index + 1) + ". Invalid value in Quantity Field."); 
									}
								}
								
								
								
								//*************************** Line Item amount validations (many of them) ***************************
								if (StringUtils.isEmpty(serviceLineItem.getLineAmount())){
									errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount is required");
								} else {
									String lineAmount = serviceLineItem.getLineAmount();
									boolean decimalFound = lineAmount.indexOf('.') > -1;
									patternToMatch = "^[0-9]{0,9}(\\.[0-9]{1,2})?$";
									if ( !lineAmount.matches(patternToMatch)) {
										errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount can only accept Numeric values with 2 decimals");
									} else if (!validateLineAmount(lineAmount)) {
										errors.rejectValue("svc.lineAmount", "", "Invalid value '" + lineAmount + "' for Amount for SV" + (index + 1) + " in the Services Tab. Invalid format: Line amt must have two decimals.");	//Invalid Service Line Amount: the correct format is 7777777.99	//Invalid format: Line amt must have  two decimals
									}
//									) {NumberUtils.isNumber(lineAmount) && 
//										logger.debug(serviceLineItem + " Item #" + index  + "-> Invalid format: Line amt, requires decimals." );
//										errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Invalid format: Line amt, requires decimals.");
//									} else if (NumberUtils.isNumber(lineAmount) &&  !(NumberUtils.toDouble(lineAmount) > 0)) {
//											errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Invalid format: Zero Line amt is not allowed.");
//									} else if (NumberUtils.isNumber(lineAmount) && decimalFound && (lineAmount.length()  - (lineAmount.indexOf('.') +1) != 2) ) {
//										errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Invalid format: Line amt must have  two decimals");
//									} else {
//										if (!validateLineAmount(lineAmount)) {
//											errors.rejectValue("svc.lineAmount", "", "Invalid value " + lineAmount + " for Amount in the Service Line " + (index + 1) + " in the Services Tab. Invalid Service Line Amount: the correct format is 7777777.99");	//Invalid format: Line amt must have  two decimals
//										}
//									}
//									} else if (((lineAmount.length() > 11) && (decimalFound))) { 
//										logger.debug(serviceLineItem + " Item #" + index  + "-> Line Amount Length cannot be greater than 11 including decimal" );
//										errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount Length cannot be greater than 11 including decimal");		//"SV" + (index+1) + ": " + 
//									} else if ((lineAmount.length() > 10) & (!decimalFound)) { 
//										logger.debug(serviceLineItem + " Item #" + index  + "-> Line Amount Length missing decimal in full 11 length (10 length without decimal)" );
//										errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount can only be 10 digits long (11 digits long including the decimal)");		//"SV" + (index+1) + ": " + 
//									}  //defect 51304
								}
				
								if (isDebug) {
									logger.debug("	Exit: " + errors.getFieldErrorCount() + " field errors and " + errors.getGlobalErrorCount() + " global error count");					logger.debug("	Basic Run: " + (errors.getFieldErrorCount() - currentErrorCount) + " new BASIC errors found for this Line item");
									
									logger.debug("	-> Running some elaborated tests on BeginDate|Procedure Code|Quantity|LineAmount" );			
									currentErrorCount = errors.getFieldErrorCount();
									
									//more validations on character lengths for Quantity and Line Items
									logger.debug("	Elaborated Run: " + (errors.getFieldErrorCount() - currentErrorCount) + " new ELABORATED errors found for this Line item");
								}
				
								
								
								//*************************** HCSA required fields validations ***************************
								//REQUIRED provider NPI, Time period qualifier and end date
							    //isDateValid = GenericValidator.isDate(serviceLineItem.getEndDateString(),"MM/dd/yyyy", true);
								
								if (formForValidation.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA)) {
									logger.debug(serviceLineItem + " Item #" + index  + "-> HCSA errors: provider NPI and end date" );
									if (serviceLineItem.getEndDate() == null || StringUtils.isEmpty(serviceLineItem.getEndDate().toString())){
										errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": End Date is required");
									} else {
										validateEndDate(errors, formatter, centuryStartDate, centuryEndDate, index, serviceLineItem, isDateValid);
									}
									
									valueToValidate = serviceLineItem.getProvider().getNpi();
									patternToMatch = "^[a-zA-Z0-9]+$";
									if (StringUtils.isEmpty(valueToValidate)){
										errors.rejectValue("svc.provider.npi", "", "SV" + (index + 1) + ": Service Provider NPI is required");
									}
									
									if (StringUtils.isEmpty(serviceLineItem.getTimePeriodQualifier())) {
										errors.rejectValue("svc.timePeriodQualifier", "", "SV" + (index + 1) + ": Time Period Qualifier is required");
									}
								} else {
									
									//OPTIONAL field but since user provided an end date, let's validate for accuracy
									if (serviceLineItem.getEndDate() != null && !StringUtils.isEmpty(serviceLineItem.getEndDate().toString())){
										validateEndDate(errors, formatter, centuryStartDate, centuryEndDate, index, serviceLineItem, isDateValid);
									}
										
									
									//Description for a service field
									patternToMatch = "^[a-zA-Z0-9.,\\s]+$";
									valueToValidate = serviceLineItem.getDescription();
									if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
										errors.rejectValue("svc.description", "", "SV" + (index + 1) + ": Service Description can only accept Alphanumeric values.");
									}
									
									//service description model number
									patternToMatch = "^[a-zA-Z0-9\\s]+$";
									valueToValidate = serviceLineItem.getServiceDescriptionModelNumber();
									if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
										errors.rejectValue("svc.ServiceDescriptionModelNumber", "", "SV" + (index + 1) + ": Service description model number can only accept Alphanumeric values and space.");
									}
								}

								//OPTIONAL FIELD for all transactions
								
								//service line item NPI
								patternToMatch = "^[a-zA-Z0-9]+$";
								valueToValidate = serviceLineItem.getProvider().getNpi();
								if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
									errors.rejectValue("svc.provider.npi", "", "SV" + (index + 1) + ": Provider NPI  can only accept Alphanumeric values.");
								} else {
									if (!StringUtils.isEmpty(valueToValidate) && valueToValidate.length() != 10) {
										errors.rejectValue("svc.provider.npi", "", "SV" + (index + 1) + ": Provider id must be 10 Alphanumeric characters");		//"SV" + (index+1) + ": " + 
									} else if (!StringUtils.isEmpty(valueToValidate) && serviceLineItem.getProvider().isServiceLineProviderNPInotInDB()) {
										errors.rejectValue("svc.provider.serviceLineProviderNPInotInDB", "", "SV" + (index + 1) + ": Invalid value '" + serviceLineItem.getProvider().getNpi() + "' for The Service Provider NPI/UMPI in the Service Line " + (index + 1) + " in the Services Tab.");
									}
								}
								
								valueToValidate = serviceLineItem.getProvider().getOrgName();
								if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
									errors.rejectValue("svc.provider.orgName", "", "SV" + (index + 1) + ": Provider Org Name  can only accept Alphanumeric values.");
								}
								
								valueToValidate = serviceLineItem.getProvider().getFirstName();
								if (!StringUtils.isEmpty(valueToValidate) && !valueToValidate.matches(patternToMatch)) {
									errors.rejectValue("svc.provider.firstName", "", "SV" + (index + 1) + ": Provider First Name  can only accept Alphanumeric values.");
								}
								
								if(formForValidation.getSvc().getModifiers().size() > 4 ) {		//TODO: size() > 4
									errors.rejectValue("svc.modifiers", "", "SV" + (index + 1) + ": Only 4 Modifiers are allowed.");
								} else {
									patternToMatch = "^[a-zA-Z0-9]+$";
									for (String modifier : serviceLineItem.getModifiers()) {
										if ( !modifier.matches(patternToMatch) ) {
											errors.rejectValue("svc.modifiers", "", "SV" + (index + 1) + ": Modifier can only accept Alphanumeric values.");
										}
										if (modifier.length() != 2) {
											errors.rejectValue("svc.modifiers", "", "SV" + (index + 1) + ": Invalid value '" + modifier + "': A modifier cannot be less or greater than 2 Alphanumeric characters.");
										}
									}
								}
								
							index++;
						}	//end of for loop for null Line Item
							
//						} catch (IllegalArgumentException iae) {
//							// TODO Auto-generated catch block
//							iae.printStackTrace();
//						} catch (Exception e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
					}
					
				} else {
					logger.debug("No line items found to validate");
					//formForValidation.setServices(null);
					int index = 0;
					
					//set the first line item errors
					errors.rejectValue("svc.beginDate", "", "SV" + (index + 1) + ": Begin Date is required");
					errors.rejectValue("svc.procedureCode", "", "SV" + (index + 1) + ": Procedure Code is required");
					errors.rejectValue("svc.quantity", "", "SV" + (index + 1) + ": Quantity is required");
					errors.rejectValue("svc.lineAmount", "", "SV" + (index + 1) + ": Line Amount is required");		//"SV" + (index+1) + ": " +
					
					if (formForValidation.getSelectedServiceTypeCode().equals(AuthConstants.AUTHORIZATION_CATEGORY_TYPE_MNITS_HCSA)) {
						errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": End Date is required");
						errors.rejectValue("svc.provider.npi", "", "SV" + (index + 1) + ": Provider NPI is required");
						errors.rejectValue("svc.timePeriodQualifier", "", "SV" + (index + 1) + ": Time Period Qualifier is required");
						//if (serviceLineItem.getTimePeriodQualifier().isEmpty()) {
						//	errors.rejectValue("svc.timePeriodQualifier", "NotEmpty.authForm.timePeriodQualifier");
						//}
					}
				}	
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}	//end of session time out 			
	}	//end of validate method

	
	
	
	
	
	
	
	//*************************** DATE VALIDATION HELPER FUNCTIONS ****************************
	/**
	 * @param errors
	 * @param formatter
	 * @param centuryStartDate
	 * @param centuryEndDate
	 * @param index
	 * @param serviceLineItem
	 * @param isDateValid
	 * @throws ParseException
	 */
	protected void validateEndDate(Errors errors, DateFormat formatter,
			Date centuryStartDate, Date centuryEndDate, int index,
			ServiceInformationForValidation serviceLineItem, boolean isDateValid)
			throws ParseException {
		
		boolean isEndDateValid = isValid(serviceLineItem.getEndDate());
		//isDateValid = GenericValidator.isDate(d_temp,"MM/dd/yyyy", true);

		if (!isEndDateValid) {
			errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": Invalid Service End Date. Enter a valid date in the format MM/DD/YYYY");
		} else {
			Date dTemp=formatter.parse(serviceLineItem.getEndDate());    
		    
			//more tests for century dates
			if (dTemp.before(centuryStartDate) || dTemp.after(centuryEndDate)) {
				//if (dTemp.before(when) || dTemp.after(when)) {
				errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": Invalid Service End Date. Choose a date in the range of 01/01/1964 and 12/31/2063");
			} else if (dTemp.before(formatter.parse(serviceLineItem.getBeginDate()))) {
				errors.rejectValue("svc.endDate", "", "SV" + (index + 1) + ": Invalid Service End Date. Cannot be before the Begin date");
			}
		}
	}
	
	public boolean isValid(String dateStr) {
        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
	
	
	
	//********************************** LINE AMOUNT HELPER FUNCTIONS *****************************
	private boolean validateLineAmount(String numberString) {
		
		boolean decimalFound= numberString.indexOf('.') != -1;
		boolean oneAfterDecimalAllowed = true;
		
		if (decimalFound) {
			int decimalFoundAt= numberString.indexOf('.');
			
			String beforeDecimal =  numberString.substring(0, numberString.indexOf('.'));
			String afterDecimal =  numberString.substring(numberString.indexOf('.')+1, numberString.length());
			
			//beforeString length is only allowed to be 7 
//			if (NumberUtils.toDouble(numberString) == NumberUtils.DOUBLE_ZERO  ) {
//				return false;
//			}
			
			if (beforeDecimal.length() == 8 && afterDecimal.length() == 1){
				//88888888.9 is NOT allowed
				oneAfterDecimalAllowed = false;
				
				return false;
			} else if (beforeDecimal.length() == 8){
				oneAfterDecimalAllowed = false;
				
			} else if (beforeDecimal.length() < 8 && afterDecimal.length() < 3){
				//happy path 7777777.99
				oneAfterDecimalAllowed = true;
				
				return true;
			}
			
			if (numberString.length() == 10 && decimalFoundAt+1 == 9) {
				oneAfterDecimalAllowed = false;
			}
		} else {
			
			//Use cases for decimal not found
			
			//beforeString length is only allowed to be 7 so .00 can be attached
			if (numberString.length() > 7 ) {
				return false;
			}
			
//			if (NumberUtils.toDouble(numberString) == NumberUtils.INTEGER_ZERO  ) {
//				return false;
//			}
			
		}
		
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
}	//end of class
	
	

