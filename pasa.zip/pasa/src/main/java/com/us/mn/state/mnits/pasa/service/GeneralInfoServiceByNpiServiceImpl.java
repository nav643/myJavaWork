package com.us.mn.state.mnits.pasa.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.us.mn.state.mnits.pasa.dao.GeneralInfoServiceByNpiDao;
import com.us.mn.state.mnits.pasa.model.GeneralInfoServiceByNpi;
import com.us.mn.state.mnits.pasa.model.Location;


@Service("generalInfoServiceByNpiService")
public class GeneralInfoServiceByNpiServiceImpl implements
		GeneralInfoServiceByNpiService {

	private final Logger logger = LoggerFactory
			.getLogger(GeneralInfoServiceByNpiServiceImpl.class);

	@Autowired
	GeneralInfoServiceByNpiDao generalInfoServiceByNpiDao;

	@Override
	public List<Location> findByNpi(String npi) {

		List<Location> locations = new ArrayList<Location>();
		try {
			List<GeneralInfoServiceByNpi> generalInfoServiceByNpiList = 
					generalInfoServiceByNpiDao.findByNpi(npi);
			for (GeneralInfoServiceByNpi generalInfoServiceByNpi : generalInfoServiceByNpiList) {
				if (generalInfoServiceByNpi.getProviderTypes() != null) {
					locations.add(createLocationObject(generalInfoServiceByNpi));
				}
			}
		} catch (Exception e) {
			logger.debug("Exception finding locations by npi:" + npi
					+ ", exception: " + e.getMessage());
		}
		return locations;
	}

	private Location createLocationObject(GeneralInfoServiceByNpi info) {

		Location location = new Location();
		location.setId(info.getProviderNumber());
		location.setName(info.getOrgTaxName());
		location.setAddress1(info.getOrgAddress1());
		location.setAddress2(info.getOrgAddress2());
		location.setCity(info.getOrgCity());
		location.setState(info.getOrgState());
		location.setZip(info.getOrgZip());
		location.setProviderName(info.getProviderTypes().getTypeDescription());
		location.setZip9(info.getOrgZip9());
		location.setProviderType(info.getProviderType());
		location.setNpiNumber(info.getNpiNumber());
		
		return location;
	}

}
