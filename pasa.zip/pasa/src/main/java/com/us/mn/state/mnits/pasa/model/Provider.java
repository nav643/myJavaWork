package com.us.mn.state.mnits.pasa.model;

public class Provider{
	private String npi;
	private String address;
	private String city;
	private String state;
	private String zip;
	private String providerName;
	private String id;		//legacy_id
	private boolean serviceLineProviderNPInotInDB = false;
	
	//in case provider is an individual
	private String firstName;
	private String lastName;
	
	//if provider belongs to an organization
	private String orgName;
	private String contactName;
	private String contactFirstName;
	private String contactLastName;
	private String supplementId;
	
	private String communicationNumber;
	private String communicationType;
	private String communicationDetail;
	
    // Information from NPI Popup application
//	private String requester_id_from_popup = null;
//	private String requester_npi_from_popup = null ;    
//	private String npi_provider_type_from_popup = null ; 
//	private String requester_wholeaddr = null ;
//	private String requester_taxonomy_code = null ;
	
	public Provider() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Provider(String npi, String address, String city, String state,
			String zip, String providerName, String id, String firstName, boolean serviceLineProviderNPInotInDB,
			String lastName, String orgName, String contactName,
			String contactFirstName, String contactLastName,
			String supplementId, String communicationNumber,
			String communicationType, String communicationDetail) {
		super();
		this.npi = npi;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.providerName = providerName;
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.serviceLineProviderNPInotInDB = serviceLineProviderNPInotInDB;
		this.orgName = orgName;
		this.contactName = contactName;
		this.contactFirstName = contactFirstName;
		this.contactLastName = contactLastName;
		this.supplementId = supplementId;
		this.communicationNumber = communicationNumber;
		this.communicationType = communicationType;
		this.communicationDetail = communicationDetail;
	}



	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public boolean isServiceLineProviderNPInotInDB() {
		return serviceLineProviderNPInotInDB;
	}



	public void setServiceLineProviderNPInotInDB(
			boolean serviceLineProviderNPInotInDB) {
		this.serviceLineProviderNPInotInDB = serviceLineProviderNPInotInDB;
	}



	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getCommunicationNumber() {
		return communicationNumber;
	}
	public void setCommunicationNumber(String communicationNumber) {
		communicationNumber = communicationNumber;
	}
	public String getCommunicationType() {
		return communicationType;
	}
	public void setCommunicationType(String communicationType) {
		communicationType = communicationType;
	}
	public String getCommunicationDetail() {
		return communicationDetail;
	}
	public void setCommunicationDetail(String communicationDetail) {
		communicationDetail = communicationDetail;
	}
	public String getContactFirstName() {
		return contactFirstName;
	}
	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}
	public String getContactLastName() {
		return contactLastName;
	}
	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}
	public String getSupplementId() {
		return supplementId;
	}
	public void setSupplementId(String supplementId) {
		this.supplementId = supplementId;
	}
	
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
