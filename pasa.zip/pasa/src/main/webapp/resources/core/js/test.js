
$(document).ready(function() {
	var isTestPage = window.location.href.indexOf("/test") > -1;
	
//	$("").click(function(){	
	//
//			$( ".hch-block").hide();
//		});
	
	$("#Tab1").click(function(){	
		$(".Tab2").hide();
		$(".Tab1").show();
	});
	
	$("#Tab2").click(function(){	
		//alert("in PASA");
		$(".Tab1").hide();
		$(".Tab2").show();
	});
	
	$("#contactName").blur(function(){	
		if( !$(this).val() ) {
	        $(this).css("background-color", "#ff0000");
			alert("The Requested Contact Name is required.");
	        //$(this).addClass('warning');
	    }
	});
	
	
	//Iterate thru a dropdown
	$("#modifySelect").click(function(){
		//alert("in here");
		$('#modifiersList > option').each(function() {
		    alert($(this).text() + ' ' + $(this).val());
		});
	});
	
	
	
	// ********** HELPER FUNCTIONS ***********
	function confirmPresence() {
		//$(document).ready(function () {
		var value = $('#serviceTypeCode :selected').val();
		alert("in TEST");
		$( "#div119").hide();
	}

	function changeDIV() {
			
	}
	

});
	
	
	
	