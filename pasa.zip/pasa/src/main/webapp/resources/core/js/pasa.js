


		//************** pop up windows *************
		function popUp(URL) {
			var awin = window.open("", "fieldDescription", "toolbar=0,scrollbars=1,location=0,status=0,menubar=1,resizable=1,width=350,height=250");
			//awin.document.write("<input type='button' id='closeButton' value='close' onclick='javascript:window.close();'>");
			awin.document.close;
			awin.focus();
			awin.location=URL;
			//awin.close();

		    var head  = awin.document.getElementsByTagName('head')[0];
		    var link  = awin.document.createElement('link');
		    link.rel  = 'stylesheet';
		    link.type = 'text/css';
		    link.href = 'resources/css/mnits.std.css';
		    link.media = 'all';
		    head.appendChild(link);
		}

		function popUpNamed(URL, windowName) {
			var awin = window.open("", windowName, "toolbar=0,scrollbars=1,location=0,status=1,menubar=1,resizable=1,width=550,height=400");
			awin.document.write("");
			awin.document.close;
			awin.focus();
			awin.location=URL;
		}

		function popUpResponse(URL) {
			var awin = window.open("", "_mmisresp", "toolbar=0,scrollbars=1,location=0,status=1,menubar=1,resizable=1,width=550,height=400");
			awin.document.write("");
			awin.document.close;
			awin.focus();
			awin.location=URL;
		}

		function popUpPdf(URL) {
			var awin = window.open("", "fieldDescription", "toolbar=0,scrollbars=1,location=0,status=0,menubar=1,resizable=1");
			awin.document.write("");
			awin.document.close;
			awin.focus();
			awin.location=URL;
		}

		function popUpFull(URL) {
			var awin = window.open("", "fieldDescription", "toolbar=0,scrollbars=1,location=0,status=0,menubar=1,resizable=1");
			awin.document.write("");
			awin.document.close;
			awin.focus();
			awin.location=URL;
		}

		//************* other utility functions **************
		function resetApp() {
			//not being used
		}


$(document).ready(function() {
	var isAuthPage = window.location.href.indexOf("/pasa/authPA") > -1;
	var isEditMode = window.location.href.indexOf("/pasa/edit") > -1;
	var isLocalStrictly = window.location.href.indexOf("localhost:8080") > - 1;
	var taxonomy_code_exists = false;
	var NPInotInDB = false;
	
	console.log(JSON.stringify(serviceCodes));	

	//initial state
	var originalForm = $("#authForm").html();
	$("#LookupNPIdiv").hide();
	$("#LookupNPI").hide();
	$("#infoDiv").hide();
	$("#infoDivServicesTab").hide();
	$("#requestNPI").trigger('blur');	//kick of autofill of NPI if found in the session


	// ***************** PRE LOADED VALUES FOR LOCALHOST AND DEV ****************
	//TODO: for debugging only - automatically fill these fields for DEV and LOCAL

	if (isLocalStrictly | window.location.href.indexOf("mn-its-dev.") > -1) { 		//} | window.location.href.indexOf("mn-its-stst.") > -1) {
		if (isLocalStrictly) {

			/*
        	 $("#infoDivServicesTab").html("Invalid value " + npi + " for Service Provider NPI in the Service Line Form. The Service Provider NPI has been identified as a consolidated NPI. We don't allow consolidated NPI in the Service Provider NPI field.");
 	        	$("#infoDivServicesTab").show();
 		    $("#providerLastNameInBox").val("");
	        $("#providerFirstNameInBox").val("");
	        $("#serviceLineItemProviderLegacyId").val("");
	        $("#infoDivServicesTab").show();			//show the info message
	        $("#infoDivServicesTab").removeClass('hidden');
			 */
		}

		if (isAuthPage && !isEditMode) {
			// ********** AUTHORIZATION tab **********
			$("#requestNpi").val("1467508226");
//			$("#communicationNumber").val("6125556677");
//			$("#subscriberId").val("00000192");			//02034153
//			$("#subcriberDOB").val("08/27/1969");		//01/24/1981
//			$("#subcriberLastName").val("test LN");
//			$("#subcriberFirstName").val("test FN");
//			if ($("#selectedServiceTypeCode").val() != 35 ) {
//				$("#diagnosisCode").val("K05.10");
//			}
//
//			//if for HHC
//			//if ($("#selectedServiceTypeCode").val() == 42 ) {
//				$("#contactLastName").val("test Contact LN");
//				$("#contactFirstName").val("test Contact FN");
//				$("#eventDate").val("12/10/2021");
//			//} else {
//				$("#contactName").val("test Contact");
//			//}
//
//			// ************* SERVICES tab **************
//			$("#serviceBeginDate").val("12/11/2021");
//			$("#procedureCode").val("J0588");
//			$("#quantity").val("1");
//			$("#lineAmount").val("59.32");
//			
//			//if (!isEditMode) {
//				//setup for RTC 68511
//				$("#modifiersListBox").append($('<option>', {value : "22", text : "22" }));
//				$("#modifiersListBox").append($('<option>', {value : "HH", text : "HH" }));
//				
//				//Dental Information section
//				$("#toothNumber").prop('selectedIndex',1);		//second element to select since first name is blank - so use index=1
//				$("#surfaceInfoDropDown").append($('<option>', {value : "B", text : "B" }));
//				$("#surfaceInfoDropDown").append($('<option>', {value : "D", text : "D" }));
//				$("#cavityInfoDropDown").append($('<option>', {value : "01", text : "01" }));
//				$("#cavityInfoDropDown").append($('<option>', {value : "10", text : "10" }));
//				$("#prosthesis").prop('selectedIndex',1);		//second element to select since first name is blank - so use index=1
//			//}
			
			//if for HHC
			//if ($("#selectedServiceTypeCode").val() == 42 ) {
				//$("#serviceEndDate").val("12/15/2021");
					//$("#timePeriodQualifier")[1].selectedIndex =1;
					$("#timePeriodQualifier").val($("#timePeriodQualifier option:eq(2)").val());
					//$("#timePeriodQualifier").selectmenu("refresh");
				//$("#providerNPI").val("1831509645");
			//}
		} // if (isAuthPage && !isEditMode) {
	} // do above only for DEV or LOCAL HOST else {






	//*********************** VALIDATION ERRORS check starts here ****************

	// If in Validation errors, go ahead and refill all list boxes again - //if ($('[id$=".errors"]').length > 0) { 	//validation error mode so all lists should be filled back in
	if ($('#alertDiv').is(':visible')) {
		//it means there are some sort of errors showing on screen
		isEditMode = true;
		console.log("coming in alertDIV=visible possibly due to binding validation errors or ..." + isEditMode);	
	} else {  //************ validation errors list completes here **********************
		isEditMode = false;
		console.log("no bindnig errors hence edit mode is " + isEditMode);	
		
		isEditMode = window.location.href.indexOf("/pasa/edit") > -1;
		console.log("but ... let's check if we are in edit page: " + isEditMode);
	}

	//now confirm if it is the edit page - double check
	isEditMode = window.location.href.indexOf("/pasa/edit") > -1;
	
	if (isEditMode) {
		console.log("in edit mode --> filling all list boxes on authorization page ...");
		//***************check for list fields and fill them in the form elements from hidden fields for EDIT page**************		
		if (!$("#communicationTextList") == '') {
			//split the text and value here
			var info = $.trim($("#communicationTextList").val());
			if (!(info == '')) {
				var array = info.split(",");
				console.log();
				if (array.length > 1) {
					$.each(array,function(i){			//for (var i in array){  or //for (i=0;i<array.length;i++){
					   //alert(array[i]);
						$("#communicationTextListBox").append($('<option>', { value : $.trim(array[i]), text : $.trim(array[i]) }) );
					});
				} else {
					$("#communicationTextListBox").append($('<option>', {value : info, text : info }) );
				}
			}
		}

		if (!$("#diagnosisCodeList") == '') {
			//console.log("ValidationErrors: Filling back Diagnosis Code List");
			//split the text and value here
			var info = $.trim($("#diagnosisCodeList").val());

			if (!(info == '')) {
				var array = info.split(",");
				//console.log();
				if (array.length > 1) {
					$.each(array,function(i){
					   //alert(array[i]);
						$("#diagnosisCodes").append($('<option>', { value : $.trim(array[i]), text : $.trim(array[i]) }) );
					});
				} else {
					$("#diagnosisCodes").append($('<option>', {value : info, text : info }) );
				}
			}
		}
		
	}	//if (isEditMode) 
	


	//*****************switch between two tabs/pages but submit as one page*******************
	$("#Tab1").click(function(event){	//authorization tab
		if ($('#infoDivServicesTab').is(':visible') & $('#providerNPI').val() != ""){
			// alert("cannot switch tabs until consolidated NPI is removed");
			$("#infoDivServicesTab").html("cannot switch tabs until consolidated NPI is removed");	//$("#infoDivServicesTab").html() + "<br><br>"

			$("#infoDivServicesTab").addClass("alert-danger");
			$("#infoDivServicesTab").removeClass("alert-info");
			$("#infoDivServicesTab").show();
		} else {
			$('#mnits-spinner').show(0);
			//$("#taxonomy").hide();

			event.preventDefault();
			$(".Tab2").hide();
			$(".Tab1").show();
			$("#Tab1").addClass("mnits-btn-link-disable");
			$("#Tab1").removeClass("mnits-btn-link-inactive");
			$("#Tab2").removeClass("mnits-btn-link-disable");
			$("#Tab2").addClass("mnits-btn-link-inactive");
			$("#infoDivServicesTab").removeClass("alert-danger");
			$("#infoDivServicesTab").addClass("alert-info");

			//remove the spinner
			setTimeout(function(){		$('#mnits-spinner').hide(0); }, 200);

		}
	});

	$("#Tab2").click(function(event){	//services tab
		if ($('#taxonomy').is(':visible') & $('#taxonomy').val() == "" & taxonomy_code_exists) {
			//alert("cannot switch tabs until taxonomy content is validated");	//		Invalid value {npi} for NPI/UMPI in the Authorization Form. The NPI/UMPI has been identified as a consolidated NPI/UMPI. Please use the look up button next to the NPI/UMPI field to select a taxonomy code/location.
      	  //$("#infoDiv").html("cannot switch tabs until valid NPI & taxonomy combination is provided");
    	  //$("#infoDiv").show();
		} else if (NPInotInDB == true && !isLocalStrictly) {
			//alert("cannot switch tab until invalid NPI is not removed");
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("cannot switch tab until invalid NPI is not removed");
		} else {
			$('#mnits-spinner').show(0);
			event.preventDefault();
			$("#infoDiv").hide();
 			$("#infoDiv").html();

			$(".Tab1").hide();
			$("#Tab1").removeClass("mnits-btn-link-disable");
			$("#Tab1").addClass("mnits-btn-link-inactive");
			$(".Tab2").removeClass("hidden");
			$(".Tab2").show();
			$("#Tab2").addClass("mnits-btn-link-disable");
			$("#Tab2").removeClass("mnits-btn-link-inactive");

			$("#infoDivServicesTab").hide();
			$("#infoDivServicesTab").removeClass("alert-danger");
			$("#infoDivServicesTab").addClass("alert-info");

			//remove the spinner
			setTimeout(function(){
				$('#mnits-spinner').hide(0); }, 200
			);
		}
	});



	//********************** show REQUIRED blocks and/or fields of data based on the 4 option in TOP DROP DOWN *********************
	$("#selectedServiceTypeCode").change(function(){
		//alert($("#selectedServiceTypeCode").val());

		if ($("#selectedServiceTypeCode").val() == 1 ) {
			$( ".MED").show();
			$( ".DME").hide();
			$( ".HHC").hide();

			//required fields are the default ones but turn off following HHC fields.  they remain visible but not BOLD
			$('a[class="form-request"]').css("font-weight", "bold");
			HHCRequiredAndAccessabilityReset();

			$('label[for="diagnosisCode"]').css("font-weight", "bold");
			$('label[for="diagnosisCode"]').html('Diagnosis Code  <span aria-hidden="true"></span>').addClass("asterisk");
			$("#diagnosisCode").attr('aria-required', 'true');

		} else if ($("#selectedServiceTypeCode").val() == 12 ) {	
			$( ".MED").show();
			$( ".DME").show();
			$( ".HHC").hide();

			//required fields same as Medical i.e. 1 but turn off following HHC fields.  they remain visible but not BOLD
			HHCRequiredAndAccessabilityReset();

			$('label[for="diagnosisCode"]').css("font-weight", "bold");
			$('label[for="diagnosisCode"]').html('Diagnosis Code  <span aria-hidden="true"></span>').addClass("asterisk");
			$("#diagnosisCode").attr('aria-required', 'true');
		} else if ($("#selectedServiceTypeCode").val() == 35 ) {	//Dental
			$( ".MED").show();
			$( ".DME").hide();
			$( ".HHC").hide();

			//required fields same as Medical (except diagnosis code) i.e. 1 but turn off following HHC fields.  they remain visible but not BOLD
			$('label[for="diagnosisCode"]').css("font-weight", "");
			$('label[for="diagnosisCode"]').html('Diagnosis Code').removeClass("asterisk");
			$("#diagnosisCode").removeAttr('aria-required');

			HHCRequiredAndAccessabilityReset();
		} else if ($("#selectedServiceTypeCode").val() == 42 ) {
			$( ".MED").hide();
			$( ".DME").hide();
			$( ".HHC").show();

			//change the diagnosis code back to  REQUIRED field
			$('label[for="diagnosisCode"]').css("font-weight", "bold");
			$('label[for="diagnosisCode"]').html('Diagnosis Code  <span aria-hidden="true"></span>').addClass("asterisk");
			$("#diagnosisCode").attr('aria-required', 'true');

			//required fields - 3  more fields become visible & required, 2 other already visible field become required
				$('label[for="serviceEndDate"]').css("font-weight", "bold");	//lblServiceLineItemEndDate
				$('label[for="providerNPI"]').css("font-weight", "bold");		//lblServiceLineItemProviderNPI
				$('label[for="contactLastName"]').css("font-weight", "bold");
				$('label[for="contactFirstName"]').css("font-weight", "bold");
				$('label[for="eventDate"]').css("font-weight", "bold");
				$('label[for="timePeriodQualifier"]').css("font-weight", "bold");
				//$("#timePeriodQualifier").attr('value', '');

				//Accessaility additions - <span aria-hidden="true">*</span>
				$('label[for="serviceEndDate"]').html('End Date  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#serviceEndDate").attr('aria-required', 'true');
				$('label[for="providerNPI"]').html('Provider NPI  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#providerNPI").attr('aria-required', 'true');
				$('label[for="contactLastName"]').html('Contact Last Name  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#contactLastName").attr('aria-required', 'true');
				$('label[for="contactFirstName"]').html('Contact First Name  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#contactFirstName").attr('aria-required', 'true');
				$('label[for="eventDate"]').html('Event Date (Home Care Assessment Date)  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#eventDate").attr('aria-required', 'true');
				$('label[for="timePeriodQualifier"]').html('Time Period Qualifier: (Home Care Frequency)  <strong style="color:red;"><span aria-hidden="true">*</span></strong>');
				$("#timePeriodQualifier").attr('aria-required', 'true');

		}
	}).trigger("change") //extra call;

	function HHCRequiredAndAccessabilityReset() {
		$('label[for="serviceEndDate"]').css("font-weight", "");	//lblServiceLineItemEndDate
		$('label[for="providerNPI"]').css("font-weight", "");		//lblServiceLineItemProviderNPI
		$('label[for="contactLastName"]').css("font-weight", "");
		$('label[for="contactFirstName"]').css("font-weight", "");
		$('label[for="eventDate"]').css("font-weight", "");
		$('label[for="timePeriodQualifier"]').css("font-weight", "");

		//Accessaility additions - <span aria-hidden="true">*</span> BE removed
		$('label[for="serviceEndDate"]').html('End Date');
		$('label[for="providerNPI"]').html('Provider NPI');
		$('label[for="contactLastName"]').html('Contact Last Name');
		$('label[for="contactFirstName"]').html('Contact First Name');
		$('label[for="eventDate"]').html('Event Date (Home Care Assessment Date)');
		$('label[for="timePeriodQualifier"]').html('Time Period Qualifier: (Home Care Frequency)');

		//also remove the aria-required=true attribute from following input fields
		$("#serviceEndDate").removeAttr('aria-required');
		$("#providerNPI").removeAttr('aria-required');
		$("#contactLastName").removeAttr('aria-required');
		$("#contactFirstName").removeAttr('aria-required');
		$("#eventDate").removeAttr('aria-required');
		$("#timePeriodQualifier").removeAttr('aria-required');
	}


	//************** process the NPI Button / NPI text box field auto filled in AUTHORIZATION tab ******************
	$("#requestNpi").blur(function(){
		var npi = $.trim($("#requestNpi").val());
		//var url= '/npi-popup-mvc/locations/' + npi + '?locationJson=testJsonResponse';

		//ensure only 10 character NPI is accepted and allowed to process
		//if (!($(this).val().length === 10)) { alert("MHCP recognizes only a value of 10 digits in Requester NPI/UMPI.");   } else {

        //alert("in ajax call");
        $.ajax({
         type: "get",
         url: "/pasa/locations/json",
         cache: false,
         data:'npi=' + npi,
         success: function(response){
          //alert(response);
	        if (response.length == 0) {
	        	//alert("Invalid value " + npi + " for NPI/UMPI in the Authorization Form. The NPI/UMPI is not in our database.");
	        	$("#infoDiv").html("Invalid value " + npi + " for NPI/UMPI in the Authorization Form. The NPI/UMPI is not in our database.");
	        	$("#infoDiv").show();
		        $("#infoDiv").removeClass('hidden');
		        NPInotInDB = true;

		        $("#LookupNPI").hide();
		        $("#LookupNPIdiv").hide();

			    $("#OrgName").val("");
			    $("#providerName").val("");
			    $("#Address").val("");
			    $("#City").val("");
			    $("#State").val("");
			    $("#Zip").val("");
			    $("#taxonomy").val("");
			    $("#requestId").val("");
	        } else if (response.length == 1) {
	        	//Single location and NOT provider type=33
	        	NPInotInDB = false;
	        	$("#LookupNPIdiv").hide();
	        	$("#LookupNPI").hide();
	        	$("#infoDiv").hide();
	         	$("#infoDiv").html("");
	        	if (!$("#infoDiv").hasClass('hidden')) { $("#infoDiv").addClass('hidden'); }


	        	if (response[0].providerName = "PHYSICIAN") {
		          	$("#OrgName").val(response[0].name);
					$("#providerName").val(response[0].org_name);
					//add first name here
		          } else {
		          	$("#OrgName").val(response[0].providerName);
					$("#providerName").val(response[0].org_name);
		          }
					if ($.trim(response[0].address2 = "")){
						$("#Address").val(response[0].address2 + response[0].adderss1);
					} else {
						$("#Address").val(response[0].address1);
					}

					$("#City").val(response[0].city);
					$("#State").val(response[0].state);
					$("#Zip").val(response[0].zip);
					$("#requestId").val(response[0].id);		//this is the most useful field
					
					//$("#infoDiv").html("For Service Line Item provider id: NPI->" + $("#requestNPI").val() + " | " + $("#requestId").val());
					// $("#infoDiv").show();
					//alert( response[0].npi_number +  " | legacy_id: " + response[0].legacy_id + " | id: " + response[0].id);
	         } else {
	        	//Multiple locations - Must be consolidated
	        	NPInotInDB = false;
	        	$("#infoDiv").html("Invalid value " + npi + " for NPI/UMPI in the Authorization Form. The NPI/UMPI has been identified as a consolidated NPI/UMPI. Please use the look up button next to the NPI/UMPI field to select a taxonomy code/location.");
		        $("#infoDiv").show();
	        	$("#infoDiv").removeClass('hidden');
	        	$("#LookupNPI").show();
	        	$("#LookupNPIdiv").show();

	        	//don't clear the address field info here. do it at lookup button click
	         }
         },
         error: function(){
        	 //alert('Error while request..');
         	  $("#infoDiv").html("Error while processing AJAX request..");
        	  $("#infoDiv").show();
        	  $("#infoDiv").removeClass('hidden');
         }
        });
	}).blur();	//$("#requestNpi").blur(function() - another solution: $inputs.trigger('blur');


	$("#LookupNPI").click(function(){
		$("#testJsonResponse").val("");
		//$("#jsonResponseTextArea").val("");
		$("#OrgName").val("");
		$("#Address").val("");
		$("#City").val("");
		$("#State").val("");
		$("#Zip").val("");
		$("#providerName").val("");
		$("#npiNumber").val("");
		$("#requestId").val("");
		$("#taxonomy").val("");

		//https://mnits-lt.dhs.state.mn.us/npi-popup-mvc/locations/A342517700?locationJson=testJsonResponse
		var npi = $("#requestNpi").val();
		var url= '/npi-popup-mvc/locations/' + npi + '?locationJson=testJsonResponse';
		window.open(url, "test", "toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=1,resizable=0");
	});

	$('#testJsonResponse').change(function() {
  		var jsonText= $("#testJsonResponse").val();
		var jsonObject = jQuery.parseJSON (jsonText);
		$("#jsonResponseTextArea").val(jsonText);
		$("#OrgName").val(jsonObject.org_name);
		$("#Address").val(jsonObject.address2 + jsonObject.address1);
		$("#City").val(jsonObject.city);
		$("#State").val(jsonObject.state);
		$("#Zip").val(jsonObject.zip);
		$("#npiNumber").val(jsonObject.npi_number);
		$("#requestId").val(jsonObject.legacy_id);	//legacy id
		
		//for consolidated NPI, if taxonomy code is empty
		if (typeof jsonObject.taxonomy_code === "undefined") {
			taxonomy_code_exists = false; 	//this is a consolidated NPI but this location has no taxonomy code - defect
		} else {
			$("#taxonomy").val(jsonObject.taxonomy_code);
			taxonomy_code_exists = true;
		}
		//alert( jsonObject.npi_number +  " | " + jsonObject.legacy_id );
	});








	//************** process the Service Line Item Provider NPI (the Provider information) for Services Tab ******************
	$("#providerNPI").blur(function(){
		//alert($("#serviceLineItemProviderLegacyId").val());
		runProiderNPIJSONcall();
	});

	$('#providerNPIJsonResponse').change(function() {
  		var jsonText= $("#providerNPIJsonResponse").val();
		var jsonObject = jQuery.parseJSON (jsonText);
        $("#providerLastNameInBox").val(jsonObject.providerName);
        $("#providerFirstNameInBox").val(jsonObject.org_name);
		//$("#serviceLineItemProviderLegacyId").val(jsonObject.legacy_id);
		
	});
	
	
	
	

	/******************figure out the right help file ***********************/
//	$("label").each(function(){
//	    //do something with the element here.
//		//var hasfoo = $(this).hasClass('foo'); // does it have foo class?
//		//var newclass = hasfoo ? 'bar' : 'baz';
//		//$(this).addClass(newclass); // conditionally add another class
//
//		//alert($(this).attr("for"));
//		//if ($(this).attr("for") != 'undefined') {
//			//alert($("label").length);
//			//alert($(this).attr("for"));
//		//}
//		//alert("total labels:" + $(xml).find("label").length);
//
//		var fieldName = $(this).attr("for");
//		if (fieldName == 'selectedServiceTypeCode') { alert(fieldName);  $(this).attr("onclick", "javascript:popUp('resources/help/auth_header_current.html')"); }
//
//	});


	//****************make the HELP file labels active (and clickable)****************
	$("label[onclick]").each(function(){
		//alert($(this).attr("for"));
		var helpFileLink = $(this).attr("onclick");
		if (helpFileLink.length > 0) {
			//alert(helpFileLink);
			$(this).css('text-decoration', 'underline');
			$(this).css('cursor', 'pointer');
		}
	});





	//************ bootstrap datepickers *************
	$("#subscriberDOB-DP").datetimepicker({
			format: 'MM/DD/yyyy',
			minDate: moment("01/01/1801"),
		    maxDate: moment("12/31/2063"),
			keepInvalid : true,
		   //endDate: '@DateTime.Now.ToString("yyyy-mm-dd")',
		});

		$("#eventDate-DP").datetimepicker({
			format: 'MM/DD/yyyy',
			minDate: moment("01/01/1964"),
		    maxDate: moment("12/31/2063"),
			keepInvalid : true,
			//endDate: '@DateTime.Now.ToString("yyyy-mm-dd")',
		});


		$("#serviceBeginDate-DP").datetimepicker({
			format: 'MM/DD/yyyy',
			minDate: moment("01/01/1964"),
		    maxDate: moment("12/31/2063"),
			keepInvalid : true,
			useCurrent: false
		});

		$("#serviceEndDate-DP").datetimepicker({
			format: 'MM/DD/yyyy',
			minDate: moment("01/01/1964"),
		    maxDate: moment("12/31/2063"),
			keepInvalid : true,
			//useCurrent: false //Important! See issue #1075
		});

		//Link #serviceBeginDate-DP and #serviceEndDate-DP
//		$("#serviceBeginDate-DP").on("dp.change", function (e) {
//            $('#serviceEndDate-DP').data("DateTimePicker").minDate(e.date);
//        });
//        $("#serviceEndDate-DP").on("dp.change", function (e) {
//            $('#serviceBeginDate-DP').data("DateTimePicker").maxDate(e.date);
//        });





	//rest of the blur events

	//************* AUTHORIZATION TAB ***************
	$("#contactName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
	        //$(this).css("background-color", "#f2dede");
			//alert("The Requested Contact Name is required.");
	        //$(this).addClass('warning');
	    }
	});

	$("#contactFirstName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Contact First Name is required.");
	    }
	});


	$("#contactLastName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Contact Last Name is required.");
	    }
	});


	$("#communicationTextListBox").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Communication Number is required.");
	        //$(this).addClass('warning');
	    }
	});


	$("#subcriberFirstName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Subscriber First Name is required.");
	    }
	});


	$("#subcriberLastName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Subscriber Last Name is required.");
	    }
	});



	//*********** date related *************
	$("#subcriberDOB").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("Invalid Subscriber Birthdate: correct format is mm/dd/ccyy.");
	    }
	});


	$("#contactName").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("Invalid Home Care Assessment Date: correct format is mm/dd/ccyy.");
	    }
	});




	//**************** SERVICES TAB ******************
	$("#providerNPI").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue & $("#selectedServiceTypeCode").val() == 42) {
			//alert("The Provider NPI is required.");
	    }
	});


	$("#lineAmount").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("The Line Amount is required.");
	    }
	});



	//************** numbers related validations ***************
	$("#quantity").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue || !$.isNumeric($(this).val())) {
			//alert("You must enter a valid Quantity.");
	    }
	});

	$("#procedureCode").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( $(this).val().length < 5) {
			//alert("MHCP recognizes only CPT/HCPCS code values of 5 characters in Procedure Code.");
	    }
	});

	$("#subscriberId").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//$(this).addClass("alert-danger");
			//alert("The Subscriber ID is required.");
	    } else if (!(($(this).val().length === 8) & ($.isNumeric($(this).val() ))))  {
	    	//$(this).addClass("alert-danger");
	    	//alert("MHCP recognizes only number values of 8 digits in Subscriber ID.");

	    	$('#alertDiv').show();	//$('#alertDiv').css('display','block');
	    	$('#alertDiv').text("MHCP recognizes only number values of 8 digits in Subscriber ID.");
	    } else {
	    	$('#alertDiv').hide();	//$('#alertDiv').css('display','none');
	    }
	});


	//************** date related validations ***************
	$("#serviceBeginDate").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue ) {
			//alert("Invalid Begin Date: correct format is mm/dd/ccyy.");
	    }
	});

	$("#serviceEndDate").blur(function(){
		var selectedValue = $.trim($(this).val());
		if( !selectedValue & $("#selectedServiceTypeCode").val() == 42) {
			//alert("Invalid End Date: correct format is mm/dd/ccyy.");
	    }
	});



	//*********** TEXT BOX & DROP DOWN CONNECTED TO EACH OTHER USING ADD DELETE BUTTONS **************

	//Working with dropdown values and Add/Delete buttons
	$("#addCommunicationNumber").click(function(){
		//if empty then alert otherwise add (type:number) text
		var communicationNumber = $.trim($("#communicationNumber").val());
		if ($("#communicationTextListBox").children("option").length >= 3) {
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("More than 3 entries cannot be added to communication list");
//		} else if (!communicationNumber || 0 === communicationNumber.length) {
//			$('#alertDiv').show();
//	    	$('#alertDiv').text("The required field(s) for this entry have not been completed.");
		} else {
			$('#alertDiv').hide();
			if (communicationNumber != '') {
				$("#communicationTextListBox").append($('<option/>', {
					value : $("#communicationType").val() + ":" + communicationNumber,
					text : $("#communicationType").val() + ":" + communicationNumber })
				);
			}
			$("#communicationType").val("T");
			$("#communicationNumber").val("");
		}
	});

	$("#delCommunicationNumber").click(function(){
		//if empty then alert otherwise add (type:number) text
		$("#communicationTextListBox option:selected").remove();
		$("#communicationType").val("T");
		$("#communicationNumber").val("");
	});

	$("#communicationTextListBox").change(function(){
		//if empty then alert otherwise add (type:number) text
		var selectedValue = $.trim($(this).val());
		//alert(selectedValue);
		$("#communicationType").val(selectedValue.split(":")[0]);
		$("#communicationNumber").val(selectedValue.split(":")[1]);
	});


	//Diagnosis Code
	$("#addDiagnosisCode").click(function(){
		//if empty then alert otherwise add (type:number) text
		var diagnosisCode = $.trim($("#diagnosisCode").val());
		var itemExists = false;
		//var patternToMatch = "^[a-zA-Z0-9.]+$";	//'[a-z0-9]+@[a-z]+\.[a-z]{2,3}'
		var regex = new RegExp('[a-zA-Z0-9.]+');

		if (!diagnosisCode || 0 === diagnosisCode.length) {
			//alert("The required field(s) for this entry have not been completed.");
//		} else if (regex.test(diagnosisCode)) {
//	    	$('#alertDiv').show();
//	    	$('#alertDiv').text("Diagnosis code can only accept Alphanumeric values");
		} else if ($("#diagnosisCode").length > 5) {
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("Only 5 Diagnosis Code entries are allowed");
		} else {
			$("#diagnosisCodes > option").each(function() {
				//alert($(this).text() + ' ' + $(this).val());
	            if ($(this).text() === $.trim(diagnosisCode)) {
	                itemExists = true;
	    	    	$('#alertDiv').show();
	    	    	$('#alertDiv').text("This diagnosis code has already been added.");
	            }
			});
			if (!itemExists) {
				$("#diagnosisCodes").append($('<option>', {value : diagnosisCode, text : diagnosisCode }) );
				$("#diagnosisCode").val("");
				$('#alertDiv').hide();
			}
		}
	});

	$("#delDiagnosisCode").click(function(){
		$("#diagnosisCodes option:selected").remove();
		$("#diagnosisCode").val("");
	});

	$("#diagnosisCodes").change(function(){
		var selectedValue = $.trim($(this).val());
		$("#diagnosisCode").val(selectedValue);
	});

	//Diagnosis code text box where validation on placement for the decimal should happen
	$("#diagnosisCode").blur(function(){
		//if( !$(this).val() ) { alert("You must enter at least one value in Diagnosis code."); }
		var diagnosisCode = $.trim($(this).val());

		//If the number entered is smaller than three digits in length (i.e. 27), MN-ITS will place the decimal point to the right of the last digit (i.e.27.).
		if (diagnosisCode.length > 0 && diagnosisCode.length < 3 ) {
	    	if (diagnosisCode.indexOf(".") == -1) {
	    		//alert("MHCP recognizes only values of 3 to 8 characters in Diagnosis Code.");
	    		//change the value to have a decimal
	    		$(this).val(diagnosisCode + ".");
	    	}
	    }

		//If the number entered is larger than three digits in length (i.e.74365), MN-ITS will place the decimal point after the third and before the fourth digit (i.e. 743. 65).
	    if ( diagnosisCode.length >= 3 && diagnosisCode.length <= 8 ) {
	    	if (diagnosisCode.indexOf(".") == -1) {
	    		//alert("MHCP recognizes only values of 3 to 8 characters in Diagnosis Code.");
	    		//change the value to have a decimal
	    		if (diagnosisCode.length === 3 ) {   $(this).val(diagnosisCode + ".");   }
	    		if (diagnosisCode.length > 3 ) {
	    			var modifiedValue = diagnosisCode.substring(0,3) + "." + diagnosisCode.substring(3, 7);
	    			$(this).val(modifiedValue);
	    		}
	    	} else {
	    		//Nothing needs to be done. It is all good
	    	}
		}
	});

	// Diagnosis codes list box where all of them are gathered
	$("#diagnosisCodes").blur(function(){
		if( !$(this).val() ) {
			//alert("You must enter at least one value in Diagnosis code.");
	    } else {
	        $(this).css("background-color", "#ffffff");
	    }
	});




	//Modifiers
	$("#addModifiers").click(function(e){
		var modifiers = $.trim($("#modifiers").val());
        var itemExists = false;

		e.preventDefault();

		if (!modifiers || 0 === modifiers.length) {
			//alert("The required field(s) for this entry have not been completed");
		} else if ($("#modifiersListBox").children("option").length >= 4) {
			//alert("Only 4 modifier entries are allowed");
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("Only 4 modifier entries are allowed");
		} else {
			$("#modifiersListBox > option").each(function() {
				//alert($(this).text() + ' ' + $(this).val());
	            if ($(this).text() === $.trim(modifiers)) {
	                itemExists = true;
	                //alert("Item '" + modifiers + "' already exists. cannot be added");
	    	    	$('#alertDiv').show();
	    	    	$('#alertDiv').text("Item '" + modifiers + "' already exists. cannot be added");
	            }
			});

			if (!itemExists) {
				$("#modifiersListBox").append($('<option>', {value : modifiers, text : modifiers }));
				$("#modifiers").val("");
				$('#alertDiv').hide();
			}
		}

	}); //end of addDodifiers


	$("#delModifiers").click(function(){
		$("#modifiersListBox option:selected").remove();
		$("#modifiers").val("");
	});

	$("#modifiersListBox").change(function(){
		var selectedValue = $.trim($(this).val());
		$("#modifiers").val(selectedValue);
	});



	//Tooth Surface Codes
	$("#addToothSurfaceCodes").click(function(){
		var toothSurfaceCode = $("#toothSurfaceCodes option:selected").val();
		var itemExists = false;

		if (!toothSurfaceCode || 0 === toothSurfaceCode.length) {
			//alert("The required field(s) for this entry have not been completed.");
		} else if ($("#surfaceInfoDropDown").children("option").length >= 4) {
			//alert("Only 4 modifier entries are allowed");
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("Only 4 surface code entries are allowed");
		} else {
			$("#surfaceInfoDropDown > option").each(function() {
				//alert($(this).text() + ' ' + $(this).val());
	            if ($(this).text() === $.trim(toothSurfaceCode)) {
	                itemExists = true;
	    	    	//$('#alertDiv').show();
	    	    	//$('#alertDiv').text("value already exists. cannot be added");
	            }
			});

			if (!itemExists) {
				$("#surfaceInfoDropDown").append($('<option>', {value : toothSurfaceCode, text : toothSurfaceCode }));
				$("#toothSurfaceCodes").val("");
			}
			$('#alertDiv').hide();
		}
	});

	$("#delToothSurfaceCodes").click(function(){
		$("#surfaceInfoDropDown option:selected").remove();
		//$("#toothSurfaceCodes").val(""); //TODO
	});

	$("#surfaceInfoDropDown").change(function(){
		var selectedValueInDropdown = $.trim($(this).val());
		//var toothSurfaceCode = $("#toothSurfaceCodes option:selected").val();
		$("#toothSurfaceCodes > option").each(function() {
            if (selectedValueInDropdown === $.trim($("#toothSurfaceCodes").val())) {
            	$("#toothSurfaceCodes").attr("selected", true);
            }
		});
		//$("#toothSurfaceCodes").val(selectedValue);
	});

	//Oral Cavity Designations
	$("#addOralCavityDesignation").click(function(){
		var OralCavityDesignation = $("#oralCavityDesignationList option:selected").val();
		var itemExists = false;

		if (!OralCavityDesignation || 0 === OralCavityDesignation.length) {
			//alert("The required field(s) for this entry have not been completed.");
		}  else if ($("#cavityInfoDropDown").children("option").length >= 5) {
			//alert("Only 4 modifier entries are allowed");
	    	$('#alertDiv').show();
	    	$('#alertDiv').text("Only 5 Oral Cavity entries are allowed");
		}else {
			$("#cavityInfoDropDown > option").each(function() {
				//alert($(this).text() + ' ' + $(this).val());
	            if ($(this).text() === $.trim(OralCavityDesignation)) {
	                itemExists = true;
	    	    	//$('#alertDiv').show();
	    	    	//$('#alertDiv').text("value already exists. cannot be added");
	            }
			});

			if (!itemExists) {
				$("#cavityInfoDropDown").append($('<option>', {value : OralCavityDesignation, text : OralCavityDesignation }));
				$("#oralCavityDesignationList").val("");
			}
	    	$('#alertDiv').hide();
		}
	});

	$("#delOralCavityDesignation").click(function(){
		$("#cavityInfoDropDown option:selected").remove();
		//$("#oralCavityDesignationList").val(""); //TODO
	});

	$("#cavityInfoDropDown").change(function(){
		var selectedValue = $.trim($(this).val());
	});



	// ********** RESET app ******************

	$("#resetApp").click(function() {
		$('#mnits-spinner').show(0);

		window.location = "/pasa/authPA";

		//reset or remove the spinner
		setTimeout(function(){
			$('#mnits-spinner').hide(0); }, 200
		);
	});




	//************************* Service line items related code *****************************

	var serviceCodes = [];
	var selectedLineItemIndex = 0;

	initializeLineItem();	//create a new blank line items

	function initializeLineItem() {
		var lineItemsAfterPostForEditAndValidate= $('#serviceLineItems').val();
		if (lineItemsAfterPostForEditAndValidate) {
			serviceCodes = JSON.parse(lineItemsAfterPostForEditAndValidate);
		} else {		
			var serviceCode = {
				beginDate: "",
				endDate: "",
				procedureCode: "",
				quantity: "",
				description: "",
				timePeriodQualifier: "",
				serviceDescriptionModelNumber: "",
				modifiers: [],
				lineAmount: "",
				provider: {
					npi: "",
					id: "",
					lastName: "",
					firstName: "",
					serviceLineProviderNPInotInDB: false
				},
				dentalInformation: {
					toothNumber: "",
					oralCavityDesignation: [],
					toothSurfaceCodes: [],
					prosthesis: ""
				}
			};
			serviceCodes.push(serviceCode);
		}
		var values = serviceCodes[selectedLineItemIndex];

//		$("#modifiersListBox").val(serviceCodes[selectedLineItemIndex].modifiers);
//		$("#modifiersListBox").empty();
//		if (serviceCodes[selectedLineItemIndex].modifiers != null && serviceCodes[selectedLineItemIndex].modifiers.length > 0) {
//			serviceCodes[selectedLineItemIndex].modifiers.forEach(function(modifier) {
//				$("#modifiersListBox").append($('<option>', {value : modifier, text : modifier }));
//			});
//		}
		
		if (!$("#modifiersList") == '') {
			//empty out the listbox/dropdown
			$("#modifiersListBox").empty();
			
			//split the text and value here
			var info = values.modifiers;	//$.trim($("#modifiersList").val());
			
			if (info.length >= 1) {
				$.each(info,function(i){			//for (var i in info){  or //for (i=0;i<info.length;i++){
				   //alert(info[i]);
					$("#modifiersListBox").append($('<option>', { value : $.trim(info[i]), text : $.trim(info[i]) })  );
				});
			}
		}
		
		if (!$("#surfaceInfoList") == '') {
			$("#surfaceInfoDropDown").empty();
	
			var info = 	values.dentalInformation.toothSurfaceCodes;		
			if (info.length >= 1) {
				$.each(info,function(i){			//for (var i in info){  or //for (i=0;i<info.length;i++){
				   //alert(info[i]);
					$("#surfaceInfoDropDown").append($('<option>', { value : $.trim(info[i]), text : $.trim(info[i]) })  );
				});
			}
		} //if (!$("#surfaceInfoList")
		
		if (!$("#cavityInfoList") == '') {
			$("#cavityInfoDropDown").empty();
			
			//split the text and value here
			var info = 	values.dentalInformation.oralCavityDesignation;					//$.trim($("#cavityInfoList").val());
			if (info.length >= 1) {
				$.each(info,function(i){			
				   //alert(info[i]);
					$("#cavityInfoDropDown").append($('<option>', { value : $.trim(info[i]), text : $.trim(info[i]) })  );
				});
			}
		}
		
		drawLineItems();
	}


	//Top bar on services page (Services Button)
	$("#saveServiceLineItem").click(function(){
		savServiceLineItem();
	});



	$("#newServiceLineItem").click(function(){
		savServiceLineItem();  //should I push too? no, I need the indexed push
		var serviceCode = {
				beginDate: "",
				endDate: "",
				procedureCode: "",
				quantity: "",
				description: "",
				timePeriodQualifier: "",
				serviceDescriptionModelNumber: "",
				modifiers: [],
				lineAmount: "",
				provider: {
					npi: "",
					id: "",
					lastName: "",
					firstName: "",
					serviceLineProviderNPInotInDB: false
				},
				dentalInformation: {
					toothNumber: "",
					oralCavityDesignation: [],
					toothSurfaceCodes: [],
					prosthesis: ""
				}
		};
		serviceCodes.push(serviceCode);
		$("#serviceLineItems").val(JSON.stringify(serviceCodes));
		//$("#serviceBeginDate").val();	//TODO not needed
		selectedLineItemIndex = serviceCodes.length - 1;	//brand new line item is empty hence show it all empty - this is its index
		drawLineItems();


		//reset all these fields to be empty so user can start filling them
		$("#serviceBeginDate").val('');
		$("#serviceEndDate").val('');
		$("#procedureCode").val('');
		$("#modifiers").val('');
		$("#quantity").val('');
		$("#lineAmount").val('');
		$("#description").val('');
		$("#providerNPI").val('');
		$("#providerLastNameInBox").val('');
		$("#providerFirstNameInBox").val('');
		$("#serviceLineProviderNPInotInDB").val(false);
		$("#serviceDescriptionModelNumber").val('');

		//reset these dropdowns
		$("#modifiersListBox").empty();
		$("#cavityInfoDropDown").empty();
		$("#surfaceInfoDropDown").empty();

		//reset hidden fields - to interact with UI elements & local JS variables
		$("#providerNPIJsonResponse").val('');
		$("#serviceLineItemProviderLegacyId").val('');
		$("#modifiersList").val('');
		$("#cavityInfoList").val('');
		$("#serviceInfoList").val('');

		//reset these drop down list boxes to first value
		$("#timePeriodQualifier").val('');
		$("#toothNumber").val('');
		$("#oralCavityDesignationList").val('');
		$("#toothSurfaceCodes").val('');
		$("#prosthesis").val('');
		//$('select option:first-child').attr("selected", "selected");  OR 		$('myID')[0].selectedIndex = 0;


		if ($("#selectedServiceTypeCode").val() == 42 ) {
			//reset all fields regardless
		} //HHC fields
	});



	$("#delServiceLineItem").click(function(){
		serviceCodes.splice(selectedLineItemIndex, 1);
		selectedLineItemIndex = 0;
		//safest: Choose the first item to be the selected one by default whenever a delete happens
		drawLineItems();
	});




	function drawLineItems() {

		//add the display and the current selected line item icon ON THE TOP LINE ITEMS TABLE with blue circle
		var i;
		$('#lineItems').empty();
		$('#lineItems').append('<tr><td width="8%"><b>#</b></td><td width="46%"><b>Service Begin Date</b></td><td width="46%"><b>Service Procedure Code</b></td></tr>');

		for (i = 0; i < serviceCodes.length; i++) {
			$('#lineItems').append('<tr>');
			if (i == selectedLineItemIndex) {
				$('#lineItems').append('<td width="8%"><a class="myItem" name=' + i + '"><img src="/pasa/resources/images/blue-circle.gif"></a></td>');
			} else {
				$('#lineItems').append('<td width="8%"><a class="myItem" name=' + i + '">SV' + (i + 1) + '</a></td>');
			}
				$('#lineItems').append('<td width="46%">' + serviceCodes[i].beginDate + '</td>');
				$('#lineItems').append('<td width="46%">' + serviceCodes[i].procedureCode + '</td>');
			$('#lineItems').append('</tr>');
		}
	}


	$('#lineItems').on('click', '.myItem', function(){		//when user click on SV# for each line item
		//save the values from previous item
		savServiceLineItem();

		var lineItem = $(this);
		var index = lineItem.attr("name");
		var key;
		selectedLineItemIndex = parseInt(index);
		drawLineItems();		//to bring the blue circle image on selected line item

		var currentItem = serviceCodes[selectedLineItemIndex];
		//fill/show date for current item on display
		$("#serviceBeginDate").val(currentItem.beginDate);
		$("#procedureCode").val(currentItem.procedureCode);
		$("#quantity").val(currentItem.quantity);
		$("#lineAmount").val(currentItem.lineAmount);

		//$("#modifiersListBox").val(currentItem.modifiers);
		$("#modifiersListBox").empty();
		if (currentItem.modifiers != null && currentItem.modifiers.length > 0) {
			currentItem.modifiers.forEach(function(modifier) {
				$("#modifiersListBox").append($('<option>', {value : modifier, text : modifier }));
			});
		}

		//for HHC
		if ($("#selectedServiceTypeCode").val() == 42 ) {
			$("#serviceEndDate").val(currentItem.endDate);
			$("#timePeriodQualifier").val(currentItem.timePeriodQualifier);
			$("#providerNPI").val(currentItem.provider.npi);
		} else if ($("#selectedServiceTypeCode").val() == 12) {
			$("#serviceDescriptionModelNumber").val(currentItem.serviceDescriptionModelNumber);
		} else {
			//Other fields = All dental ones?
			$("#serviceEndDate").val(currentItem.endDate);
			$("#description").val(currentItem.description);
			$("#providerNPI").val(currentItem.provider.npi);
			$("#serviceLineItemProviderLegacyId").val(currentItem.provider.id);	//id: "",
			$("#providerLastNameInBox").val(currentItem.provider.lastName);
			$("#providerFirstNameInBox").val(currentItem.provider.firstName);
			$("#serviceLineProviderNPInotInDB").val(currentItem.provider.serviceLineProviderNPInotInDB);

			//process the info for the lower section where most errors are
			var dentalInfo = serviceCodes[selectedLineItemIndex].dentalInformation;

			//$("#toothNumber").append('<option id="' + key + '">' + serviceCodes[selectedLineItemIndex].dentalInformation.toothNumber + '</option>');
			$("#toothNumber").val(dentalInfo.toothNumber);
			
			$("#surfaceInfoDropDown").empty();
			if (dentalInfo.toothSurfaceCodes != null &&	dentalInfo.toothSurfaceCodes.length > 0) {
				dentalInfo.toothSurfaceCodes.forEach(function(toothSurfaceCode) {
					$("#surfaceInfoDropDown").append($('<option>', {value : toothSurfaceCode, text : toothSurfaceCode }));
				});
			}
			//select first element
			//$('#surfaceInfoDropDown option:first-child').attr("selected", true);
			
			$("#cavityInfoDropDown").empty();
			if (dentalInfo.oralCavityDesignation != null &&	dentalInfo.oralCavityDesignation.length > 0) {
				dentalInfo.oralCavityDesignation.forEach(function(oralCavityInfo) {
					$("#cavityInfoDropDown").append($('<option>', {value : oralCavityInfo, text : oralCavityInfo }));
				});
			}
			//select first element
			//$('#cavityInfoDropDown option:first-child').attr("selected", true);
			
			$("#prosthesis").val(dentalInfo.prosthesis);
			
		}
	});


	//This function to be used by two calls.  One from submit button, 2nd thru Save Line Item Button
	function savServiceLineItem() {
		console.log("For Service Line Item provider id: NPI->" +  $("#serviceLineItemProviderLegacyId").val());
		var serviceCodeLength = serviceCodes.length;
		var modifiers = [];
//		if ($("#modifiersListBox").val()) {
//			modifiers = $("#modifiersListBox").val().split(',');
//		}
		$("#modifiersListBox option").each(function() {
			modifiers.push($(this).val());
		});

		var surfaceInfo = [];
		$("#surfaceInfoDropDown option").each(function() {
			surfaceInfo.push($(this).val());
		});

		var cavityInfo = [];
		$("#cavityInfoDropDown option").each(function() {
			cavityInfo.push($(this).val());
		});

		var serviceCode = {
				beginDate: $("#serviceBeginDate").val(),
				endDate: $("#serviceEndDate").val(),
				procedureCode: $("#procedureCode").val(),
				quantity: $("#quantity").val(),
				description: $("#description").val(),
				timePeriodQualifier: $("#timePeriodQualifier").val(),
				serviceDescriptionModelNumber: $("#serviceDescriptionModelNumber").val(),
				modifiers: modifiers,
				lineAmount: $("#lineAmount").val(),
				provider: {
					npi: $("#providerNPI").val(),
					id: $("#serviceLineItemProviderLegacyId").val(),
					lastName: $("#providerLastNameInBox").val(),
					firstName: $("#providerFirstNameInBox").val(),
					serviceLineProviderNPInotInDB: $("#serviceLineProviderNPInotInDB").val()
				},
				dentalInformation: {
					toothNumber: $("#toothNumber").val(),
					oralCavityDesignation: cavityInfo,
					toothSurfaceCodes: surfaceInfo,
					prosthesis: $("#prosthesis").val()
				}
		};
		console.log(JSON.stringify(serviceCode));
		//serviceCodes.push(serviceCode);		//we need the index
		serviceCodes[selectedLineItemIndex] = serviceCode;
		console.log(JSON.stringify(serviceCodes));		
		$("#serviceLineItems").val(JSON.stringify(serviceCodes));
		drawLineItems();
	}



	
	
function runProiderNPIJSONcall(){
	
		$("#testJsonResponse").val("");
		$("#npiNumber").val("");
		//alert($("#serviceLineItemProviderLegacyId").val(""));

		//https://mnits-lt.dhs.state.mn.us/npi-popup-mvc/locations/A342517700?locationJson=testJsonResponse
		var npi = $.trim($("#providerNPI").val());
		var serviceLineProviderNPInotInDB = false;
		if (npi != '') {

	        //alert("in ajax call");
	        $.ajax({
	         type: "get",
	         url: "/pasa/locations/json",
	         cache: false,
	         data:'npi=' + npi,
	         success: function(response){
	          //alert(response);
	        	 if (response.length == 0) {
	 	        	//alert("Invalid value " + npi + " for NPI/UMPI in the Authorization Form. The NPI/UMPI is not in our database.");
	 	        	$("#infoDivServicesTab").html("Invalid value " + npi + " for NPI/UMPI in the Authorization Form. The NPI/UMPI is not in our database.");
	 	        	$("#infoDivServicesTab").show();
	 		        $("#infoDivServicesTab").removeClass('hidden');
		        	$("#providerLastNameInBox").val("");
			        $("#providerFirstNameInBox").val("");
			        $("#serviceLineItemProviderLegacyId").val("");
			        serviceLineProviderNPInotInDB = true;
			        $("#serviceLineProviderNPInotInDB").val(true);
			        //$("#serviceLineItemProviderLegacyId").val("1234567");
			        //alert("localhost: " + $("#serviceLineItemProviderLegacyId").val());
	 	        } else if (response.length == 1) {
		        	//happy path
	 	        	serviceLineProviderNPInotInDB = false;
	 	        	$("#serviceLineProviderNPInotInDB").val(false);
	 	        	$("#infoDivServicesTab").hide();
	 				$("#infoDivServicesTab").removeClass("alert-danger");
	 				$("#infoDivServicesTab").addClass("alert-info");

		        	if (!$("#infoDivServicesTab").hasClass('hidden')) {
		        	  $("#infoDivServicesTab").addClass('hidden');
		        	}	//hide the message div - because all is good
			        //$("#providerLastNameInBox").val(response[0].providerName);
			        //$("#providerFirstNameInBox").val(response[0].org_name);
			        $("#serviceLineItemProviderLegacyId").val(response[0].id);			//this is the most userful field	        
					serviceCodes[selectedLineItemIndex].provider.id = response[0].id;
					$("#serviceLineItems").val(JSON.stringify(serviceCodes));
					console.log("For Service Line Item provider id: NPI->" +  $("#providerNPI").val() +  " | " + response[0].id );
					//alert("For this provider's JSON object: NPI->" +  $("#serviceLineItemProviderLegacyId").val() +  " | " + jsonObject.legacy_id );
		         } else {
			         //more than one location? must be conslidated and we do not allow that.  WE CANNOT ALLOW TO CHANGE THE TAB UNTIL USER REMOVES THIS NPI
		        	 $("#infoDivServicesTab").html("Invalid value " + npi + " for Service Provider NPI in the Service Line Form. The Service Provider NPI has been identified as a consolidated NPI. We don't allow consolidated NPI in the Service Provider NPI field.");
		 	        	$("#infoDivServicesTab").show();
		 		    $("#providerLastNameInBox").val("");
			        $("#providerFirstNameInBox").val("");
			        $("#serviceLineItemProviderLegacyId").val("");
			        $("#infoDivServicesTab").show();			//show the info message
			        $("#infoDivServicesTab").removeClass('hidden');
	 	        	serviceLineProviderNPInotInDB = false;
	 	        	$("#serviceLineProviderNPInotInDB").val(false);
		         }
	         },
	         error: function(){
	        	 //alert('Error while request..');
	        	  $("#infoDivServicesTab").html("Error while processing AJAX request..");
	        	  $("#infoDivServicesTab").show();
	        	  $("#infoDivServicesTab").removeClass('hidden');
	         }
	        });
		} else {
			$('#infoDivServicesTab').hide();
		}//if (npi != '')
	}






/************** SUBMIT BUTTON SHOULD PROCESS ALL THESE LIST FIELDS ****************/

	// ********** SUBMIT app ******************
	
	//$("#btnSubmit").click(function() {
	//	$('#mnits-spinner').show(0);
	//	savServiceLineItem();
	//
	//	document.getElementById('authForm').action = "/pasa/authPA";
	//	document.getElementById('authForm').submit();
	//});
	//
	$("#btnSubmitServices").click(function() {
		//alert('in btnSubmitServices');
	
		$('#mnits-spinner').show(0);
		//savServiceLineItem();
	
		document.getElementById('authForm').action = "/pasa/authPA";
		document.getElementById('authForm').submit();	//calls $( "#authForm" ).submit(function( event )  below
	});
	
	
	
	
	$( "#authForm" ).submit(function( event ) {
		//alert('in authForm.submit');	
		
		//if there is a provider NPI in servies tab  then call the location service
		runProiderNPIJSONcall();
		
		//save some lists information
		//1 - CommunictionText
		str = "";
		$("#communicationTextListBox option").each(function()
		{
			if (str == '')   { str = $.trim($(this).text()); }
			else { str = str + ',' + $.trim($(this).text()); }
		});
		$('#communicationTextList').val(str);	//path="communicationText" id="communicationTextList"
	
		//2 - Diagnosis Code
		var str = '';
		$("#diagnosisCodes option").each(function()
		{
			if (str == '')   { str = $.trim($(this).text()); }
			else { str = str + ',' + $.trim($(this).text()); }
			//alert(str);
		});
		$('#diagnosisCodeList').val(str);	//path="pe.diagnosisCodes" id="diagnosisCodeList"
	
		
		//save the last line item before proceeding
		savServiceLineItem();
		
		//Get the DOB - just in case
		//var subDOB = $('#subscriberDOB-DP').datetimepicker('getDate');
		//alert("DOB ->" + subDOB);
	
		//process all listbox and fill their values in hidden fields correspoding to java objects via path variable
		//0 - Service Type Code
	//			var str = '';
	//			$("#selectedServiceTypeCodeList option").each(function()
	//			{
	//				if (str == '')   { str = $(this).text(); }
	//				//alert(str);
	//			});
	//			$('#selectedServiceTypeCode').val(str);	//path="selectedServiceTypeCode"
	//
	

//		//3 - Modifiers
//		str = "";
//		$("#modifiersListBox option").each(function()
//		{
//			if (str == '')   { str = $.trim($(this).text()); }
//			else { str = str + ',' + $.trim($(this).text()); }
//		});
//		$('#modifiersList').val(str);	//path="svc.modifiers" id="modifiersList"
//	
//		//4 - Oral Cavity Designation
//		str = "";
//		$("#cavityInfoDropDown option").each(function()
//		{
//			if (str == '')   { str = $.trim($(this).text()); }
//			else { str = str + ',' + $.trim($(this).text()); }
//		});
//		if (str.substr(str.length-1) == ",") { str = str.slice(0,-1) }
//		$('#cavityInfoList').val(str);	//path="svc.dentalInformation.oralCavityDesignation" id="cavityInfoList"
//	
//		//5 - Tooth Surface Codes
//		str = "";
//		$("#surfaceInfoDropDown option").each(function()
//		{
//			if (str == '')   { str = $.trim($(this).text()); }
//			else { str = str + ',' + $.trim($(this).text()); }
//		});
//		if (str.substr(str.length-1) == ",") { str = str.slice(0,-1) }
//		$('#surfaceInfoList').val(str);	//path="svc.dentalInformation.toothSurfaceCodes" id="surfaceInfoList"
	
	});





});	//end of all jquery















// *********** SERIALIZE objects! comment out as needed.  form can also be replected with input or textarea etc. ***************
//$( "form" ).submit(function( event ) {
//	  console.log( $( this ).serializeArray() );
//	  event.preventDefault();
//});



//********************* METHODS NOT IN USE AND NOT NEEDED ANY MORE ****************





//for loops
//var $dropdown = $("#dropdown");
//$.each(result, function() {
//    $dropdown.append($("<option />").val(this.ImageFolderID).text(this.Name));
//});


//select first elements
//$('#cavityInfoDropDown option:first-child').attr("selected", true);

//$('#oralCavityDesignationList option:first-child').attr("selected", true);
//$('#toothSurfaceCodes option:first-child').attr("selected", true);

//$("#surfaceInfoDropDown").val(currentItem.surfaceInfo);
//$("#cavityInfoDropDown").val(currentItem.cavityInfo);



//If you're testing for an empty string:
//if(myVar === ''){ // do stuff };
//
//If you're checking for a variable that has been declared, but not defined:
//if(myVar === null){ // do stuff };
//
//If you're checking for a variable that may not be defined:
//if(myVar === undefined){ // do stuff };
//
//If you're checking both i.e, either variable is null or undefined:
//if(myVar == null){ // do stuff };

//	if (!$("#selectedServiceTypeCode") == '') {
//		var info = $("#communicationTextList").val();
//		$("#selectedServiceTypeCodeList").append($('<option>', {value : info, text : info }) );
//		$("#selectedServiceTypeCodeList").prop($('selected', {value : info, text : info }) );
//	}





/*


//		// ********** AUTHORIZATION tab **********
//		$("#requestNpi").val("");
//		$("#communicationNumber").val("");
//		$("#subcriberId").val("");
//		$("#subcriberDOB").val("");
//		$("#subcriberLastName").val("");
//		$("#subcriberFirstName").val("");
//		$("#diagnosisCode").val("");
//
//			//if for HHC
//			$("#contactLastName").val("");
//			$("#contactFirstName").val("");
//			$("#eventDate").val("");
//
//		// ************* SERVICES tab **************
//		$("#serviceBeginDate").val("");
//		$("#procedureCode").val("");
//		$("#quantity").val("");
//		$("#lineAmount").val("");
//
//			//if for HHC
//			$("#serviceEndDate").val("");
//			$("#timePeriodQualifier").val("");
//			$("#providerNPI").val("");
//
//	} // do above for STST, ATST and PROD



		//jquery function template
		//	$("").click(function(){
		//
		//		$( ".hch-block").hide();
		//	});


	// *************** UNUSED FUNCTION: SAVING FOR FUTURE *********************
		//$(this).closest('myForm').find("input[type=text], textarea").val("");
		//console.log("this is %o, event is %o, host is %s", this, e, location.host);
		//console.log("%s", new Error().stack);

//		$("input[type=text]").each(function(){		//:not([value=''])
//			//"Going to reset this field " + ": " + $(this).val());
//			//console.log( $(this).attr("id") );
//			if ($(this).val()) {
//
//				$(this).val('');
//				//alert( $(this).attr("id") + ": " + $(this).val() );
//			} //else !$(this).val()
//		});


		//Iterate thru a dropdown
//		$('#select > option').each(function() {
//		    alert($(this).text() + ' ' + $(this).val());
//		});


		//TODO: also reset the dropdowns
//		$(':input','#myform')
//		  .not(':button, :submit, :reset, :hidden')
//		  .val('')
//		  .prop('checked', false)
//		  .prop('selected', false);


//		$("#requestNpi").blur(function(){
//			if( !$(this).val() ) {
//		        $(this).css("background-color", "#f2dede");
//				alert("You must enter a Requester NPI/UMPI.");
//		    } else {
//	    		var npiValue = document.getElementById('npi').value;
//	    			$('#mnits-spinner').show(0);
//	    			location.href = npiValue;
//	    		}
//		});




//RESET
		/*
		$("#requestNpi").attr('value', '');
		$("#requestId").attr('value', '');
		$("#OrgName").attr('value', '');
		$("#orgContactFirstName").attr('value', '');
		$("#Address").attr('value', '');
		$("#City").attr('value', '');
		$("#State").attr('value', '');
		$("#Zip").attr('value', '');
		$("#communicationNumber").attr('value', '');
		$("#contactName").attr('value', '');
		$("#contactLastName").attr('value', '');
		$("#supplementId").attr('value', '');
		$("#contactFirstName").attr('value', '');
		$("#subscriberId").attr('value', '');
		$("#subcriberDOB").attr('value', '');
		$("#subcriberLastName").attr('value', '');
		$("#subcriberFirstName").attr('value', '');
		$("#subcriberMiddleName").attr('value', '');
		$("#eventDate").attr('value', '');
		$("#traceNumber").attr('value', '');
		$("#diagnosisCode").attr('value', '');
		$("#serviceBeginDate").attr('value', '');
		$("#serviceEndDate").attr('value', '');
		$("#procedureCode").attr('value', '');
		$("#quantity").attr('value', '');
		$("#serviceDescriptionModelNumber").attr('value', '');
		$("#modifiers").attr('value', '');
		$("#lineAmount").attr('value', '');
		$("#providerNPI").attr('value', '');
		$("#providerLastName").attr('value', '');
		$("#providerFirstName").attr('value', '');

		//reset all dropdowns as well
		$("#communicationTextListBox").empty();
		$("#diagnosisCodes").empty();
		$("#modifiersListBox").empty();
		$("#cavityInfoDropDown").empty();
		$("#surfaceInfoDropDown").empty();
		$("#diagnosisCodes").empty();

		//other resettings (do NOT empty out the list box values)
		//$("#toothNumber").empty();
		//$("#oralCavityDesignationList").empty();
		//$("#toothSurfaceCodes").empty();
		//$("#prosthesis").empty();

		//hide tabs, fields back to initial values, set back to medical menu item


		//Clear the hidden list fields (data holders)
		$("#communicationTextList").val();
		$("#diagnosisCodeList").val();
		$("#modifiersList").val();
		$("#cavityInfoList").val();
		$("#surfaceInfoList").val();

		//Service Line Items - a whole different world
		$("#serviceLineItems").val();

		//JSON holders - should I reset them
		$("#requestId").val();
		$("#testJsonResponse").val();
		$("#providerNPIJsonResponse").val();


		//clear the form
		$("#authForm").html(originalForm);

		//clear all error boxes
		var errorSpanElements = $('[id$=".errors"]');
		errorSpanElements.each(function(index, element){
		  //console.log($(element).attr('id') + ' '  + $(element).html());
		  $(element).html("");
		});



		//$("#requestNpi").trigger("blur");
		//$("#selectedServiceTypeCode").val("42").trigger("change");

		$("#selectedServiceTypeCode").on('change', function() {
			alert("I am in selectedServiceTypeCode change");
		}).trigger('change');

		$("#requestNpi").on('blur', function() {	//focus change
			  //$(this).closest('div').toggleClass('disabled', !$.trim(this.value).length);
			  alert("I am in NPI blur");
		}).trigger('blur');

		$.get ("/pasa/authPA");
		location.reload(true);	window.location is much better to use
		*/

	// *************** end of UNUSED FUNCTION *********************







