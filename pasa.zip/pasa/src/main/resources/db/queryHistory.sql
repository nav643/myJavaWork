
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('1952685158','A557175200','1356427397','1083160352','1952696049','1558421792','1427089010','1437691417');	PASA mnits_reg_v5	1593227519895	SQL	1	0.031
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('1952685158','A557175200','356427397','083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227321865	SQL	1	0.022
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('1952685158','1407834302','557175200','356427397','083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227307799	SQL	1	0.062
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('437691417');	PASA mnits_reg_v5	1593227275453	SQL	1	0.017
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('427089010','437691417');	PASA mnits_reg_v5	1593227271008	SQL	1	0.018
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('558421792','427089010','437691417');	PASA mnits_reg_v5	1593227266564	SQL	1	0.019
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227261204	SQL	1	0.023
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227256242	SQL	1	0.023
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('356427397','083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227250010	SQL	1	0.022
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('557175200','356427397','083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227239706	SQL	1	0.024
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in ('1952685158','557175200','356427397','083160352','952696049','558421792','427089010','437691417');	PASA mnits_reg_v5	1593227089872	SQL	4	0.024
select npi_number, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in 
(select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') 
group by NPI_NUMBER order by count(prov_type);	PASA mnits_reg_v5	1593227056703	SQL	4	6.646
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' 
and NPI_NUMBER not in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33')
group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1593227038907	SQL	4	8.099
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='A557175200';	PASA mnits_reg_v5	1593226944124	SQL	1	0.02
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239';	PASA mnits_reg_v5	1593226888064	SQL	11	0.082
select distinct(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226234843	SQL	1	0.016
select distinct(prov_number), prov_type from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226211137	SQL	1	0.017
select distinct(prov_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226179598	SQL	3	0.018
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in 
(select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') 
order by NPI_NUMBER, prov_type;	PASA mnits_reg_v5	1592981223250	SQL	2	6.312
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1407834302' group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1592981173559	SQL	2	0.042

select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='A557175200';

select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='A557175200';	PASA mnits_reg_v5	1593226944124	SQL	1	0.02
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239';	PASA mnits_reg_v5	1593226888064	SQL	11	0.082
select distinct(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226234843	SQL	1	0.016
select distinct(prov_number), prov_type from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226211137	SQL	1	0.017
select distinct(prov_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1593226179598	SQL	3	0.018
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in 
(select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') 
order by NPI_NUMBER, prov_type;	PASA mnits_reg_v5	1592981223250	SQL	2	6.312
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1407834302' group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1592981173559	SQL	2	0.042
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1083160352';	PASA mnits_reg_v5	1592942810048	SQL	1	0.036
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1760541700';	PASA mnits_reg_v5	1592942789541	SQL	4	0.049
select npi_number, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER order by count(prov_type);	PASA mnits_reg_v5	1592456165302	SQL	2	6.794
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' 
group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1592455986203	SQL	1	7.002
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1592455935809	SQL	1	6.91
select prov_type, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1164474250' group by prov_type order by count(prov_type);	PASA mnits_reg_v5	1592455225307	SQL	1	0.015
select npi_number, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1164474250' group by NPI_NUMBER order by count(prov_type);	PASA mnits_reg_v5	1592455192383	SQL	1	0.016
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1164474250';	PASA mnits_reg_v5	1592455159913	SQL	1	0.041
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1407834302';	PASA mnits_reg_v5	1592455079253	SQL	1	0.031
select npi_number, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER order by NPI_NUMBER;	PASA mnits_reg_v5	1592454663409	SQL	1	7.543
select npi_number, count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592454595808	SQL	1	8.065
select npi_number,count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592454529088	SQL	1	7.796
select count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592454511041	SQL	1	7.732
select count(NPI_NUMBER), count(prov_type) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592454423903	SQL	1	7.729
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592454257682	SQL	1	7.185
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') order by NPI_NUMBER, prov_type;	PASA mnits_reg_v5	1592454217464	SQL	1	7.47
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') order by NPI_NUMBER, prov_type;	PASA mnits_reg_v5	1592454113367	SQL	1	7.156
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' and npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') order by NPI_NUMBER, prov_type;	PASA mnits_reg_v5	1592454045872	SQL	1	8.045
select NPI_NUMBER from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' and npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') group by NPI_NUMBER;	PASA mnits_reg_v5	1592453912471	SQL	1	0.911
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select npi_number from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33');	PASA mnits_reg_v5	1592453850860	SQL	3	7.37
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type !='33' and npi_number in (select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33');	PASA mnits_reg_v5	1592453795577	SQL	1	7.218
select distinct(npi_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33'	PASA mnits_reg_v5	1592453729648	SQL	1	0.265
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number in (select npi_number from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33') and npi_number='1801909239';	PASA mnits_reg_v5	1592453650079	SQL	1	0.089
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_number in (select npi_number from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33');	PASA mnits_reg_v5	1592453603821	SQL	1	7.598
select npi_number from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33';	PASA mnits_reg_v5	1592453543572	SQL	1	0.312
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_number in (select prov_number from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33');	PASA mnits_reg_v5	1592451618467	SQL	1	7.919
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='A342517700';	PASA mnits_reg_v5	1592451488260	SQL	5	0.015
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33';	PASA mnits_reg_v5	1592451442593	SQL	5	0.267
select count(*) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where prov_type='33';	PASA mnits_reg_v5	1592450811309	SQL	2	0.344
select distinct(prov_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239';	PASA mnits_reg_v5	1592450771133	SQL	5	0.007
select distinct(taxonomy_code) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type != '33';	PASA mnits_reg_v5	1592442069579	SQL	1	0.03
select distinct(prov_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type!='33';	PASA mnits_reg_v5	1592441842789	SQL	1	0.018
select distinct(prov_number) from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI where npi_number='1801909239' and prov_type='33';	PASA mnits_reg_v5	1592441830358	SQL	1	0.014
select * from MNITS_COMMON.GENERAL_INFO_SERVICE_BY_NPI;	PASA mnits_reg_v5	1592362315191	SQL	1	12.153